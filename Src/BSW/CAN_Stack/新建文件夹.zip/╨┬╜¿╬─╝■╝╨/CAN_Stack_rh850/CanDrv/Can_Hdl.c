/******************************************************************************/
/* PROJECT  :  M01                                                            */
/******************************************************************************/
/* !Layer           : COM_CAN                                                 */
/*                                                                            */
/* !Component       : Can_Hdl                                                 */
/* !Description     : Can communication interface                             */
/*                                                                            */
/* !Module          : Can_Hdl                                                 */
/* !Description     : Can communication interface                             */
/*                                                                            */
/* !File            : Can_Hdl.c                                               */
/*                                                                            */
/* !Scope           : Private                                                 */
/*                                                                            */
/* !Target          : uPD70F3375                                              */
/*                                                                            */
/* !Vendor          : T13 (VALEO Climate Control China)                       */
/*                                                                            */
/* Coding language  : C                                                       */
/*                                                                            */
/* COPYRIGHT 2017 VALEO                                                       */
/* All Rights Reserved                                                        */
/*                                                                            */
/******************************************************************************/
/* PVCS                                                                       */
/******************************************************************************/
/* !Deviation : Inhibit MISRA rule [0288]: Dollar sign is needed by configu-  */
/*              ration management tool (PVCS)                                 */
/* PRQA S 0288 ++                                                             */
/* PRQA S 0292 ++                                                             */
/* $Archive::   V:/SWDatabase/CHJ_M01/archives/M01_CLM/04_Software/Sources/CO$*/
/* $Revision::   1.1      $$Author::   chunping.yan   $$Date::   Dec 18 2017 $*/
/* PRQA S 0292 --                                                             */
/* PRQA S 0288 --                                                             */
/******************************************************************************/
/* MODIFICATION LOG :                                                         */
/******************************************************************************/
/* $Log:   V:/SWDatabase/CHJ_M01/archives/M01_CLM/04_Software/Sources/COM_CAN/Can/Can_Hdl.c-arc  $
 * 
 *    Rev 1.1   Dec 18 2017 15:24:06   chunping.yan
 * Add signal 0x538
 * 
 *    Rev 1.1   Jun 30 2017 18:19:04   chunping.yan
 * standardization
 * 
 *    Rev 1.0   Jun 30 2017 09:47:22   CYAN
 * Initial revision.
 * 
 * 
 ******************************************************************************/

/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
#include "Std_Types.h"
#include "Can_Type.h"
#include "Can_Hdl.h"
#include "Can.h"
#include "CanTrcv.h"
#include "Eeprom.h"
/******************************************************************************/
/* DEFINES                                                                    */
/******************************************************************************/

#define   s8Act_ABS_DIFF(x ,y)  ( ((x) > (y)) ? ((x) - (y)) : ((y) - (x)) )
/******************************************************************************/
/* CONSTANTS DEFINITION                                                       */
/******************************************************************************/


/******************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/


/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/


/******************************************************************************/
/* DATA DEFINITION                                                            */
/******************************************************************************/
uint8 Can_u8SendNOkCnt;
uint8 Can_u8SendOkCnt;

static Can_tpfvidRxFuncCallback Can_pfvidRxCallback ;
static Can_tpfvidTxFuncCallback Can_pfvidTxCallback ;
static Std_tpfvidFuncCbk_vid Can_pfvidWakeUpCallback;
static Std_tpfvidFuncCbk_u8 Can_pfvidBusOffCallback;

/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/
//add for PDTest
uint8  u8PDTestMode = 0x00u;
uint16 u16PwmOutValue[4]  = {0,0,0,0};
uint8  u8ValveOutValue[4] = {0,0,0,0};



static uint8  u8MixLPerPosi    = 0xffu;
static uint8  u8MixRPerPosi    = 0xffu;
static uint8  u8ModeLStsPosi   = 0xffu;
static uint8  u8ModeRStsPosi   = 0xffu;
static uint8  u8DefrostPerPosi = 0xffu;
static uint8  u8RecyPerPosi    = 0xffu;


uint8 au8_00A_C_57900323_10_B0B1[2] = {0,0};
uint8 au8_00A_C_57900323_10_B2B3[2] = {0,0};
uint8 au8_00A_C_57900323_10_B4B5[2] = {0,0};
uint8 au8_00A_C_57900323_10_B6B7[2] = {0,0};

uint8 au8_00B_C_57900323_11_B0B1[2] = {0,0};
uint8 au8_00B_C_57900323_11_B2B3[2] = {0,0};
uint8 au8_00B_C_57900323_11_B4B5[2] = {0,0};
uint8 au8_00B_C_57900323_11_B6B7[2] = {0,0};

uint8 au8_00C_C_57900322_12_B0B1[2] = {0,0};
uint8 au8_00C_C_57900322_12_B2B3[2] = {0,0};
uint8 au8_00C_C_57900322_12_B4B5[2] = {0,0};
uint8 au8_00C_C_57900322_12_B6B7[2] = {0,0};

uint8 au8_00D_C_57900322_13_B0B1[2] = {0,0};
uint8 au8_00D_C_57900322_13_B2B3[2] = {0,0};
uint8 au8_00D_C_57900322_13_B4B5[2] = {0,0};
uint8 au8_00D_C_57900322_13_B6B7[2] = {0,0};

uint8 au8_00E_C_56704738_14_B0B1[2] = {0,0};
uint8 au8_00E_C_56704738_14_B2B3[2] = {0,0};
/*
uint8 au8_00E_C_56704738_14_B4B5[2] = {0,0};
uint8 au8_00E_C_56704738_14_B6B7[2] = {0,0};

uint8 au8_00F_C_56704738_15_B0B1[2] = {0,0};
uint8 au8_00F_C_56704738_15_B2B3[2] = {0,0};
uint8 au8_00F_C_56704738_15_B4B5[2] = {0,0};
uint8 au8_00F_C_56704738_15_B6B7[2] = {0,0};
*/

/******************************************************************************/
/* LOCAL FUNCTION DEFINITION                                                  */
/******************************************************************************/
#if 0
const CAN_RX_RULE_TYPE CAN_RX_RULE_TABLE[CAN_RX_RULE_NUM] = {
		/* CAN 1 reception rules */
		/* NO.0 : ID = 0x3DB will be accepted, Receive FIFO Buffer 0 */
		{{0x000003DBUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000001UL}},
		/* NO.1 : ID = 0x3BC will be accepted, Receive FIFO Buffer 1 */
		{{0x000003BCUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000002UL}},
		/* NO.2 : ID = 0x51C will be accepted, Receive FIFO Buffer 1 */
		{{0x0000051CUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000002UL}},
		/* NO.3 : ID = 0x3CC will be accepted, Receive FIFO Buffer 1 */
		{{0x000003CCUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000002UL}},
#if 0
		/* NO.4 : ID = 0x530 will be accepted, Receive FIFO Buffer 4 */
		//{{0x00000530UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}}, //use to send msg to control Dc Motor Board
#else
		/* NO.4 : ID = 0x008 will be accepted, Receive FIFO Buffer 4 */
		{{0x00000008UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}}, //use to recv msg from control Dc Motor Board
#endif
		/* NO.5 : ID = 0x390 will be accepted, Receive FIFO Buffer 4 */
		{{0x00000390UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}},
		/* NO.6 : ID = 0x295 will be accepted, Receive FIFO Buffer 4 */
		{{0x00000295UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}},
		/* NO.7 : ID = 0x95 will be accepted, Receive FIFO Buffer 5 */
		{{0x00000095UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
		/* NO.8 : ID = 0x3A0 will be accepted, Receive FIFO Buffer 5 */
		{{0x000003A0UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
	    /* NO.9 : ID = 0x620 will be accepted, Receive FIFO Buffer 5 */
		{{0x00000620UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
#if 0
		/* NO.10 : ID = 0x560 will be accepted, Receive FIFO Buffer 5 */
		{{0x00000560UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
		/* NO.11: ID = 0x400 will be accepted, Receive FIFO Buffer 6 */
		{{0x00000400UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.12 : ID = 0x42A will be accepted, Receive FIFO Buffer 6 */
		{{0x0000042AUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.13: ID = 0x419 will be accepted, Receive FIFO Buffer 6 */
		{{0x00000419UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.14 : ID = 0x405 will be accepted, Receive FIFO Buffer 6 */
		{{0x00000405UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.15 : ID = 0x429 will be accepted, Receive FIFO Buffer 6 */
#else
		/* NO.10 : ID = 0x00A will be accepted, Receive FIFO Buffer 5 */
		{{0x0000000AUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
		/* NO.11: ID = 0x00B will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000BUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.12 : ID = 0x00C will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000CUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.13: ID = 0x00D will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000DUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.14 : ID = 0x00E will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000EUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.15 : ID = 0x00F will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000FUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
#endif	
		/* NO.16 : ID = 0x7A3 will be accepted, Receive FIFO Buffer 7 */
		{{0x000007A3UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000080UL}},
		/* NO.17 : ID = 0x7DF will be accepted, Receive FIFO Buffer 7 */
		{{0x000007DFUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000080UL}},
};
#endif
//add for PDTest
static void vidCanHdlRxCallback(Can_tstrPduType strPdu);

static void vidCanHdlRxCallback(Can_tstrPduType strPdu)
{
	if(0x3DB == strPdu.u32CanId)
	{
       u8PDTestMode = strPdu.pu8Data[0];
	}
    else if(0x3BC == strPdu.u32CanId)
	{
       uint8 u8Index;
	   for(u8Index = 0u; u8Index < 4u; u8Index++)
	   {
          u16PwmOutValue[u8Index] = (uint16)(strPdu.pu8Data[2*u8Index]*256u + strPdu.pu8Data[2*u8Index+1]);
	   }
	}
	else if(0x51C == strPdu.u32CanId)
	{
       uint8 u8Index;
	   for(u8Index = 0u; u8Index < 4u; u8Index++)
	   {
          u8ValveOutValue[u8Index] = strPdu.pu8Data[u8Index];
	   }
	}
	else if(0x008 == strPdu.u32CanId)//DC Motor Info
	{
		u8MixLPerPosi    = strPdu.pu8Data[0];
		u8MixRPerPosi    = strPdu.pu8Data[1];
		u8ModeLStsPosi   = strPdu.pu8Data[2];
		u8ModeRStsPosi   = strPdu.pu8Data[3];
		u8DefrostPerPosi = strPdu.pu8Data[4];
		u8RecyPerPosi    = strPdu.pu8Data[5];
	}
	else if(0x00A == strPdu.u32CanId)
	{
       au8_00A_C_57900323_10_B0B1[0] = strPdu.pu8Data[0];
	   au8_00A_C_57900323_10_B0B1[1] = strPdu.pu8Data[1];
	   /***********************************************/
	   au8_00A_C_57900323_10_B2B3[0] = strPdu.pu8Data[2];
	   au8_00A_C_57900323_10_B2B3[1] = strPdu.pu8Data[3];
	   /***********************************************/
	   au8_00A_C_57900323_10_B4B5[0] = strPdu.pu8Data[4];
	   au8_00A_C_57900323_10_B4B5[1] = strPdu.pu8Data[5];
	   /***********************************************/
	   au8_00A_C_57900323_10_B6B7[0] = strPdu.pu8Data[6];
	   au8_00A_C_57900323_10_B6B7[1] = strPdu.pu8Data[7];
	}
	else if(0x00B == strPdu.u32CanId)
	{
       au8_00B_C_57900323_11_B0B1[0] = strPdu.pu8Data[0];
	   au8_00B_C_57900323_11_B0B1[1] = strPdu.pu8Data[1];
	   /***********************************************/
	   au8_00B_C_57900323_11_B2B3[0] = strPdu.pu8Data[2];
	   au8_00B_C_57900323_11_B2B3[1] = strPdu.pu8Data[3];
	   /***********************************************/
	   au8_00B_C_57900323_11_B4B5[0] = strPdu.pu8Data[4];
	   au8_00B_C_57900323_11_B4B5[1] = strPdu.pu8Data[5];
	   /***********************************************/
	   au8_00B_C_57900323_11_B6B7[0] = strPdu.pu8Data[6];
	   au8_00B_C_57900323_11_B6B7[1] = strPdu.pu8Data[7];
	}
	else if(0x00C == strPdu.u32CanId)
	{
       au8_00C_C_57900322_12_B0B1[0] = strPdu.pu8Data[0];
	   au8_00C_C_57900322_12_B0B1[1] = strPdu.pu8Data[1];
	   /***********************************************/
	   au8_00C_C_57900322_12_B2B3[0] = strPdu.pu8Data[2];
	   au8_00C_C_57900322_12_B2B3[1] = strPdu.pu8Data[3];
	   /***********************************************/
	   au8_00C_C_57900322_12_B4B5[0] = strPdu.pu8Data[4];
	   au8_00C_C_57900322_12_B4B5[1] = strPdu.pu8Data[5];
	   /***********************************************/
	   au8_00C_C_57900322_12_B6B7[0] = strPdu.pu8Data[6];
	   au8_00C_C_57900322_12_B6B7[1] = strPdu.pu8Data[7];
	}
	else if(0x00D == strPdu.u32CanId)
	{
       au8_00D_C_57900322_13_B0B1[0] = strPdu.pu8Data[0];
	   au8_00D_C_57900322_13_B0B1[1] = strPdu.pu8Data[1];
	   /***********************************************/
	   au8_00D_C_57900322_13_B2B3[0] = strPdu.pu8Data[2];
	   au8_00D_C_57900322_13_B2B3[1] = strPdu.pu8Data[3];
	   /***********************************************/
	   au8_00D_C_57900322_13_B4B5[0] = strPdu.pu8Data[4];
	   au8_00D_C_57900322_13_B4B5[1] = strPdu.pu8Data[5];
	   /***********************************************/
	   au8_00D_C_57900322_13_B6B7[0] = strPdu.pu8Data[6];
	   au8_00D_C_57900322_13_B6B7[1] = strPdu.pu8Data[7];
	}
	else if(0x00E == strPdu.u32CanId)
	{
       au8_00E_C_56704738_14_B0B1[0] = strPdu.pu8Data[0];
	   au8_00E_C_56704738_14_B0B1[1] = strPdu.pu8Data[1];
	   /***********************************************/
	   au8_00E_C_56704738_14_B2B3[0] = strPdu.pu8Data[2];
	   au8_00E_C_56704738_14_B2B3[1] = strPdu.pu8Data[3];
	}
	else
	{

	}
}

/*****************Get CAN MSG From Dc Motor Contrl PCBA to Get Flap Motor Actual Posi*****************/
extern uint8  u8GetMixLPerPosi(void)
{
   return u8MixLPerPosi;
}
extern uint8  u8GetMixRPerPosi(void)
{
   return u8MixRPerPosi;
}
extern uint8  u8GetModeLStsPosi(void)
{
   uint8 u8Rtn = 0xffu;
   if(s8Act_ABS_DIFF(u8ModeLStsPosi,0) <= 2)
   {
       u8Rtn = 1u;
   }
   else if(s8Act_ABS_DIFF(u8ModeLStsPosi,49) <= 2)
   {
	   u8Rtn = 3u;
   }
   else if(s8Act_ABS_DIFF(u8ModeLStsPosi,1000) <= 2)
   {
       u8Rtn = 5u;
   }
   else
   {

   }
   return u8Rtn;
}
extern uint8  u8GetModeRStsPosi(void)
{
   return u8ModeRStsPosi;
}
extern uint8  u8GetDefrostPerPosi(void)
{
   return u8DefrostPerPosi;
}
extern uint8  u8GetRecyPerPosi(void)
{
   return u8RecyPerPosi;
}

/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/
void Can_vidHdlInit(void)
{
	Can_u8SendOkCnt = 0u;
	Can_u8SendNOkCnt = 0u;
	Can_pfvidRxCallback = (Can_tpfvidRxFuncCallback)0;

	//add for PDTest
	Can_vidSetRxCallbackFunc(vidCanHdlRxCallback);
}

void Can_vidRxHandler(uint8 u8BufIdx)
{
	uint8 u8Dlc;
	uint32 u32Id;
	uint8 u8Data[8];
	boolean bRtn;
    Can_tstrPduType strPdu;

    /*get data*/
	bRtn = Can_bReceiveFIFORxBuf(u8BufIdx, &u32Id, &u8Dlc, u8Data);

	/* save related frame data	*/
	if (bRtn == TRUE)
	{
		strPdu.u32CanId = u32Id;
		strPdu.u8Dlc = u8Dlc;
		strPdu.pu8Data = u8Data;
		if (Can_pfvidRxCallback != NULL_PTR )
		{
			Can_pfvidRxCallback(strPdu);
			//add for PDTest
			vidCanHdlRxCallback(strPdu);

		}
	}
}

void Can_vidTxHandler(void)
{
	Can_tstrPduType strPdu;
	/*to get the pdu*/
     strPdu.u8Dlc = 0u;
	if (Can_pfvidTxCallback != NULL_PTR ) 
	{ 
		Can_pfvidTxCallback(strPdu);
	}		
}

extern void Can_vidWakeupHandler(void)
{
	if (Can_pfvidWakeUpCallback != NULL_PTR ) 
	{ 
		Can_pfvidWakeUpCallback();
	}	
}

extern void Can_vidBusoffHandler(void)
{
    uint8 u8State = 0u;
	
	if (Can_pfvidBusOffCallback != NULL_PTR ) 
	{ 
		Can_pfvidBusOffCallback(u8State);
	}	
}

void Can_vidSetRxCallbackFunc(Can_tpfvidRxFuncCallback pfvidCallback)
{
	Can_pfvidRxCallback = pfvidCallback;
}

void Can_vidSetTxCallbackFunc(Can_tpfvidTxFuncCallback pfvidCallback)
{
	Can_pfvidTxCallback = pfvidCallback;
}

void Can_vidSetWakeUpCallbackFunc(Std_tpfvidFuncCbk_vid pfvidCallback)
{
	Can_pfvidWakeUpCallback = pfvidCallback;
}

void Can_vidSetBusOffCallbackFunc(Std_tpfvidFuncCbk_u8 pfvidCallback)
{
	Can_pfvidBusOffCallback = pfvidCallback;	
}

void Can_vidBusoffRecovery(void)
{
    Can1_vidFromCommToReset();
    Can_vidInit();
}

uint8 Can_u8CanMsgSendIdDatDlc(uint8 u8BufNo, uint32 u32CanId, 
	                                          uint8* pu8Data, uint8 u8Dlc)
{
	boolean bRtn;
	uint8 u8FilledCounter;
	/* to consider place in diag part*/
	for(u8FilledCounter = 0u;u8FilledCounter < 8u;u8FilledCounter++)
	{
		if(u8FilledCounter < u8Dlc)
		{
			/*do nothing*/
		}
		else
		{
			pu8Data[u8FilledCounter] = 0x55u;
		}
	}

	/*use can2*/
	bRtn = Can_bSendMsg(1u, u8BufNo, u32CanId, u8Dlc, pu8Data);  
	return (uint8)bRtn;
}

extern Std_ReturnType Can_udtComStart(void)
{
    /*init trcv*/
    Can1Trcv_vidTrcvInitFct();
	return E_OK;
}

extern void Can_vidComStop(void)
{
	Can1Trcv_vidSleepTrcvFct();	
}

extern void Can_vidComSleep(void)
{
    Can1Trcv_vidSleepTrcvFct();	
}

extern Std_ReturnType Can_udtComWakeUp(void)
{
	/*wakeup trcv*/
    Can1Trcv_vidWakeUpTrcvFct();	
	return E_OK;	
}

/*-------------------------------- end of file -------------------------------*/
