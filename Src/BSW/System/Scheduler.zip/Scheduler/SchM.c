/******************************************************************************/
/*! \file
*
* \par
*   Internals of the module SchM. \n
*   This file contains the internals of the module SchM.  */
/******************************************************************************/

/******************************************************************************/
/*! \defgroup  SchM_Comp_Id SchM Component
* SchM Component.
* \{
*/

/*! \defgroup SchM_Module_Id SchM Module
* This is the grouping of SchM module members.
* \{
*/
/******************************************************************************/

/*! \Trace_To  :
* HVAC_SCD_Services_0023#01
* HVAC_SCD_Services_0024#01
* HVAC_SCD_Services_0025#01
* HVAC_SCD_Services_0026#01
* HVAC_SCD_Services_0027#01
*/

/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
/*! \Trace_To: HVAC_SCD_SYSTEM_0001#01  ,HVAC_SCD_SYSTEM_0002#01    */
#include "Std_Types.h"
#include "GPT.h"
#include "DIO.h"
#include "MCU_Manager.h"
#include "SchM.h"
#include "SchM_Tasks.h"
#include "osif.h"
#include "Cpu.h"


/******************************************************************************/
/* DEFINES                                                                    */
/******************************************************************************/

/******************************************************************************/
/*! \Description max value of timing counter.
 *  \Range  100
*******************************************************************************/
/*! \Trace_To: HVAC_SCD_SYSTEM_0045#01  ,HVAC_SCD_SYSTEM_0046#01    */
#define u8MAX_TASK_PERIOD                                         ((uint8)200)
#define u16NUMBER_REQ_TICKS                                     ((uint16)0x7CFF)
 /*****************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/

/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/

/******************************************************************************/
/* CONSTANTS DEFINITION                                                       */
/******************************************************************************/

/******************************************************************************/
/* DATA DEFINITION                                                            */
/******************************************************************************/
/*! \Trace_To: HVAC_SCD_SYSTEM_0047#01  ,HVAC_SCD_SYSTEM_0048#01
 * HVAC_SCD_SYSTEM_0048#01
 * HVAC_SCD_SYSTEM_0049#01
 * HVAC_SCD_SYSTEM_0055#01    */
//static boolean bTask1mFlag;
/******************************************************************************/
/*! \Description counter to switch exact task.
 *  \Range  0..10
*******************************************************************************/
static uint8 SchM_u8TimingCounter;

/******************************************************************************/
/*! \Description flag to active scheduler.
 *  \Range  0..1
*******************************************************************************/
static boolean SchM_bIsSchActive;

/******************************************************************************/
/*! \Description Indicates whether Task 1 should be called or not.
 *  \Range  0..1
*******************************************************************************/
static boolean SchM_bActivTask1;

/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/
static void vidTick( void );

/******************************************************************************/
/* LOCAL FUNCTION DEFINITION                                                  */
/******************************************************************************/
/******************************************************************************/
/*!Function :   vidTick                                                        */
/*! \Description function to inform that 1ms passed.
 *  \return      void.
 *  \Trace_To: HVAC_SCD_SYSTEM_0050#01  ,HVAC_SCD_SYSTEM_0051#01            */
/******************************************************************************/
static void vidTick( void )
{
  /*! If scheduler is active*/
  if (SchM_bIsSchActive == TRUE)
  {
    /*! Increment the SchM counter                                            */
    SchM_u8TimingCounter++;
    
    /*! If  modulus of scheduler counter /10 is equal to 0                    */
    if ( (SchM_u8TimingCounter % (uint8)10) == (uint8)0)
    {
       /*! Set Activate task 1 flag to TRUE                                   */
       SchM_bActivTask1 = TRUE;
    }

   
    /*! If scheduler counter equal to 200                                     */
    if ( SchM_u8TimingCounter >= u8MAX_TASK_PERIOD)
    {
       /*! Reinitialize timing counter                                        */
       SchM_u8TimingCounter = (uint8)0;
    }
      
  }

}
/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/

/******************************************************************************/
/*!Function :   SchM_vidGptCbk                                      */
/*! \Description call timer and refresh elmos and stepper.
    \return      void.
    \Trace_To: HVAC_SCD_SYSTEM_0018#01, HVAC_SCD_SYSTEM_0019#02 
*******************************************************************************/
void SchM_vidGptCbk( void )
{
    /*! call tick function */
    vidTick();
    

} 

/******************************************************************************/
/*!Function :   SchM_vidInit                                      */
/*! \Description initialize global variables.
    \return      void.
    \Trace_To: HVAC_SCD_SYSTEM_0006#01  ,HVAC_SCD_SYSTEM_0007#01
*******************************************************************************/
void SchM_vidInit( void )
{
  /*! Set the activate task 1 flag. */
  SchM_bActivTask1 = TRUE;

  /*! Initialize timing counter to 0*/
  SchM_u8TimingCounter = (uint8)0;

  /*! Initialize flag to active scheduler to False*/
  SchM_bIsSchActive = (boolean) FALSE;
  
  GPT_pfvideOSCallback = &SchM_vidGptCbk;

}

/******************************************************************************/
/*!Function :   SchM_vidScheduler                                            */
/*! \Description call tasks at its time.
    \return      void.
    \Trace_To: HVAC_SCD_SYSTEM_0008#01  ,HVAC_SCD_SYSTEM_0009#01
*******************************************************************************/
void SchM_vidScheduler( void )
{
    /*! Activate scheduler*/
    SchM_bIsSchActive = (boolean) TRUE;

    /*! Start Scheduler Timer */
    GPT_vidStartSchedTimer();

  /*!  While One                                                             */
  /* !Deviation : Inhibit PCLINT rule [716]: Infinite loop needed by the
                  Scheduler                                                  */
  /*lint -save -e716 */
  for(;;)
  {  
    switch (SchM_u8TimingCounter) 
    {
      /*! If scheduling timer equal 0*/
      case 0u:
      case 1u:
      case 2u:

      
        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;
          /*! call 10 and 50ms tasks*/
          SchM_vidTask1();
          
        }

        break ;
      
      /*! If scheduling timer equal 10 or 11 or 12*/
      case 10u:
      case 11u:
      case 12u:

      
        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 10 and 100ms tasks*/
          SchM_vidTask1();
          SchM_vidTask2();
          
        }
        break ;
      
      /*! If scheduling timer equal 20 or 21 or 22*/
      case 20u:
      case 21u:
      case 22u:

      
        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 1 ms task*/
          SchM_vidTask1();
          SchM_vidTask3();
        }
        break ;
        
      /*! If scheduling timer equal 30 or 31 or 32*/
      case 30u:
      case 31u:
      case 32u:

      
        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 1 ms task*/
          SchM_vidTask1();
        }
        break ;
      
      /*! If scheduling timer equal 40 or 41 or 42*/
      case 40u:
      case 41u:
      case 42u:

        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 1 ms task*/
          SchM_vidTask1();
        }
        break ;
        
      /*! If scheduling timer equal 50 or 51 or 52*/
      case 50u:
      case 51u:
      case 52u:

        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 10 and 50 ms tasks*/
          SchM_vidTask1();
          SchM_vidTask2();
        }
        break ;
      
      /*! If scheduling timer equal 60 or 61 or 62*/
      case 60u:
      case 61u:
      case 62u:

        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 10 ms task*/
          SchM_vidTask1();
        }
        break ;
       
       /*! If scheduling timer equal 70 or 71 or 72*/
      case 70u:
      case 71u:
      case 72u:

        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 10 ms task*/
          SchM_vidTask1();
        }
        break ;
        
        /*! If scheduling timer equal 80 or 81 or 82*/
      case 80u:
      case 81u:
      case 82u:

        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 10 ms task*/
          SchM_vidTask1();
        }
        break ;
        
        /*! If scheduling timer equal 90 or 91 or 92*/
      case 90u:
      case 91u:
      case 92u:

        /*! IF activate Task 1 Flag is set */
        if (SchM_bActivTask1 == TRUE)
        {
          /*! Reset the Activate Task 1 Flag. */
          SchM_bActivTask1 = FALSE;

          /*! call 10 ms task*/
          SchM_vidTask1();
            SchM_vidTask2();
        }
         break; 
        /*! If scheduling timer equal 100*/
      case 100u:
      case 101u:     
      case 102u:

      
         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 10ms tasks*/
           SchM_vidTask1();
         }  
         break;      
      case 110u:
      case 111u:     
      case 112u:

      
         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 10ms tasks*/
           SchM_vidTask1();
         }  
         break; 
      case 120u:
      case 121u:     
      case 122u:
      
     
         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
           /*! call 10ms tasks and 100ms tasks.*/
           SchM_vidTask1();
             SchM_vidTask3();
         }  
         break;      
      case 130u:
      case 131u:     
      case 132u:

         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
           /*! call 10ms tasks and 60ms tasks.*/
           SchM_vidTask1();
              SchM_vidTask2();
         }  
         break; 
      case 140u:
      case 141u:     
      case 142u:

      
         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 10ms tasks*/
           SchM_vidTask1();
         }  
         break;           
      case 150u:
      case 151u:     
      case 152u:

         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 10ms tasks*/
           SchM_vidTask1();
         }  
         break;      
      case 160u:
      case 161u:     
      case 162u:

         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 5ms tasks*/
           SchM_vidTask1();
         }  
         break;      
      case 170u:
      case 171u:     
      case 172u:

         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 10ms tasks*/
           SchM_vidTask1();
       SchM_vidTask2();
         }  
         break;      
      case 180u:
      case 181u:     
      case 182u:

         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 10ms tasks*/
           SchM_vidTask1();
         }  
         break;      
      case 190u:
      case 191u:     
      case 192u:

         if (SchM_bActivTask1 == TRUE)
         {
          /*! Reset the Activate Task 1 Flag. */
           SchM_bActivTask1 = FALSE;
          /*! call 5ms tasks*/
           SchM_vidTask1();
         }  
         break;      
        default :
        break ;
    }
   
  }    /* End of while one Loop */
  /*lint -restore */
}
/******************************************************************************/
/* !Function    : SchM_u8GetTimingCounter                                     */
/* !Description : getting the timing counter to be used as seed                 */
/* !Parameter[in]: void                                                       */
/* !Comment      :                                                            */
/*! \Trace_To:        HVAC_SCD_SYSTEM_0057#01                                    */
/******************************************************************************/
uint8 SchM_u8GetTimingCounter( void )
{
   uint8 u8TimingCounter ;
   u8TimingCounter = SchM_u8TimingCounter ;
   return (uint8)u8TimingCounter ;
}


/******************************************************************************/
/* !Function    : SchM_SetActive                                             */
/* !Description : Setting the schedule flg to active state                        */
/* !Parameter[in]: void                                                       */
/* !Comment      :                                                            */
/*! \Trace_To:        HVAC_SCD_SYSTEM_0057#01                                    */
/******************************************************************************/
void SchM_SetActive(void)
{
    /*! Activate scheduler*/
    SchM_bIsSchActive = (boolean) TRUE;
}

/** \} */ /* end of SchM module group */
/** \} */ /* end of SchM Component group */

/*-------------------------------- end of file -------------------------------*/
