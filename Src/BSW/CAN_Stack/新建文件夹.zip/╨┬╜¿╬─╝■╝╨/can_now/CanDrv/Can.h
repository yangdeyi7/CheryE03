#ifndef CAN_H
#define CAN_H

#include "device_registers.h"
#include "Std_Types.h"
#include "Can_Type.h"

#define MSG_BUF_SIZE  18    /* Msg Buffer Size. (CAN 2.0AB: 2 hdr +  16 data= 18 words) */
 
#define BTF_SHIFT      31
#define BTF(x)         (uint32_t)(x << BTF_SHIFT)
#define EPRESDIV_SHIFT 21
#define EPRESDIV(x)    (x << EPRESDIV_SHIFT)
#define EPSEG2_SHIFT    0
#define EPSEG2(x)      (x << EPSEG2_SHIFT)
#define EPSEG1_SHIFT    5
#define EPSEG1(x)      (x << EPSEG1_SHIFT)
#define EPROPSEG_SHIFT 10
#define EPROPSEG(x)    (x << EPROPSEG_SHIFT)
#define ERJW_SHIFT     16
#define ERJW(x)        (x << ERJW_SHIFT)

#define FPRESDIV_SHIFT 20
#define FPRESDIV(x)    (x << FPRESDIV_SHIFT)
#define FPSEG2_SHIFT    0
#define FPSEG2(x)      (x << FPSEG2_SHIFT)
#define FPSEG1_SHIFT    5
#define FPSEG1(x)      (x << FPSEG1_SHIFT)
#define FPROPSEG_SHIFT 10
#define FPROPSEG(x)    (x << FPROPSEG_SHIFT)
#define FRJW_SHIFT     16
#define FRJW(x)        (x << FRJW_SHIFT)

/*define TX BUF ID*/
#define TX_BUF0_ID    0u
#define TX_BUF1_ID    1u
/*define RX BUF ID*/
#define RX_BUF1_ID    1u
#define RX_BUF2_ID    2u
#define RX_BUF3_ID    3u
#define RX_BUF4_ID    4u
#define RX_BUF5_ID    5u
#define RX_BUF6_ID    6u
#define RX_BUF7_ID    7u
#define RX_BUF8_ID    8u
#define RX_BUF9_ID    9u
#define RX_BUF10_ID   10u
#define RX_BUF11_ID   11u
#define RX_BUF12_ID   12u
#define RX_BUF13_ID   13u
#define RX_BUF14_ID   14u
#define RX_BUF15_ID   15u
#define RX_BUF16_ID   16u
#define RX_BUF17_ID   17u
#define RX_BUF18_ID   18u
#define RX_BUF19_ID   19u
#define RX_BUF20_ID   20u
#define RX_BUF21_ID   21u
#define RX_BUF22_ID   22u
#define RX_BUF23_ID   23u
#define RX_BUF24_ID   24u
#define RX_BUF25_ID   25u
#define RX_BUF26_ID   26u
#define RX_BUF27_ID   27u
#define RX_BUF28_ID   28u
#define RX_BUF29_ID   29u
#define RX_BUF30_ID   30u
#define RX_BUF31_ID   31u


extern void   Can_vidInit(void);
extern uint32 Can_u32TrasnimitMsg(uint32 u32MsgBufId, Can_tstrPduType *pstrPduType);
#if 0
extern void   Can_vidSendMsgManage(void);
#endif
extern uint8  Can_u8GetBusStatus(void);

#endif

