#ifndef CANIF_CFG_H
#define CANIF_CFG_H

/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
#include "Can_Type.h"
#include "CanTp.h"

/******************************************************************************/
/* DEFINES                                                                    */
/******************************************************************************/
/*receive normal msg num*/
#define COM_RXPDUNUM  				(13u) 						
/*send normal msg num */
#define COM_TXPDUNUM  				(1u)  						


#define TP_RXPDUNUM   				(2u)						/*receive diag msg num*/
#define TP_MSG_TX_ID    			(0x7ABu) 					/*send diag msg id*/
#define TP_MSG_TX_BUFFER_ID 		(COM_TXPDUNUM) 	            /*for send diag msg tx buffer id*/


#define NODE_COMM_LOST_CYCLE        10u
#define NODE_COMM_RECOVER_CYCLE     5u

/**********************Can Send Message****************************************/
/*0x2FF*/
#define  SetSig_HVAC_1_Unused0(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused0 = x
#define  SetSig_HVAC_1_Unused1(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused1 = x
#define  SetSig_HVAC_1_Unused2(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused2 = x
#define  SetSig_HVAC_1_HVAC_1_TempSelect(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_TempSelect = x
#define  SetSig_HVAC_1_HVAC_1_ACmaxSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ACmaxSt = x
#define  SetSig_HVAC_1_HVAC_1_ACSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ACSt = x
#define  SetSig_HVAC_1_HVAC_1_RearDefrostSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_RearDefrostSt = x
#define  SetSig_HVAC_1_HVAC_1_TelematicsSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_TelematicsSt = x
#define  SetSig_HVAC_1_HVAC_1_WindExitMode(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WindExitMode = x
#define  SetSig_HVAC_1_HVAC_1_AutoSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AutoSt = x
#define  SetSig_HVAC_1_HVAC_1_DualSynSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_DualSynSt = x
#define  SetSig_HVAC_1_HVAC_1_PopupDisplayReq2(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PopupDisplayReq2 = x
#define  SetSig_HVAC_1_HVAC_1_PopupDisplayReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PopupDisplayReq = x
#define  SetSig_HVAC_1_HVAC_1_AirCirculationSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AirCirculationSt = x
#define  SetSig_HVAC_1_HVAC_1_IonMode(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_IonMode = x
#define  SetSig_HVAC_1_HVAC_1_DriverTempSelect(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_DriverTempSelect = x
#define  SetSig_HVAC_1_HVAC_1_IonPopReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_IonPopReq = x
#define  SetSig_HVAC_1_HVAC_1_CompensateWindExitMotorReq_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CompensateWindExitMotorReq_H = x
#define  SetSig_HVAC_1_HVAC_1_WindExitSpd(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WindExitSpd = x
#define  SetSig_HVAC_1_HVAC_1_PTCPwrConsmp_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCPwrConsmp_H = x
#define  SetSig_HVAC_1_Unused3(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused3 = x
#define  SetSig_HVAC_1_HVAC_1_CompensateWindExitMotorReqVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CompensateWindExitMotorReqVD = x
#define  SetSig_HVAC_1_HVAC_1_CompensateWindExitMotorReq_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CompensateWindExitMotorReq_L = x
#define  SetSig_HVAC_1_HVAC_1_PTCPwrConsmp_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCPwrConsmp_L = x
#define  SetSig_HVAC_1_HVAC_1_ComfortCfgSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ComfortCfgSt = x
#define  SetSig_HVAC_1_HVAC_1_PTCWaterTempWarn(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCWaterTempWarn = x
#define  SetSig_HVAC_1_HVAC_1_PsnTempSelect(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PsnTempSelect = x
#define  SetSig_HVAC_1_HVAC_1_AirCirCfgSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AirCirCfgSt = x
#define  SetSig_HVAC_1_HVAC_1_PTCCoolantTemp(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCCoolantTemp = x
#define  SetSig_HVAC_1_HVAC_1_AirQqualitySenSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AirQqualitySenSt = x
#define  SetSig_HVAC_1_HVAC_1_PTCOutletTargetTemp(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCOutletTargetTemp = x
#define  SetSig_HVAC_1_HVAC_1_ExterTempSnsDiag(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ExterTempSnsDiag = x
#define  SetSig_HVAC_1_HVAC_1_SolarFeaturesCfgSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_SolarFeaturesCfgSt = x
#define  SetSig_HVAC_1_HVAC_1_EvapratorSelfCleanSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EvapratorSelfCleanSt = x
#define  SetSig_HVAC_1_HVAC_1_SceneDisplayReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_SceneDisplayReq = x
#define  SetSig_HVAC_1_HVAC_1_FanspeedCfgSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FanspeedCfgSt = x
#define  SetSig_HVAC_1_HVAC_1_WindExitModeReqVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WindExitModeReqVD = x
#define  SetSig_HVAC_1_HVAC_1_WindExitModeReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WindExitModeReq = x
#define  SetSig_HVAC_1_HVAC_1_EngIdleStopProhibitReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EngIdleStopProhibitReq = x
#define  SetSig_HVAC_1_HVAC_1_DisinfectenSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_DisinfectenSt = x
#define  SetSig_HVAC_1_HVAC_1_WindExitSpdLvl(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WindExitSpdLvl = x
#define  SetSig_HVAC_1_Unused4(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused4 = x
#define  SetSig_HVAC_1_HVAC_1_CorrectedExterTemp(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CorrectedExterTemp = x
#define  SetSig_HVAC_1_HVAC_1_PTCHeatingReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCHeatingReq = x
#define  SetSig_HVAC_1_HVAC_1_CorrectedExterTempVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CorrectedExterTempVD = x
#define  SetSig_HVAC_1_HVAC_1_DrAMDoorPostion(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_DrAMDoorPostion = x
#define  SetSig_HVAC_1_HVAC_1_HeaterPumpSpdSet(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_HeaterPumpSpdSet = x
#define  SetSig_HVAC_1_HVAC_1_DrAMDoorPostionVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_DrAMDoorPostionVD = x
#define  SetSig_HVAC_1_HVAC_1_PaAMDoorPostion(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PaAMDoorPostion = x
#define  SetSig_HVAC_1_HVAC_1_PTCSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCSt = x
#define  SetSig_HVAC_1_HVAC_1_PTCFault(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCFault = x
#define  SetSig_HVAC_1_HVAC_1_ECPFault(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECPFault = x
#define  SetSig_HVAC_1_HVAC_1_AirCompressorReqVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AirCompressorReqVD = x
#define  SetSig_HVAC_1_HVAC_1_AirCompressorReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AirCompressorReq = x
#define  SetSig_HVAC_1_HVAC_1_DualCircuSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_DualCircuSt = x
#define  SetSig_HVAC_1_HVAC_1_PaAMDoorPostionVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PaAMDoorPostionVD = x
#define  SetSig_HVAC_1_HVAC_1_ECPTargetSpd(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECPTargetSpd = x
#define  SetSig_HVAC_1_HVAC_1_ECPwrLimit(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECPwrLimit = x
#define  SetSig_HVAC_1_HVAC_1_CoolFanDutyCycleReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CoolFanDutyCycleReq = x
#define  SetSig_HVAC_1_HVAC_1_PTCCurSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCCurSt = x
#define  SetSig_HVAC_1_HVAC_1_EVAvalve(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVAvalve = x
#define  SetSig_HVAC_1_HVAC_1_CondDefSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CondDefSt = x
#define  SetSig_HVAC_1_HVAC_1_HighSpdFanReqVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_HighSpdFanReqVD = x
#define  SetSig_HVAC_1_HVAC_1_HighSpdFanReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_HighSpdFanReq = x
#define  SetSig_HVAC_1_HVAC_1_CoolFanDutyCyclerReqVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CoolFanDutyCyclerReqVD = x
#define  SetSig_HVAC_1_HVAC_1_StsCabinHeatPrioReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_StsCabinHeatPrioReq = x
#define  SetSig_HVAC_1_HVAC_1_StsCanbinCoolPrioReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_StsCanbinCoolPrioReq = x
#define  SetSig_HVAC_1_HVAC_1_ActGrillDutyCycleReqVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ActGrillDutyCycleReqVD = x
#define  SetSig_HVAC_1_HVAC_1_ActGrillDutyCycleReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ActGrillDutyCycleReq = x
#define  SetSig_HVAC_1_Unused5(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused5 = x
#define  SetSig_HVAC_1_Unused6(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused6 = x
#define  SetSig_HVAC_1_HVAC_1_PM25Value_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25Value_H = x
#define  SetSig_HVAC_1_HVAC_1_PM25CleanReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25CleanReq = x
#define  SetSig_HVAC_1_HVAC_1_PM10ValueVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM10ValueVD = x
#define  SetSig_HVAC_1_HVAC_1_PM25ValueVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25ValueVD = x
#define  SetSig_HVAC_1_HVAC_1_RefrigerantPrVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_RefrigerantPrVD = x
#define  SetSig_HVAC_1_HVAC_1_RawExterTempVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_RawExterTempVD = x
#define  SetSig_HVAC_1_HVAC_1_RawCabinTempVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_RawCabinTempVD = x
#define  SetSig_HVAC_1_HVAC_1_PM25Value_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25Value_L = x
#define  SetSig_HVAC_1_HVAC_1_PM10_Value_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM10_Value_H = x
#define  SetSig_HVAC_1_HVAC_1_FraganceTasteReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceTasteReq = x
#define  SetSig_HVAC_1_HVAC_1_FraganceRatioWarn(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceRatioWarn = x
#define  SetSig_HVAC_1_HVAC_1_IonModeReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_IonModeReq = x
#define  SetSig_HVAC_1_HVAC_1_PM10_Value_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM10_Value_L = x
#define  SetSig_HVAC_1_HVAC_1_FraganceTaste(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceTaste = x
#define  SetSig_HVAC_1_HVAC_1_FragTaste1RemanentRatio(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FragTaste1RemanentRatio = x
#define  SetSig_HVAC_1_HVAC_1_FraganceConcentrationReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceConcentrationReq = x
#define  SetSig_HVAC_1_HVAC_1_FragTaste2RemanentRatio(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FragTaste2RemanentRatio = x
#define  SetSig_HVAC_1_HVAC_1_FraganceBoxID(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceBoxID = x
#define  SetSig_HVAC_1_HVAC_1_FraganceConcentration(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceConcentration = x
#define  SetSig_HVAC_1_HVAC_1_OHX_EXV_PstReq_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_OHX_EXV_PstReq_H = x
#define  SetSig_HVAC_1_HVAC_1_UVCSwith(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_UVCSwith = x
#define  SetSig_HVAC_1_HVAC_1_FragTaste3RemanentRatio(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FragTaste3RemanentRatio = x
#define  SetSig_HVAC_1_HVAC_1_OHX_EXV_PstReq_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_OHX_EXV_PstReq_L = x
#define  SetSig_HVAC_1_HVAC_1_CHI_EXV_PstReq_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CHI_EXV_PstReq_H = x
#define  SetSig_HVAC_1_HVAC_1_EVA_EXV_PstReq_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVA_EXV_PstReq_H = x
#define  SetSig_HVAC_1_HVAC_1_CHI_EXV_PstReq_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CHI_EXV_PstReq_L = x
#define  SetSig_HVAC_1_HVAC_1_HeataValve(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_HeataValve = x
#define  SetSig_HVAC_1_HVAC_1_IconInletValve(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_IconInletValve = x
#define  SetSig_HVAC_1_HVAC_1_CoolingValve(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CoolingValve = x
#define  SetSig_HVAC_1_HVAC_1_DehumidifyValve(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_DehumidifyValve = x
#define  SetSig_HVAC_1_HVAC_1_EVA_EXV_PstReq_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVA_EXV_PstReq_L = x
#define  SetSig_HVAC_1_HVAC_1_ECV_PosnSet(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECV_PosnSet = x
#define  SetSig_HVAC_1_HVAC_1_WarmupReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WarmupReq = x
#define  SetSig_HVAC_1_HVAC_1_UnlockVentilationSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_UnlockVentilationSt = x
#define  SetSig_HVAC_1_HVAC_1_WasteHeatTempMinReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WasteHeatTempMinReq = x
#define  SetSig_HVAC_1_HVAC_1_ECP_EXV_PstReq_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECP_EXV_PstReq_H = x
#define  SetSig_HVAC_1_HVAC_1_HeatPumpMode(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_HeatPumpMode = x
#define  SetSig_HVAC_1_HVAC_1_PM25CirReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25CirReq = x
#define  SetSig_HVAC_1_HVAC_1_ECP_EXV_PstReq_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECP_EXV_PstReq_L = x
#define  SetSig_HVAC_1_HVAC_1_ECPPwrConsump_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECPPwrConsump_H = x
#define  SetSig_HVAC_1_HVAC_1_WasteHeatTempMaxReq_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WasteHeatTempMaxReq_H = x
#define  SetSig_HVAC_1_HVAC_1_ECPPwrConsump_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECPPwrConsump_L = x
#define  SetSig_HVAC_1_HVAC_1_RawEvaTempVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_RawEvaTempVD = x
#define  SetSig_HVAC_1_HVAC_1_CabinHeatReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CabinHeatReq = x
#define  SetSig_HVAC_1_Unused7(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused7 = x
#define  SetSig_HVAC_1_HVAC_1_WasteHeatTempMaxReq_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_WasteHeatTempMaxReq_L = x
#define  SetSig_HVAC_1_Unused8(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused8 = x
#define  SetSig_HVAC_1_HVAC_1_PM25ValueOut_H(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25ValueOut_H = x
#define  SetSig_HVAC_1_HVAC_1_AirCirculationReqVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AirCirculationReqVD = x
#define  SetSig_HVAC_1_Unused9(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused9 = x
#define  SetSig_HVAC_1_HVAC_1_PM25ValueOutVD(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25ValueOutVD = x
#define  SetSig_HVAC_1_HVAC_1_PM25ValueOut_L(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25ValueOut_L = x
#define  SetSig_HVAC_1_HVAC_1_AirCirculationReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_AirCirculationReq = x
#define  SetSig_HVAC_1_HVAC_1_FraganceTasteRemanentRatioResetReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceTasteRemanentRatioResetReq = x
#define  SetSig_HVAC_1_HVAC_1_FraganceSwitchSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_FraganceSwitchSt = x
#define  SetSig_HVAC_1_HVAC_1_BlowerSt(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_BlowerSt = x
#define  SetSig_HVAC_1_HVAC_1_PTCRsestReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCRsestReq = x
#define  SetSig_HVAC_1_HVAC_1_PTCOnReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCOnReq = x
#define  SetSig_HVAC_1_HVAC_1_ECPDriveReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECPDriveReq = x
#define  SetSig_HVAC_1_HVAC_1_PM25WorkCmd(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PM25WorkCmd = x
#define  SetSig_HVAC_1_HVAC_1_EVA_EXVStallDetEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVA_EXVStallDetEnable = x
#define  SetSig_HVAC_1_HVAC_1_OHX_EXVStallDetEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_OHX_EXVStallDetEnable = x
#define  SetSig_HVAC_1_HVAC_1_OHX_EXVMoveEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_OHX_EXVMoveEnable = x
#define  SetSig_HVAC_1_HVAC_1_PTCDischargeReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCDischargeReq = x
#define  SetSig_HVAC_1_HVAC_1_PTCEmergencyOffReq(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_PTCEmergencyOffReq = x
#define  SetSig_HVAC_1_HVAC_1_EVA_EXVMoveEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVA_EXVMoveEnable = x
#define  SetSig_HVAC_1_HVAC_1_OHX_EXVLmhTimeCinfg(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_OHX_EXVLmhTimeCinfg = x
#define  SetSig_HVAC_1_HVAC_1_OHX_EXVMoveCtr(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_OHX_EXVMoveCtr = x
#define  SetSig_HVAC_1_HVAC_1_OHX_EXVInitial(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_OHX_EXVInitial = x
#define  SetSig_HVAC_1_HVAC_1_ECP_EXVMoveEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECP_EXVMoveEnable = x
#define  SetSig_HVAC_1_HVAC_1_EVA_EXVLmhTimeCinfg(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVA_EXVLmhTimeCinfg = x
#define  SetSig_HVAC_1_HVAC_1_EVA_EXVMoveCtr(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVA_EXVMoveCtr = x
#define  SetSig_HVAC_1_HVAC_1_EVA_EXVInitial(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_EVA_EXVInitial = x
#define  SetSig_HVAC_1_HVAC_1_ECP_EXVLmhTimeCinfg(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECP_EXVLmhTimeCinfg = x
#define  SetSig_HVAC_1_HVAC_1_ECP_EXVInitial(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECP_EXVInitial = x
#define  SetSig_HVAC_1_HVAC_1_ECP_EXVStallDetEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECP_EXVStallDetEnable = x
#define  SetSig_HVAC_1_HVAC_1_CHI_EXVMoveCtr(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CHI_EXVMoveCtr = x
#define  SetSig_HVAC_1_HVAC_1_CHI_EXVInitial(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CHI_EXVInitial = x
#define  SetSig_HVAC_1_HVAC_1_CHI_EXVStallDetEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CHI_EXVStallDetEnable = x
#define  SetSig_HVAC_1_HVAC_1_CHI_EXVMoveEnable(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CHI_EXVMoveEnable = x
#define  SetSig_HVAC_1_HVAC_1_ECP_EXVMoveCtr(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_ECP_EXVMoveCtr = x
#define  SetSig_HVAC_1_Unused10(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused10 = x
#define  SetSig_HVAC_1_HVAC_1_CHI_EXVLmhTimeCinfg(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.HVAC_1_CHI_EXVLmhTimeCinfg = x
#define  SetSig_HVAC_1_Unused11(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused11 = x
#define  SetSig_HVAC_1_Unused12(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused12 = x
#define  SetSig_HVAC_1_Unused13(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused13 = x
#define  SetSig_HVAC_1_Unused14(x) CanIf_uniTxMsgType_HVAC_1.Ipdu.Unused14 = x

/**********************Can Receive Message*************************************/
/*0x198*/
#define GetSig_BMC_1_Unused0() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused0
#define GetSig_BMC_1_Unused1() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused1
#define GetSig_BMC_1_Unused2() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused2
#define GetSig_BMC_1_Unused3() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused3
#define GetSig_BMC_1_Unused4() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused4
#define GetSig_BMC_1_Unused5() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused5
#define GetSig_BMC_1_BMC_BatVolt_H() CanIf_uniRxMsgType_BMC_1.Ipdu.BMC_BatVolt_H
#define GetSig_BMC_1_Unused6() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused6
#define GetSig_BMC_1_Unused7() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused7
#define GetSig_BMC_1_BMC_BatVolt_L() CanIf_uniRxMsgType_BMC_1.Ipdu.BMC_BatVolt_L
#define GetSig_BMC_1_Unused8() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused8
#define GetSig_BMC_1_Unused9() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused9
#define GetSig_BMC_1_Unused10() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused10
#define GetSig_BMC_1_Unused11() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused11
#define GetSig_BMC_1_Unused12() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused12
#define GetSig_BMC_1_Unused13() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused13
#define GetSig_BMC_1_Unused14() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused14
#define GetSig_BMC_1_Unused15() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused15
#define GetSig_BMC_1_Unused16() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused16
#define GetSig_BMC_1_Unused17() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused17
#define GetSig_BMC_1_Unused18() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused18
#define GetSig_BMC_1_Unused19() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused19
#define GetSig_BMC_1_Unused20() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused20
#define GetSig_BMC_1_Unused21() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused21
#define GetSig_BMC_1_Unused22() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused22
#define GetSig_BMC_1_Unused23() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused23
#define GetSig_BMC_1_Unused24() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused24
#define GetSig_BMC_1_Unused25() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused25
#define GetSig_BMC_1_Unused26() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused26
#define GetSig_BMC_1_Unused27() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused27
#define GetSig_BMC_1_Unused28() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused28
#define GetSig_BMC_1_Unused29() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused29
#define GetSig_BMC_1_Unused30() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused30
#define GetSig_BMC_1_Unused31() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused31
#define GetSig_BMC_1_Unused32() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused32
#define GetSig_BMC_1_Unused33() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused33
#define GetSig_BMC_1_Unused34() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused34
#define GetSig_BMC_1_Unused35() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused35
#define GetSig_BMC_1_Unused36() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused36
#define GetSig_BMC_1_Unused37() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused37
#define GetSig_BMC_1_Unused38() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused38
#define GetSig_BMC_1_Unused39() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused39
#define GetSig_BMC_1_Unused40() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused40
#define GetSig_BMC_1_Unused41() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused41
#define GetSig_BMC_1_Unused42() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused42
#define GetSig_BMC_1_Unused43() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused43
#define GetSig_BMC_1_Unused44() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused44
#define GetSig_BMC_1_Unused45() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused45
#define GetSig_BMC_1_Unused46() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused46
#define GetSig_BMC_1_Unused47() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused47
#define GetSig_BMC_1_Unused48() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused48
#define GetSig_BMC_1_Unused49() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused49
#define GetSig_BMC_1_Unused50() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused50
#define GetSig_BMC_1_Unused51() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused51
#define GetSig_BMC_1_Unused52() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused52
#define GetSig_BMC_1_Unused53() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused53
#define GetSig_BMC_1_Unused54() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused54
#define GetSig_BMC_1_Unused55() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused55
#define GetSig_BMC_1_Unused56() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused56
#define GetSig_BMC_1_Unused57() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused57
#define GetSig_BMC_1_Unused58() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused58
#define GetSig_BMC_1_Unused59() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused59
#define GetSig_BMC_1_Unused60() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused60
#define GetSig_BMC_1_Unused61() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused61
#define GetSig_BMC_1_Unused62() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused62
#define GetSig_BMC_1_Unused63() CanIf_uniRxMsgType_BMC_1.Ipdu.Unused63

/*0x32C*/
#define GetSig_BMC_22_Unused0() CanIf_uniRxMsgType_BMC22.Ipdu.Unused0
#define GetSig_BMC_22_Unused1() CanIf_uniRxMsgType_BMC22.Ipdu.Unused1
#define GetSig_BMC_22_Unused2() CanIf_uniRxMsgType_BMC22.Ipdu.Unused2
#define GetSig_BMC_22_Unused3() CanIf_uniRxMsgType_BMC22.Ipdu.Unused3
#define GetSig_BMC_22_Unused4() CanIf_uniRxMsgType_BMC22.Ipdu.Unused4
#define GetSig_BMC_22_Unused5() CanIf_uniRxMsgType_BMC22.Ipdu.Unused5
#define GetSig_BMC_22_Unused6() CanIf_uniRxMsgType_BMC22.Ipdu.Unused6
#define GetSig_BMC_22_Unused7() CanIf_uniRxMsgType_BMC22.Ipdu.Unused7
#define GetSig_BMC_22_Unused8() CanIf_uniRxMsgType_BMC22.Ipdu.Unused8
#define GetSig_BMC_22_Unused9() CanIf_uniRxMsgType_BMC22.Ipdu.Unused9
#define GetSig_BMC_22_Unused10() CanIf_uniRxMsgType_BMC22.Ipdu.Unused10
#define GetSig_BMC_22_Unused11() CanIf_uniRxMsgType_BMC22.Ipdu.Unused11
#define GetSig_BMC_22_Unused12() CanIf_uniRxMsgType_BMC22.Ipdu.Unused12
#define GetSig_BMC_22_Unused13() CanIf_uniRxMsgType_BMC22.Ipdu.Unused13
#define GetSig_BMC_22_Unused14() CanIf_uniRxMsgType_BMC22.Ipdu.Unused14
#define GetSig_BMC_22_Unused15() CanIf_uniRxMsgType_BMC22.Ipdu.Unused15
#define GetSig_BMC_22_BMC_BattSocDisp_H() CanIf_uniRxMsgType_BMC22.Ipdu.BMC_BattSocDisp_H
#define GetSig_BMC_22_Unused16() CanIf_uniRxMsgType_BMC22.Ipdu.Unused16
#define GetSig_BMC_22_Unused17() CanIf_uniRxMsgType_BMC22.Ipdu.Unused17
#define GetSig_BMC_22_BMC_BattSocDisp_L() CanIf_uniRxMsgType_BMC22.Ipdu.BMC_BattSocDisp_L
#define GetSig_BMC_22_Unused18() CanIf_uniRxMsgType_BMC22.Ipdu.Unused18
#define GetSig_BMC_22_Unused19() CanIf_uniRxMsgType_BMC22.Ipdu.Unused19
#define GetSig_BMC_22_Unused20() CanIf_uniRxMsgType_BMC22.Ipdu.Unused20
#define GetSig_BMC_22_Unused21() CanIf_uniRxMsgType_BMC22.Ipdu.Unused21
#define GetSig_BMC_22_Unused22() CanIf_uniRxMsgType_BMC22.Ipdu.Unused22
#define GetSig_BMC_22_Unused23() CanIf_uniRxMsgType_BMC22.Ipdu.Unused23
#define GetSig_BMC_22_Unused24() CanIf_uniRxMsgType_BMC22.Ipdu.Unused24
#define GetSig_BMC_22_Unused25() CanIf_uniRxMsgType_BMC22.Ipdu.Unused25
#define GetSig_BMC_22_Unused26() CanIf_uniRxMsgType_BMC22.Ipdu.Unused26
#define GetSig_BMC_22_Unused27() CanIf_uniRxMsgType_BMC22.Ipdu.Unused27
#define GetSig_BMC_22_Unused28() CanIf_uniRxMsgType_BMC22.Ipdu.Unused28
#define GetSig_BMC_22_Unused29() CanIf_uniRxMsgType_BMC22.Ipdu.Unused29
#define GetSig_BMC_22_Unused30() CanIf_uniRxMsgType_BMC22.Ipdu.Unused30
#define GetSig_BMC_22_Unused31() CanIf_uniRxMsgType_BMC22.Ipdu.Unused31
#define GetSig_BMC_22_Unused32() CanIf_uniRxMsgType_BMC22.Ipdu.Unused32
#define GetSig_BMC_22_Unused33() CanIf_uniRxMsgType_BMC22.Ipdu.Unused33
#define GetSig_BMC_22_Unused34() CanIf_uniRxMsgType_BMC22.Ipdu.Unused34
#define GetSig_BMC_22_Unused35() CanIf_uniRxMsgType_BMC22.Ipdu.Unused35
#define GetSig_BMC_22_Unused36() CanIf_uniRxMsgType_BMC22.Ipdu.Unused36
#define GetSig_BMC_22_Unused37() CanIf_uniRxMsgType_BMC22.Ipdu.Unused37
#define GetSig_BMC_22_Unused38() CanIf_uniRxMsgType_BMC22.Ipdu.Unused38
#define GetSig_BMC_22_Unused39() CanIf_uniRxMsgType_BMC22.Ipdu.Unused39
#define GetSig_BMC_22_Unused40() CanIf_uniRxMsgType_BMC22.Ipdu.Unused40
#define GetSig_BMC_22_Unused41() CanIf_uniRxMsgType_BMC22.Ipdu.Unused41
#define GetSig_BMC_22_Unused42() CanIf_uniRxMsgType_BMC22.Ipdu.Unused42
#define GetSig_BMC_22_Unused43() CanIf_uniRxMsgType_BMC22.Ipdu.Unused43
#define GetSig_BMC_22_Unused44() CanIf_uniRxMsgType_BMC22.Ipdu.Unused44
#define GetSig_BMC_22_Unused45() CanIf_uniRxMsgType_BMC22.Ipdu.Unused45
#define GetSig_BMC_22_Unused46() CanIf_uniRxMsgType_BMC22.Ipdu.Unused46
#define GetSig_BMC_22_Unused47() CanIf_uniRxMsgType_BMC22.Ipdu.Unused47
#define GetSig_BMC_22_Unused48() CanIf_uniRxMsgType_BMC22.Ipdu.Unused48
#define GetSig_BMC_22_Unused49() CanIf_uniRxMsgType_BMC22.Ipdu.Unused49
#define GetSig_BMC_22_Unused50() CanIf_uniRxMsgType_BMC22.Ipdu.Unused50
#define GetSig_BMC_22_Unused51() CanIf_uniRxMsgType_BMC22.Ipdu.Unused51
#define GetSig_BMC_22_Unused52() CanIf_uniRxMsgType_BMC22.Ipdu.Unused52
#define GetSig_BMC_22_Unused53() CanIf_uniRxMsgType_BMC22.Ipdu.Unused53
#define GetSig_BMC_22_Unused54() CanIf_uniRxMsgType_BMC22.Ipdu.Unused54
#define GetSig_BMC_22_Unused55() CanIf_uniRxMsgType_BMC22.Ipdu.Unused55
#define GetSig_BMC_22_Unused56() CanIf_uniRxMsgType_BMC22.Ipdu.Unused56
#define GetSig_BMC_22_Unused57() CanIf_uniRxMsgType_BMC22.Ipdu.Unused57
#define GetSig_BMC_22_Unused58() CanIf_uniRxMsgType_BMC22.Ipdu.Unused58
#define GetSig_BMC_22_Unused59() CanIf_uniRxMsgType_BMC22.Ipdu.Unused59
#define GetSig_BMC_22_Unused60() CanIf_uniRxMsgType_BMC22.Ipdu.Unused60
#define GetSig_BMC_22_Unused61() CanIf_uniRxMsgType_BMC22.Ipdu.Unused61
#define GetSig_BMC_22_Unused62() CanIf_uniRxMsgType_BMC22.Ipdu.Unused62
#define GetSig_BMC_22_Unused63() CanIf_uniRxMsgType_BMC22.Ipdu.Unused63


/*0x3B0*/
#define GetSig_BMC_3_Unused0() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused0
#define GetSig_BMC_3_Unused1() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused1
#define GetSig_BMC_3_Unused2() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused2
#define GetSig_BMC_3_Unused3() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused3
#define GetSig_BMC_3_BMC_BattTempMin_H() CanIf_uniRxMsgType_BMC_3.Ipdu.BMC_BattTempMin_H
#define GetSig_BMC_3_Unused4() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused4
#define GetSig_BMC_3_BMC_BattTempAvg_H() CanIf_uniRxMsgType_BMC_3.Ipdu.BMC_BattTempAvg_H
#define GetSig_BMC_3_BMC_BattTempMin_L() CanIf_uniRxMsgType_BMC_3.Ipdu.BMC_BattTempMin_L
#define GetSig_BMC_3_BMC_BattTempMax_H() CanIf_uniRxMsgType_BMC_3.Ipdu.BMC_BattTempMax_H
#define GetSig_BMC_3_BMC_BattTempAvg_L() CanIf_uniRxMsgType_BMC_3.Ipdu.BMC_BattTempAvg_L
#define GetSig_BMC_3_Unused5() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused5
#define GetSig_BMC_3_BMC_BattTempMax_L() CanIf_uniRxMsgType_BMC_3.Ipdu.BMC_BattTempMax_L
#define GetSig_BMC_3_Unused6() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused6
#define GetSig_BMC_3_Unused7() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused7
#define GetSig_BMC_3_Unused8() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused8
#define GetSig_BMC_3_Unused9() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused9
#define GetSig_BMC_3_Unused10() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused10
#define GetSig_BMC_3_Unused11() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused11
#define GetSig_BMC_3_Unused12() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused12
#define GetSig_BMC_3_Unused13() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused13
#define GetSig_BMC_3_Unused14() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused14
#define GetSig_BMC_3_Unused15() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused15
#define GetSig_BMC_3_Unused16() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused16
#define GetSig_BMC_3_Unused17() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused17
#define GetSig_BMC_3_Unused18() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused18
#define GetSig_BMC_3_Unused19() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused19
#define GetSig_BMC_3_Unused20() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused20
#define GetSig_BMC_3_Unused21() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused21
#define GetSig_BMC_3_Unused22() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused22
#define GetSig_BMC_3_Unused23() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused23
#define GetSig_BMC_3_Unused24() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused24
#define GetSig_BMC_3_Unused25() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused25
#define GetSig_BMC_3_Unused26() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused26
#define GetSig_BMC_3_Unused27() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused27
#define GetSig_BMC_3_Unused28() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused28
#define GetSig_BMC_3_Unused29() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused29
#define GetSig_BMC_3_Unused30() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused30
#define GetSig_BMC_3_Unused31() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused31
#define GetSig_BMC_3_Unused32() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused32
#define GetSig_BMC_3_Unused33() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused33
#define GetSig_BMC_3_Unused34() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused34
#define GetSig_BMC_3_Unused35() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused35
#define GetSig_BMC_3_Unused36() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused36
#define GetSig_BMC_3_Unused37() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused37
#define GetSig_BMC_3_Unused38() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused38
#define GetSig_BMC_3_Unused39() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused39
#define GetSig_BMC_3_Unused40() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused40
#define GetSig_BMC_3_Unused41() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused41
#define GetSig_BMC_3_Unused42() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused42
#define GetSig_BMC_3_Unused43() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused43
#define GetSig_BMC_3_Unused44() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused44
#define GetSig_BMC_3_Unused45() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused45
#define GetSig_BMC_3_Unused46() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused46
#define GetSig_BMC_3_Unused47() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused47
#define GetSig_BMC_3_Unused48() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused48
#define GetSig_BMC_3_Unused49() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused49
#define GetSig_BMC_3_Unused50() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused50
#define GetSig_BMC_3_Unused51() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused51
#define GetSig_BMC_3_Unused52() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused52
#define GetSig_BMC_3_Unused53() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused53
#define GetSig_BMC_3_Unused54() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused54
#define GetSig_BMC_3_Unused55() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused55
#define GetSig_BMC_3_Unused56() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused56
#define GetSig_BMC_3_Unused57() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused57
#define GetSig_BMC_3_Unused58() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused58
#define GetSig_BMC_3_Unused59() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused59
#define GetSig_BMC_3_Unused60() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused60
#define GetSig_BMC_3_Unused61() CanIf_uniRxMsgType_BMC_3.Ipdu.Unused61



/*0x448*/
#define GetSig_BMC_4_Unused0() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused0
#define GetSig_BMC_4_Unused1() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused1
#define GetSig_BMC_4_Unused2() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused2
#define GetSig_BMC_4_Unused3() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused3
#define GetSig_BMC_4_Unused4() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused4
#define GetSig_BMC_4_Unused5() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused5
#define GetSig_BMC_4_Unused6() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused6
#define GetSig_BMC_4_BMC_CoolantTargTemp_H() CanIf_uniRxMsgType_BMC_4.Ipdu.BMC_CoolantTargTemp_H
#define GetSig_BMC_4_Unused7() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused7
#define GetSig_BMC_4_Unused8() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused8
#define GetSig_BMC_4_BMC_CoolantTargTemp_L() CanIf_uniRxMsgType_BMC_4.Ipdu.BMC_CoolantTargTemp_L
#define GetSig_BMC_4_Unused9() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused9
#define GetSig_BMC_4_Unused10() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused10
#define GetSig_BMC_4_Unused11() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused11
#define GetSig_BMC_4_Unused12() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused12
#define GetSig_BMC_4_Unused13() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused13
#define GetSig_BMC_4_Unused14() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused14
#define GetSig_BMC_4_Unused15() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused15
#define GetSig_BMC_4_Unused16() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused16
#define GetSig_BMC_4_Unused17() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused17
#define GetSig_BMC_4_Unused18() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused18
#define GetSig_BMC_4_Unused19() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused19
#define GetSig_BMC_4_Unused20() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused20
#define GetSig_BMC_4_Unused21() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused21
#define GetSig_BMC_4_Unused22() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused22
#define GetSig_BMC_4_Unused23() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused23
#define GetSig_BMC_4_Unused24() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused24
#define GetSig_BMC_4_Unused25() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused25
#define GetSig_BMC_4_Unused26() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused26
#define GetSig_BMC_4_Unused27() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused27
#define GetSig_BMC_4_Unused28() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused28
#define GetSig_BMC_4_Unused29() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused29
#define GetSig_BMC_4_Unused30() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused30
#define GetSig_BMC_4_Unused31() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused31
#define GetSig_BMC_4_Unused32() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused32
#define GetSig_BMC_4_Unused33() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused33
#define GetSig_BMC_4_Unused34() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused34
#define GetSig_BMC_4_Unused35() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused35
#define GetSig_BMC_4_Unused36() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused36
#define GetSig_BMC_4_Unused37() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused37
#define GetSig_BMC_4_Unused38() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused38
#define GetSig_BMC_4_Unused39() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused39
#define GetSig_BMC_4_Unused40() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused40
#define GetSig_BMC_4_Unused41() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused41
#define GetSig_BMC_4_Unused42() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused42
#define GetSig_BMC_4_Unused43() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused43
#define GetSig_BMC_4_Unused44() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused44
#define GetSig_BMC_4_Unused45() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused45
#define GetSig_BMC_4_Unused46() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused46
#define GetSig_BMC_4_Unused47() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused47
#define GetSig_BMC_4_Unused48() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused48
#define GetSig_BMC_4_Unused49() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused49
#define GetSig_BMC_4_Unused50() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused50
#define GetSig_BMC_4_Unused51() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused51
#define GetSig_BMC_4_Unused52() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused52
#define GetSig_BMC_4_Unused53() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused53
#define GetSig_BMC_4_Unused54() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused54
#define GetSig_BMC_4_Unused55() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused55
#define GetSig_BMC_4_Unused56() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused56
#define GetSig_BMC_4_Unused57() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused57
#define GetSig_BMC_4_Unused58() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused58
#define GetSig_BMC_4_Unused59() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused59
#define GetSig_BMC_4_Unused60() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused60
#define GetSig_BMC_4_Unused61() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused61
#define GetSig_BMC_4_Unused62() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused62
#define GetSig_BMC_4_Unused63() CanIf_uniRxMsgType_BMC_4.Ipdu.Unused63


/*0X268*/
#define GetSig_CCU_1_Unused0() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused0
#define GetSig_CCU_1_Unused1() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused1
#define GetSig_CCU_1_Unused2() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused2
#define GetSig_CCU_1_PowerModeSt() CanIf_uniRxMsgType_CCU_1.Ipdu.PowerModeSt
#define GetSig_CCU_1_Unused3() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused3
#define GetSig_CCU_1_Unused4() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused4
#define GetSig_CCU_1_Unused5() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused5
#define GetSig_CCU_1_Unused6() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused6
#define GetSig_CCU_1_Unused7() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused7
#define GetSig_CCU_1_Unused8() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused8
#define GetSig_CCU_1_Unused9() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused9
#define GetSig_CCU_1_Unused10() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused10
#define GetSig_CCU_1_Unused11() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused11
#define GetSig_CCU_1_Unused12() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused12
#define GetSig_CCU_1_Unused13() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused13
#define GetSig_CCU_1_Unused14() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused14
#define GetSig_CCU_1_Unused15() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused15
#define GetSig_CCU_1_Unused16() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused16
#define GetSig_CCU_1_Unused17() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused17
#define GetSig_CCU_1_Unused18() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused18
#define GetSig_CCU_1_Unused19() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused19
#define GetSig_CCU_1_Unused20() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused20
#define GetSig_CCU_1_Unused21() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused21
#define GetSig_CCU_1_Unused22() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused22
#define GetSig_CCU_1_Unused23() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused23
#define GetSig_CCU_1_Unused24() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused24
#define GetSig_CCU_1_Unused25() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused25
#define GetSig_CCU_1_Unused26() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused26
#define GetSig_CCU_1_Unused27() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused27
#define GetSig_CCU_1_Unused28() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused28
#define GetSig_CCU_1_Unused29() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused29
#define GetSig_CCU_1_Unused30() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused30
#define GetSig_CCU_1_Unused31() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused31
#define GetSig_CCU_1_Unused32() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused32
#define GetSig_CCU_1_Unused33() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused33
#define GetSig_CCU_1_Unused34() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused34
#define GetSig_CCU_1_Unused35() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused35
#define GetSig_CCU_1_Unused36() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused36
#define GetSig_CCU_1_Unused37() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused37
#define GetSig_CCU_1_Unused38() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused38
#define GetSig_CCU_1_Unused39() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused39
#define GetSig_CCU_1_Unused40() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused40
#define GetSig_CCU_1_Unused41() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused41
#define GetSig_CCU_1_Unused42() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused42
#define GetSig_CCU_1_Unused43() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused43
#define GetSig_CCU_1_Unused44() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused44
#define GetSig_CCU_1_Unused45() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused45
#define GetSig_CCU_1_Unused46() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused46
#define GetSig_CCU_1_Unused47() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused47
#define GetSig_CCU_1_Unused48() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused48
#define GetSig_CCU_1_Unused49() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused49
#define GetSig_CCU_1_Unused50() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused50
#define GetSig_CCU_1_Unused51() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused51
#define GetSig_CCU_1_Unused52() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused52
#define GetSig_CCU_1_Unused53() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused53
#define GetSig_CCU_1_Unused54() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused54
#define GetSig_CCU_1_Unused55() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused55
#define GetSig_CCU_1_Unused56() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused56
#define GetSig_CCU_1_Unused57() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused57
#define GetSig_CCU_1_Unused58() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused58
#define GetSig_CCU_1_Unused59() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused59
#define GetSig_CCU_1_Unused60() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused60
#define GetSig_CCU_1_Unused61() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused61
#define GetSig_CCU_1_Unused62() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused62
#define GetSig_CCU_1_Unused63() CanIf_uniRxMsgType_CCU_1.Ipdu.Unused63



/*0X330*/
#define GetSig_CCU_2_Unused0() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused0
#define GetSig_CCU_2_Unused1() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused1
#define GetSig_CCU_2_Unused2() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused2
#define GetSig_CCU_2_Unused3() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused3
#define GetSig_CCU_2_ACmaxSt() CanIf_uniRxMsgType_CCU_2.Ipdu.ACmaxSt
#define GetSig_CCU_2_ACSt() CanIf_uniRxMsgType_CCU_2.Ipdu.ACSt
#define GetSig_CCU_2_RearDefrostSt() CanIf_uniRxMsgType_CCU_2.Ipdu.RearDefrostSt
#define GetSig_CCU_2_Unused4() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused4
#define GetSig_CCU_2_WindExitMode() CanIf_uniRxMsgType_CCU_2.Ipdu.WindExitMode
#define GetSig_CCU_2_AutoSt() CanIf_uniRxMsgType_CCU_2.Ipdu.AutoSt
#define GetSig_CCU_2_DualSynSt() CanIf_uniRxMsgType_CCU_2.Ipdu.DualSynSt
#define GetSig_CCU_2_Unused5() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused5
#define GetSig_CCU_2_AirCirculationSt() CanIf_uniRxMsgType_CCU_2.Ipdu.AirCirculationSt
#define GetSig_CCU_2_Unused6() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused6
#define GetSig_CCU_2_DriverTempSelect() CanIf_uniRxMsgType_CCU_2.Ipdu.DriverTempSelect
#define GetSig_CCU_2_Unused7() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused7
#define GetSig_CCU_2_Unused8() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused8
#define GetSig_CCU_2_WindExitSpd() CanIf_uniRxMsgType_CCU_2.Ipdu.WindExitSpd
#define GetSig_CCU_2_Unused9() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused9
#define GetSig_CCU_2_Unused10() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused10
#define GetSig_CCU_2_ComfortCfgSt() CanIf_uniRxMsgType_CCU_2.Ipdu.ComfortCfgSt
#define GetSig_CCU_2_Unused11() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused11
#define GetSig_CCU_2_PsnTempSelect() CanIf_uniRxMsgType_CCU_2.Ipdu.PsnTempSelect
#define GetSig_CCU_2_AirCirCfgSt() CanIf_uniRxMsgType_CCU_2.Ipdu.AirCirCfgSt
#define GetSig_CCU_2_Unused12() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused12
#define GetSig_CCU_2_AirQqualitySenSt() CanIf_uniRxMsgType_CCU_2.Ipdu.AirQqualitySenSt
#define GetSig_CCU_2_Unused13() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused13
#define GetSig_CCU_2_ExterTempSnsDiag() CanIf_uniRxMsgType_CCU_2.Ipdu.ExterTempSnsDiag
#define GetSig_CCU_2_SolarFeaturesCfgSt() CanIf_uniRxMsgType_CCU_2.Ipdu.SolarFeaturesCfgSt
#define GetSig_CCU_2_EvapratorSelfCleanSt() CanIf_uniRxMsgType_CCU_2.Ipdu.EvapratorSelfCleanSt
#define GetSig_CCU_2_SceneDisplayReq() CanIf_uniRxMsgType_CCU_2.Ipdu.SceneDisplayReq
#define GetSig_CCU_2_FanspeedCfgSt() CanIf_uniRxMsgType_CCU_2.Ipdu.FanspeedCfgSt
#define GetSig_CCU_2_Unused14() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused14
#define GetSig_CCU_2_Unused15() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused15
#define GetSig_CCU_2_Unused16() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused16
#define GetSig_CCU_2_Unused17() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused17
#define GetSig_CCU_2_Unused18() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused18
#define GetSig_CCU_2_Unused19() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused19
#define GetSig_CCU_2_Unused20() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused20
#define GetSig_CCU_2_Unused21() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused21
#define GetSig_CCU_2_Unused22() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused22
#define GetSig_CCU_2_Unused23() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused23
#define GetSig_CCU_2_Unused24() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused24
#define GetSig_CCU_2_Unused25() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused25
#define GetSig_CCU_2_Unused26() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused26
#define GetSig_CCU_2_Unused27() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused27
#define GetSig_CCU_2_Unused28() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused28
#define GetSig_CCU_2_Unused29() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused29
#define GetSig_CCU_2_Unused30() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused30
#define GetSig_CCU_2_Unused31() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused31
#define GetSig_CCU_2_Unused32() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused32
#define GetSig_CCU_2_Unused33() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused33
#define GetSig_CCU_2_Unused34() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused34
#define GetSig_CCU_2_Unused35() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused35
#define GetSig_CCU_2_Unused36() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused36
#define GetSig_CCU_2_Unused37() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused37
#define GetSig_CCU_2_Unused38() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused38
#define GetSig_CCU_2_Unused39() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused39
#define GetSig_CCU_2_Unused40() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused40
#define GetSig_CCU_2_Unused41() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused41
#define GetSig_CCU_2_Unused42() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused42
#define GetSig_CCU_2_Unused43() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused43
#define GetSig_CCU_2_Unused44() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused44
#define GetSig_CCU_2_Unused45() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused45
#define GetSig_CCU_2_Unused46() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused46
#define GetSig_CCU_2_Unused47() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused47
#define GetSig_CCU_2_Unused48() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused48
#define GetSig_CCU_2_Unused49() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused49
#define GetSig_CCU_2_Unused50() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused50
#define GetSig_CCU_2_Unused51() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused51
#define GetSig_CCU_2_Unused52() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused52
#define GetSig_CCU_2_Unused53() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused53
#define GetSig_CCU_2_Unused54() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused54
#define GetSig_CCU_2_Unused55() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused55
#define GetSig_CCU_2_Unused56() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused56
#define GetSig_CCU_2_Unused57() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused57
#define GetSig_CCU_2_Unused58() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused58
#define GetSig_CCU_2_Unused59() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused59
#define GetSig_CCU_2_Unused60() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused60
#define GetSig_CCU_2_Unused61() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused61
#define GetSig_CCU_2_Unused62() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused62
#define GetSig_CCU_2_Unused63() CanIf_uniRxMsgType_CCU_2.Ipdu.Unused63


/*0X160*/
#define GetSig_CCU_BCS_2_C_Unused0() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused0
#define GetSig_CCU_BCS_2_C_Unused1() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused1
#define GetSig_CCU_BCS_2_C_Unused2() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused2
#define GetSig_CCU_BCS_2_C_BCS_VehSpd_H() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.BCS_VehSpd_H
#define GetSig_CCU_BCS_2_C_Unused3() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused3
#define GetSig_CCU_BCS_2_C_BCS_VehSpdVD() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.BCS_VehSpdVD
#define GetSig_CCU_BCS_2_C_BCS_VehSpd_L() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.BCS_VehSpd_L
#define GetSig_CCU_BCS_2_C_Unused4() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused4
#define GetSig_CCU_BCS_2_C_Unused5() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused5
#define GetSig_CCU_BCS_2_C_Unused6() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused6
#define GetSig_CCU_BCS_2_C_Unused7() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused7
#define GetSig_CCU_BCS_2_C_Unused8() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused8
#define GetSig_CCU_BCS_2_C_Unused9() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused9
#define GetSig_CCU_BCS_2_C_Unused10() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused10
#define GetSig_CCU_BCS_2_C_Unused11() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused11
#define GetSig_CCU_BCS_2_C_Unused12() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused12
#define GetSig_CCU_BCS_2_C_Unused13() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused13
#define GetSig_CCU_BCS_2_C_Unused14() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused14
#define GetSig_CCU_BCS_2_C_Unused15() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused15
#define GetSig_CCU_BCS_2_C_Unused16() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused16
#define GetSig_CCU_BCS_2_C_Unused17() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused17
#define GetSig_CCU_BCS_2_C_Unused18() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused18
#define GetSig_CCU_BCS_2_C_Unused19() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused19
#define GetSig_CCU_BCS_2_C_Unused20() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused20
#define GetSig_CCU_BCS_2_C_Unused21() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused21
#define GetSig_CCU_BCS_2_C_Unused22() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused22
#define GetSig_CCU_BCS_2_C_Unused23() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused23
#define GetSig_CCU_BCS_2_C_Unused24() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused24
#define GetSig_CCU_BCS_2_C_Unused25() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused25
#define GetSig_CCU_BCS_2_C_Unused26() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused26
#define GetSig_CCU_BCS_2_C_Unused27() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused27
#define GetSig_CCU_BCS_2_C_Unused28() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused28
#define GetSig_CCU_BCS_2_C_Unused29() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused29
#define GetSig_CCU_BCS_2_C_Unused30() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused30
#define GetSig_CCU_BCS_2_C_Unused31() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused31
#define GetSig_CCU_BCS_2_C_Unused32() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused32
#define GetSig_CCU_BCS_2_C_Unused33() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused33
#define GetSig_CCU_BCS_2_C_Unused34() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused34
#define GetSig_CCU_BCS_2_C_Unused35() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused35
#define GetSig_CCU_BCS_2_C_Unused36() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused36
#define GetSig_CCU_BCS_2_C_Unused37() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused37
#define GetSig_CCU_BCS_2_C_Unused38() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused38
#define GetSig_CCU_BCS_2_C_Unused39() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused39
#define GetSig_CCU_BCS_2_C_Unused40() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused40
#define GetSig_CCU_BCS_2_C_Unused41() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused41
#define GetSig_CCU_BCS_2_C_Unused42() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused42
#define GetSig_CCU_BCS_2_C_Unused43() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused43
#define GetSig_CCU_BCS_2_C_Unused44() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused44
#define GetSig_CCU_BCS_2_C_Unused45() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused45
#define GetSig_CCU_BCS_2_C_Unused46() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused46
#define GetSig_CCU_BCS_2_C_Unused47() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused47
#define GetSig_CCU_BCS_2_C_Unused48() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused48
#define GetSig_CCU_BCS_2_C_Unused49() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused49
#define GetSig_CCU_BCS_2_C_Unused50() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused50
#define GetSig_CCU_BCS_2_C_Unused51() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused51
#define GetSig_CCU_BCS_2_C_Unused52() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused52
#define GetSig_CCU_BCS_2_C_Unused53() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused53
#define GetSig_CCU_BCS_2_C_Unused54() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused54
#define GetSig_CCU_BCS_2_C_Unused55() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused55
#define GetSig_CCU_BCS_2_C_Unused56() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused56
#define GetSig_CCU_BCS_2_C_Unused57() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused57
#define GetSig_CCU_BCS_2_C_Unused58() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused58
#define GetSig_CCU_BCS_2_C_Unused59() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused59
#define GetSig_CCU_BCS_2_C_Unused60() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused60
#define GetSig_CCU_BCS_2_C_Unused61() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused61
#define GetSig_CCU_BCS_2_C_Unused62() CanIf_uniRxMsgType_CCU_BCS_2_C.Ipdu.Unused62

/*0X310*/
#define GetSig_CCU_ZCUF_1_Unused0() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused0
#define GetSig_CCU_ZCUF_1_Unused1() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused1
#define GetSig_CCU_ZCUF_1_Unused2() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused2
#define GetSig_CCU_ZCUF_1_Unused3() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused3
#define GetSig_CCU_ZCUF_1_Unused4() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused4
#define GetSig_CCU_ZCUF_1_Unused5() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused5
#define GetSig_CCU_ZCUF_1_Unused6() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused6
#define GetSig_CCU_ZCUF_1_Unused7() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused7
#define GetSig_CCU_ZCUF_1_Unused8() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused8
#define GetSig_CCU_ZCUF_1_Unused9() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused9
#define GetSig_CCU_ZCUF_1_Unused10() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused10
#define GetSig_CCU_ZCUF_1_Unused11() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused11
#define GetSig_CCU_ZCUF_1_Unused12() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused12
#define GetSig_CCU_ZCUF_1_Unused13() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused13
#define GetSig_CCU_ZCUF_1_Unused14() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused14
#define GetSig_CCU_ZCUF_1_Unused15() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused15
#define GetSig_CCU_ZCUF_1_Unused16() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused16
#define GetSig_CCU_ZCUF_1_RawExterTemp_H() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.RawExterTemp_H
#define GetSig_CCU_ZCUF_1_Unused17() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused17
#define GetSig_CCU_ZCUF_1_RawExterTemp_L() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.RawExterTemp_L
#define GetSig_CCU_ZCUF_1_Unused18() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused18
#define GetSig_CCU_ZCUF_1_Unused19() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused19
#define GetSig_CCU_ZCUF_1_Unused20() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused20
#define GetSig_CCU_ZCUF_1_Unused21() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused21
#define GetSig_CCU_ZCUF_1_Unused22() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused22
#define GetSig_CCU_ZCUF_1_Unused23() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused23
#define GetSig_CCU_ZCUF_1_Unused24() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused24
#define GetSig_CCU_ZCUF_1_Unused25() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused25
#define GetSig_CCU_ZCUF_1_Unused26() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused26
#define GetSig_CCU_ZCUF_1_Unused27() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused27
#define GetSig_CCU_ZCUF_1_Unused28() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused28
#define GetSig_CCU_ZCUF_1_Unused29() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused29
#define GetSig_CCU_ZCUF_1_Unused30() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused30
#define GetSig_CCU_ZCUF_1_Unused31() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused31
#define GetSig_CCU_ZCUF_1_Unused32() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused32
#define GetSig_CCU_ZCUF_1_Unused33() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused33
#define GetSig_CCU_ZCUF_1_Unused34() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused34
#define GetSig_CCU_ZCUF_1_Unused35() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused35
#define GetSig_CCU_ZCUF_1_Unused36() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused36
#define GetSig_CCU_ZCUF_1_Unused37() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused37
#define GetSig_CCU_ZCUF_1_Unused38() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused38
#define GetSig_CCU_ZCUF_1_Unused39() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused39
#define GetSig_CCU_ZCUF_1_Unused40() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused40
#define GetSig_CCU_ZCUF_1_Unused41() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused41
#define GetSig_CCU_ZCUF_1_Unused42() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused42
#define GetSig_CCU_ZCUF_1_Unused43() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused43
#define GetSig_CCU_ZCUF_1_Unused44() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused44
#define GetSig_CCU_ZCUF_1_Unused45() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused45
#define GetSig_CCU_ZCUF_1_Unused46() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused46
#define GetSig_CCU_ZCUF_1_Unused47() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused47
#define GetSig_CCU_ZCUF_1_Unused48() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused48
#define GetSig_CCU_ZCUF_1_Unused49() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused49
#define GetSig_CCU_ZCUF_1_Unused50() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused50
#define GetSig_CCU_ZCUF_1_Unused51() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused51
#define GetSig_CCU_ZCUF_1_Unused52() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused52
#define GetSig_CCU_ZCUF_1_Unused53() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused53
#define GetSig_CCU_ZCUF_1_Unused54() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused54
#define GetSig_CCU_ZCUF_1_Unused55() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused55
#define GetSig_CCU_ZCUF_1_Unused56() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused56
#define GetSig_CCU_ZCUF_1_Unused57() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused57
#define GetSig_CCU_ZCUF_1_Unused58() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused58
#define GetSig_CCU_ZCUF_1_Unused59() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused59
#define GetSig_CCU_ZCUF_1_Unused60() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused60
#define GetSig_CCU_ZCUF_1_Unused61() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused61
#define GetSig_CCU_ZCUF_1_Unused62() CanIf_uniRxMsgType_CCU_ZCUF_1.Ipdu.Unused62

/*0X312*/
#define GetSig_CCU_ZCUR_5_Unused0() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused0
#define GetSig_CCU_ZCUR_5_Unused1() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused1
#define GetSig_CCU_ZCUR_5_Unused2() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused2
#define GetSig_CCU_ZCUR_5_Unused3() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused3
#define GetSig_CCU_ZCUR_5_Unused4() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused4
#define GetSig_CCU_ZCUR_5_RawCabinTemp_H() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.RawCabinTemp_H
#define GetSig_CCU_ZCUR_5_Unused5() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused5
#define GetSig_CCU_ZCUR_5_RawCabinTemp_L() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.RawCabinTemp_L
#define GetSig_CCU_ZCUR_5_Unused6() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused6
#define GetSig_CCU_ZCUR_5_Unused7() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused7
#define GetSig_CCU_ZCUR_5_Unused8() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused8
#define GetSig_CCU_ZCUR_5_Unused9() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused9
#define GetSig_CCU_ZCUR_5_Unused10() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused10
#define GetSig_CCU_ZCUR_5_Unused11() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused11
#define GetSig_CCU_ZCUR_5_Unused12() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused12
#define GetSig_CCU_ZCUR_5_Unused13() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused13
#define GetSig_CCU_ZCUR_5_Unused14() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused14
#define GetSig_CCU_ZCUR_5_Unused15() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused15
#define GetSig_CCU_ZCUR_5_Unused16() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused16
#define GetSig_CCU_ZCUR_5_Unused17() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused17
#define GetSig_CCU_ZCUR_5_Unused18() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused18
#define GetSig_CCU_ZCUR_5_Unused19() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused19
#define GetSig_CCU_ZCUR_5_Unused20() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused20
#define GetSig_CCU_ZCUR_5_Unused21() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused21
#define GetSig_CCU_ZCUR_5_Unused22() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused22
#define GetSig_CCU_ZCUR_5_Unused23() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused23
#define GetSig_CCU_ZCUR_5_Unused24() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused24
#define GetSig_CCU_ZCUR_5_Unused25() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused25
#define GetSig_CCU_ZCUR_5_Unused26() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused26
#define GetSig_CCU_ZCUR_5_Unused27() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused27
#define GetSig_CCU_ZCUR_5_Unused28() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused28
#define GetSig_CCU_ZCUR_5_Unused29() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused29
#define GetSig_CCU_ZCUR_5_Unused30() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused30
#define GetSig_CCU_ZCUR_5_Unused31() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused31
#define GetSig_CCU_ZCUR_5_Unused32() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused32
#define GetSig_CCU_ZCUR_5_Unused33() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused33
#define GetSig_CCU_ZCUR_5_Unused34() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused34
#define GetSig_CCU_ZCUR_5_Unused35() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused35
#define GetSig_CCU_ZCUR_5_Unused36() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused36
#define GetSig_CCU_ZCUR_5_Unused37() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused37
#define GetSig_CCU_ZCUR_5_Unused38() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused38
#define GetSig_CCU_ZCUR_5_Unused39() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused39
#define GetSig_CCU_ZCUR_5_Unused40() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused40
#define GetSig_CCU_ZCUR_5_Unused41() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused41
#define GetSig_CCU_ZCUR_5_Unused42() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused42
#define GetSig_CCU_ZCUR_5_Unused43() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused43
#define GetSig_CCU_ZCUR_5_Unused44() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused44
#define GetSig_CCU_ZCUR_5_Unused45() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused45
#define GetSig_CCU_ZCUR_5_Unused46() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused46
#define GetSig_CCU_ZCUR_5_Unused47() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused47
#define GetSig_CCU_ZCUR_5_Unused48() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused48
#define GetSig_CCU_ZCUR_5_Unused49() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused49
#define GetSig_CCU_ZCUR_5_Unused50() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused50
#define GetSig_CCU_ZCUR_5_Unused51() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused51
#define GetSig_CCU_ZCUR_5_Unused52() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused52
#define GetSig_CCU_ZCUR_5_Unused53() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused53
#define GetSig_CCU_ZCUR_5_Unused54() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused54
#define GetSig_CCU_ZCUR_5_Unused55() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused55
#define GetSig_CCU_ZCUR_5_Unused56() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused56
#define GetSig_CCU_ZCUR_5_Unused57() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused57
#define GetSig_CCU_ZCUR_5_Unused58() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused58
#define GetSig_CCU_ZCUR_5_Unused59() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused59
#define GetSig_CCU_ZCUR_5_Unused60() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused60
#define GetSig_CCU_ZCUR_5_Unused61() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused61
#define GetSig_CCU_ZCUR_5_Unused62() CanIf_uniRxMsgType_CCU_ZCUR_5.Ipdu.Unused62

/*0X370*/
#define GetSig_ITS_1_Unused0() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused0
#define GetSig_ITS_1_Unused1() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused1
#define GetSig_ITS_1_Unused2() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused2
#define GetSig_ITS_1_ITS_HeaterPumpStpSpdErr() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_HeaterPumpStpSpdErr
#define GetSig_ITS_1_ITS_FanRunSt() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_FanRunSt
#define GetSig_ITS_1_Unused3() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused3
#define GetSig_ITS_1_Unused4() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused4
#define GetSig_ITS_1_ITS_EcvErr() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_EcvErr
#define GetSig_ITS_1_Unused5() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused5
#define GetSig_ITS_1_ITS_ValveModeAct() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_ValveModeAct
#define GetSig_ITS_1_ITS_ECVPosnAct_H() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_ECVPosnAct_H
#define GetSig_ITS_1_Unused6() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused6
#define GetSig_ITS_1_ITS_ECVMotorSt() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_ECVMotorSt
#define GetSig_ITS_1_Unused7() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused7
#define GetSig_ITS_1_ITS_ECVPosnAct_L() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_ECVPosnAct_L
#define GetSig_ITS_1_Unused8() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused8
#define GetSig_ITS_1_Unused9() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused9
#define GetSig_ITS_1_Unused10() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused10
#define GetSig_ITS_1_Unused11() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused11
#define GetSig_ITS_1_Unused12() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused12
#define GetSig_ITS_1_Unused13() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused13
#define GetSig_ITS_1_ITS_ChillerInletTempErr() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_ChillerInletTempErr
#define GetSig_ITS_1_ITS_BatteryInletTempErr() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_BatteryInletTempErr
#define GetSig_ITS_1_ITS_MotorInletTempErr() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_MotorInletTempErr
#define GetSig_ITS_1_Unused14() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused14
#define GetSig_ITS_1_ITS_MotorInletTemp_H() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_MotorInletTemp_H
#define GetSig_ITS_1_ITS_MotorInletTemp_L() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_MotorInletTemp_L
#define GetSig_ITS_1_ITS_BatteryInletTemp_H() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_BatteryInletTemp_H
#define GetSig_ITS_1_ITS_BatteryInletTemp_L() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_BatteryInletTemp_L
#define GetSig_ITS_1_ITS_ChillerInletTemp_H() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_ChillerInletTemp_H
#define GetSig_ITS_1_ITS_ChillerInletTemp_L() CanIf_uniRxMsgType_ITS_1.Ipdu.ITS_ChillerInletTemp_L
#define GetSig_ITS_1_Unused15() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused15
#define GetSig_ITS_1_Unused16() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused16
#define GetSig_ITS_1_Unused17() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused17
#define GetSig_ITS_1_Unused18() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused18
#define GetSig_ITS_1_Unused19() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused19
#define GetSig_ITS_1_Unused20() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused20
#define GetSig_ITS_1_Unused21() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused21
#define GetSig_ITS_1_Unused22() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused22
#define GetSig_ITS_1_Unused23() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused23
#define GetSig_ITS_1_Unused24() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused24
#define GetSig_ITS_1_Unused25() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused25
#define GetSig_ITS_1_Unused26() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused26
#define GetSig_ITS_1_Unused27() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused27
#define GetSig_ITS_1_Unused28() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused28
#define GetSig_ITS_1_Unused29() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused29
#define GetSig_ITS_1_Unused30() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused30
#define GetSig_ITS_1_Unused31() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused31
#define GetSig_ITS_1_Unused32() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused32
#define GetSig_ITS_1_Unused33() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused33
#define GetSig_ITS_1_Unused34() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused34
#define GetSig_ITS_1_Unused35() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused35
#define GetSig_ITS_1_Unused36() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused36
#define GetSig_ITS_1_Unused37() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused37
#define GetSig_ITS_1_Unused38() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused38
#define GetSig_ITS_1_Unused39() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused39
#define GetSig_ITS_1_Unused40() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused40
#define GetSig_ITS_1_Unused41() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused41
#define GetSig_ITS_1_Unused42() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused42
#define GetSig_ITS_1_Unused43() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused43
#define GetSig_ITS_1_Unused44() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused44
#define GetSig_ITS_1_Unused45() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused45
#define GetSig_ITS_1_Unused46() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused46
#define GetSig_ITS_1_Unused47() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused47
#define GetSig_ITS_1_Unused48() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused48
#define GetSig_ITS_1_Unused49() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused49
#define GetSig_ITS_1_Unused50() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused50
#define GetSig_ITS_1_Unused51() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused51
#define GetSig_ITS_1_Unused52() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused52
#define GetSig_ITS_1_Unused53() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused53
#define GetSig_ITS_1_Unused54() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused54
#define GetSig_ITS_1_Unused55() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused55
#define GetSig_ITS_1_Unused56() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused56
#define GetSig_ITS_1_Unused57() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused57
#define GetSig_ITS_1_Unused58() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused58
#define GetSig_ITS_1_Unused59() CanIf_uniRxMsgType_ITS_1.Ipdu.Unused59


/*0x338*/
#define GetSig_VCU_2_Unused0() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused0
#define GetSig_VCU_2_Unused1() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused1
#define GetSig_VCU_2_Unused2() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused2
#define GetSig_VCU_2_Unused3() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused3
#define GetSig_VCU_2_Unused4() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused4
#define GetSig_VCU_2_VCU_HVAC_PTCdelayEn() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVAC_PTCdelayEn
#define GetSig_VCU_2_Unused5() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused5
#define GetSig_VCU_2_Unused6() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused6
#define GetSig_VCU_2_VCU_HVAC_InterCirReq() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVAC_InterCirReq
#define GetSig_VCU_2_Unused7() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused7
#define GetSig_VCU_2_VCU_HVBatCoolPrioReq_H() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVBatCoolPrioReq_H
#define GetSig_VCU_2_Unused8() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused8
#define GetSig_VCU_2_Unused9() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused9
#define GetSig_VCU_2_VCU_HVBatCoolPrioReq_L() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVBatCoolPrioReq_L
#define GetSig_VCU_2_Unused10() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused10
#define GetSig_VCU_2_VCU_HVAC_CabinCoolHeatOffReq() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVAC_CabinCoolHeatOffReq
#define GetSig_VCU_2_Unused11() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused11
#define GetSig_VCU_2_VCU_BattCoolPwrReq_H() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_BattCoolPwrReq_H
#define GetSig_VCU_2_Unused12() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused12
#define GetSig_VCU_2_Unused13() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused13
#define GetSig_VCU_2_VCU_BattCoolPwrReq_L() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_BattCoolPwrReq_L
#define GetSig_VCU_2_Unused14() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused14
#define GetSig_VCU_2_Unused15() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused15
#define GetSig_VCU_2_Unused16() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused16
#define GetSig_VCU_2_Unused17() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused17
#define GetSig_VCU_2_Unused18() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused18
#define GetSig_VCU_2_Unused19() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused19
#define GetSig_VCU_2_Unused20() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused20
#define GetSig_VCU_2_Unused21() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused21
#define GetSig_VCU_2_Unused22() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused22
#define GetSig_VCU_2_Unused23() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused23
#define GetSig_VCU_2_VCU_HVBatHeatPrioReq_H() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVBatHeatPrioReq_H
#define GetSig_VCU_2_VCU_PwrHeatEn() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_PwrHeatEn
#define GetSig_VCU_2_Unused24() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused24
#define GetSig_VCU_2_Unused25() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused25
#define GetSig_VCU_2_VCU_HVBatHeatPrioReq_L() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVBatHeatPrioReq_L
#define GetSig_VCU_2_Unused26() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused26
#define GetSig_VCU_2_Unused27() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused27
#define GetSig_VCU_2_Unused28() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused28
#define GetSig_VCU_2_Unused29() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused29
#define GetSig_VCU_2_Unused30() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused30
#define GetSig_VCU_2_Unused31() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused31
#define GetSig_VCU_2_Unused32() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused32
#define GetSig_VCU_2_Unused33() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused33
#define GetSig_VCU_2_Unused34() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused34
#define GetSig_VCU_2_Unused35() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused35
#define GetSig_VCU_2_Unused36() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused36
#define GetSig_VCU_2_Unused37() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused37
#define GetSig_VCU_2_Unused38() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused38
#define GetSig_VCU_2_Unused39() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused39
#define GetSig_VCU_2_Unused40() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused40
#define GetSig_VCU_2_Unused41() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused41
#define GetSig_VCU_2_Unused42() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused42
#define GetSig_VCU_2_Unused43() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused43
#define GetSig_VCU_2_Unused44() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused44
#define GetSig_VCU_2_Unused45() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused45
#define GetSig_VCU_2_Unused46() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused46
#define GetSig_VCU_2_VCU_HVACPwrLimit_H() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVACPwrLimit_H
#define GetSig_VCU_2_Unused47() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused47
#define GetSig_VCU_2_VCU_PwrCoolEn() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_PwrCoolEn
#define GetSig_VCU_2_Unused48() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused48
#define GetSig_VCU_2_Unused49() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused49
#define GetSig_VCU_2_VCU_HVACPwrLimit_L() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVACPwrLimit_L
#define GetSig_VCU_2_Unused50() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused50
#define GetSig_VCU_2_VCU_HVACPwrLimitAct() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVACPwrLimitAct
#define GetSig_VCU_2_Unused51() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused51
#define GetSig_VCU_2_Unused52() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused52
#define GetSig_VCU_2_Unused53() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused53
#define GetSig_VCU_2_Unused54() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused54
#define GetSig_VCU_2_Unused55() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused55
#define GetSig_VCU_2_Unused56() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused56
#define GetSig_VCU_2_VCU_HVACEcoModeReq() CanIf_uniRxMsgType_VCU_2.Ipdu.VCU_HVACEcoModeReq
#define GetSig_VCU_2_Unused57() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused57
#define GetSig_VCU_2_Unused58() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused58
#define GetSig_VCU_2_Unused59() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused59
#define GetSig_VCU_2_Unused60() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused60
#define GetSig_VCU_2_Unused61() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused61
#define GetSig_VCU_2_Unused62() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused62
#define GetSig_VCU_2_Unused63() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused63
#define GetSig_VCU_2_Unused64() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused64
#define GetSig_VCU_2_Unused65() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused65
#define GetSig_VCU_2_Unused66() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused66
#define GetSig_VCU_2_Unused67() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused67
#define GetSig_VCU_2_Unused68() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused68
#define GetSig_VCU_2_Unused69() CanIf_uniRxMsgType_VCU_2.Ipdu.Unused69



/*0X3B8*/
#define GetSig_VCU_3_Unused0() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused0
#define GetSig_VCU_3_Unused1() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused1
#define GetSig_VCU_3_Unused2() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused2
#define GetSig_VCU_3_Unused3() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused3
#define GetSig_VCU_3_Unused4() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused4
#define GetSig_VCU_3_Unused5() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused5
#define GetSig_VCU_3_Unused6() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused6
#define GetSig_VCU_3_Unused7() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused7
#define GetSig_VCU_3_Unused8() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused8
#define GetSig_VCU_3_Unused9() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused9
#define GetSig_VCU_3_Unused10() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused10
#define GetSig_VCU_3_Unused11() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused11
#define GetSig_VCU_3_Unused12() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused12
#define GetSig_VCU_3_Unused13() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused13
#define GetSig_VCU_3_VCU_HeatRecEnChiller() CanIf_uniRxMsgType_VCU_3.Ipdu.VCU_HeatRecEnChiller
#define GetSig_VCU_3_Unused14() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused14
#define GetSig_VCU_3_Unused15() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused15
#define GetSig_VCU_3_Unused16() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused16
#define GetSig_VCU_3_Unused17() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused17
#define GetSig_VCU_3_Unused18() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused18
#define GetSig_VCU_3_Unused19() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused19
#define GetSig_VCU_3_Unused20() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused20
#define GetSig_VCU_3_Unused21() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused21
#define GetSig_VCU_3_Unused22() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused22
#define GetSig_VCU_3_Unused23() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused23
#define GetSig_VCU_3_Unused24() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused24
#define GetSig_VCU_3_Unused25() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused25
#define GetSig_VCU_3_Unused26() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused26
#define GetSig_VCU_3_Unused27() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused27
#define GetSig_VCU_3_Unused28() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused28
#define GetSig_VCU_3_Unused29() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused29
#define GetSig_VCU_3_Unused30() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused30
#define GetSig_VCU_3_Unused31() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused31
#define GetSig_VCU_3_Unused32() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused32
#define GetSig_VCU_3_Unused33() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused33
#define GetSig_VCU_3_Unused34() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused34
#define GetSig_VCU_3_Unused35() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused35
#define GetSig_VCU_3_Unused36() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused36
#define GetSig_VCU_3_Unused37() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused37
#define GetSig_VCU_3_Unused38() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused38
#define GetSig_VCU_3_Unused39() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused39
#define GetSig_VCU_3_Unused40() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused40
#define GetSig_VCU_3_Unused41() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused41
#define GetSig_VCU_3_Unused42() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused42
#define GetSig_VCU_3_Unused43() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused43
#define GetSig_VCU_3_Unused44() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused44
#define GetSig_VCU_3_Unused45() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused45
#define GetSig_VCU_3_Unused46() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused46
#define GetSig_VCU_3_Unused47() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused47
#define GetSig_VCU_3_Unused48() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused48
#define GetSig_VCU_3_Unused49() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused49
#define GetSig_VCU_3_Unused50() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused50
#define GetSig_VCU_3_Unused51() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused51
#define GetSig_VCU_3_Unused52() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused52
#define GetSig_VCU_3_Unused53() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused53
#define GetSig_VCU_3_Unused54() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused54
#define GetSig_VCU_3_Unused55() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused55
#define GetSig_VCU_3_Unused56() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused56
#define GetSig_VCU_3_Unused57() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused57
#define GetSig_VCU_3_Unused58() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused58
#define GetSig_VCU_3_Unused59() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused59
#define GetSig_VCU_3_Unused60() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused60
#define GetSig_VCU_3_Unused61() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused61
#define GetSig_VCU_3_Unused62() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused62
#define GetSig_VCU_3_Unused63() CanIf_uniRxMsgType_VCU_3.Ipdu.Unused63

/*0X3A2*/
#define GetSig_VCU_4_Unused0() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused0
#define GetSig_VCU_4_Unused1() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused1
#define GetSig_VCU_4_Unused2() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused2
#define GetSig_VCU_4_Unused3() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused3
#define GetSig_VCU_4_Unused4() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused4
#define GetSig_VCU_4_Unused5() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused5
#define GetSig_VCU_4_Unused6() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused6
#define GetSig_VCU_4_Unused7() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused7
#define GetSig_VCU_4_Unused8() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused8
#define GetSig_VCU_4_Unused9() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused9
#define GetSig_VCU_4_Unused10() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused10
#define GetSig_VCU_4_Unused11() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused11
#define GetSig_VCU_4_Unused12() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused12
#define GetSig_VCU_4_Unused13() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused13
#define GetSig_VCU_4_VCU_HVAC_PTCShutlmme() CanIf_uniRxMsgType_VCU_4.Ipdu.VCU_HVAC_PTCShutlmme
#define GetSig_VCU_4_Unused14() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused14
#define GetSig_VCU_4_Unused15() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused15
#define GetSig_VCU_4_Unused16() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused16
#define GetSig_VCU_4_Unused17() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused17
#define GetSig_VCU_4_Unused18() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused18
#define GetSig_VCU_4_Unused19() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused19
#define GetSig_VCU_4_Unused20() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused20
#define GetSig_VCU_4_Unused21() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused21
#define GetSig_VCU_4_Unused22() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused22
#define GetSig_VCU_4_Unused23() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused23
#define GetSig_VCU_4_Unused24() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused24
#define GetSig_VCU_4_Unused25() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused25
#define GetSig_VCU_4_Unused26() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused26
#define GetSig_VCU_4_Unused27() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused27
#define GetSig_VCU_4_Unused28() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused28
#define GetSig_VCU_4_Unused29() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused29
#define GetSig_VCU_4_Unused30() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused30
#define GetSig_VCU_4_Unused31() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused31
#define GetSig_VCU_4_Unused32() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused32
#define GetSig_VCU_4_Unused33() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused33
#define GetSig_VCU_4_Unused34() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused34
#define GetSig_VCU_4_Unused35() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused35
#define GetSig_VCU_4_Unused36() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused36
#define GetSig_VCU_4_Unused37() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused37
#define GetSig_VCU_4_Unused38() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused38
#define GetSig_VCU_4_Unused39() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused39
#define GetSig_VCU_4_Unused40() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused40
#define GetSig_VCU_4_Unused41() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused41
#define GetSig_VCU_4_Unused42() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused42
#define GetSig_VCU_4_Unused43() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused43
#define GetSig_VCU_4_Unused44() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused44
#define GetSig_VCU_4_Unused45() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused45
#define GetSig_VCU_4_Unused46() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused46
#define GetSig_VCU_4_Unused47() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused47
#define GetSig_VCU_4_Unused48() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused48
#define GetSig_VCU_4_Unused49() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused49
#define GetSig_VCU_4_Unused50() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused50
#define GetSig_VCU_4_Unused51() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused51
#define GetSig_VCU_4_Unused52() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused52
#define GetSig_VCU_4_Unused53() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused53
#define GetSig_VCU_4_Unused54() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused54
#define GetSig_VCU_4_Unused55() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused55
#define GetSig_VCU_4_Unused56() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused56
#define GetSig_VCU_4_Unused57() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused57
#define GetSig_VCU_4_Unused58() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused58
#define GetSig_VCU_4_Unused59() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused59
#define GetSig_VCU_4_Unused60() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused60
#define GetSig_VCU_4_Unused61() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused61
#define GetSig_VCU_4_Unused62() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused62
#define GetSig_VCU_4_Unused63() CanIf_uniRxMsgType_VCU_4.Ipdu.Unused63


typedef struct
{
	uint8* pu8Data;
} CanIf_tstrDataAddrType;

/******************************************************************************/
/* CONSTANTS DEFINITION                                                       */
/******************************************************************************/


/******************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/


	
/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/
typedef void (*Com_RxIndicationType)(void);
typedef void (*Com_TOIndicationType)(void);
typedef void (*Com_TxIndicationType)(uint8 *pu8Data);

typedef enum
{
	MST_Cycle,
	MST_NoSendType,
	MST_IfActive
} CanIf_tenuMsgSendType;

/*send msg type*/
typedef struct
{
	Can_tstrPduType strPdu;
	uint16 u16MsgCycleTime;
	uint16 u16MsgCycleTimeFast;
	uint8 u8MsgNbOfRepetition;
    CanIf_tenuMsgSendType enuMsgSendType;
	Com_TxIndicationType vidTxIndication;
	uint8 u8MsgBufInd;
} CanIf_tstrTxMsgInfoType;

/*receive msg type*/
typedef struct
{
	Can_tstrPduType strPdu;
    boolean bTOMonitored;
	uint16 u16MsgCycleTime;
    uint16 u16RxTimeout; 
	uint16 u16RxRTTime;
	Com_RxIndicationType vidRxIndication;
	Com_TOIndicationType vidTOIndication;
} CanIf_tstrRxMsgInfoType;

typedef struct
{
	boolean bSend;
	uint16 u16MsgCycleTimeCnt;
	uint16 u16MsgCycleTimeFastCnt;
	uint8 u8MsgNbOfRepetitionCnt;
}CanIf_tstrTxCtrlType;

typedef struct
{
	uint16 u16CntRecv;
	uint16 u16CntLost;
	uint16 u16TimerRecvPassed; /*record timer passed when receive the last msg*/
	uint8 u8Status; /*0-normal, 1-rx time out*/
} CanIf_tstrRxCtrlType;

/******************************************************************************/   
/* Send Signal structures                                                     */ 
/******************************************************************************/  
typedef struct 
{	 
	 uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
     
	 uint8 HVAC_1_TempSelect : 5;	
     uint8 HVAC_1_ACmaxSt: 1;
     uint8 HVAC_1_ACSt: 1;
     uint8 HVAC_1_RearDefrostSt: 1;

     
     uint8 HVAC_1_TelematicsSt: 3;
     uint8 HVAC_1_WindExitMode: 3;
     uint8 HVAC_1_AutoSt: 1;
     uint8 HVAC_1_DualSynSt: 1;

     
	 uint8 HVAC_1_PopupDisplayReq2 : 5;	
     uint8 HVAC_1_PopupDisplayReq  : 1;	
	 uint8 HVAC_1_AirCirculationSt : 2;	

     
     uint8 HVAC_1_IonMode : 2;	
     uint8 HVAC_1_DriverTempSelect : 5;	
     uint8 HVAC_1_IonPopReq : 1;   

     uint8 HVAC_1_CompensateWindExitMotorReq_H : 4;	
     uint8 HVAC_1_WindExitSpd : 4;	
     /*********************************/
     uint8 HVAC_1_PTCPwrConsmp_H: 2;
     uint8 Unused3 : 1;	
     uint8 HVAC_1_CompensateWindExitMotorReqVD : 1;	
     uint8 HVAC_1_CompensateWindExitMotorReq_L : 4;	

     uint8 HVAC_1_PTCPwrConsmp_L: 8;

     uint8 HVAC_1_ComfortCfgSt: 2;	
     uint8 HVAC_1_PTCWaterTempWarn: 1;	
     uint8 HVAC_1_PsnTempSelect: 5;

     uint8 HVAC_1_AirCirCfgSt : 1;	
     uint8 HVAC_1_PTCCoolantTemp : 7;	

     uint8 HVAC_1_AirQqualitySenSt : 2;	
     uint8 HVAC_1_PTCOutletTargetTemp : 6;	

     uint8 HVAC_1_ExterTempSnsDiag : 2;	
     uint8 HVAC_1_SolarFeaturesCfgSt : 1;	
     uint8 HVAC_1_EvapratorSelfCleanSt : 1;	
     uint8 HVAC_1_SceneDisplayReq : 2;	
     uint8 HVAC_1_FanspeedCfgSt : 2;

     uint8 HVAC_1_WindExitModeReqVD : 1;	
     uint8 HVAC_1_WindExitModeReq : 3;	
     uint8 HVAC_1_EngIdleStopProhibitReq : 1;
     uint8 HVAC_1_DisinfectenSt : 3;	

     uint8 HVAC_1_WindExitSpdLvl : 5;
     uint8 Unused4 : 3;
     /*********************************/
     uint8 HVAC_1_CorrectedExterTemp : 8;

     uint8 HVAC_1_PTCHeatingReq : 7;	
     uint8 HVAC_1_CorrectedExterTempVD : 1;

     uint8 HVAC_1_DrAMDoorPostion : 8;	

     uint8 HVAC_1_HeaterPumpSpdSet : 7;	
     uint8 HVAC_1_DrAMDoorPostionVD : 1;

     uint8 HVAC_1_PaAMDoorPostion : 8;	

     uint8 HVAC_1_PTCSt: 1;	
     uint8 HVAC_1_PTCFault : 1;	
     uint8 HVAC_1_ECPFault : 1;	
     uint8 HVAC_1_AirCompressorReqVD : 1;
     uint8 HVAC_1_AirCompressorReq : 1;	
     uint8 HVAC_1_DualCircuSt : 2;	
     uint8 HVAC_1_PaAMDoorPostionVD : 1;

     uint8 HVAC_1_ECPTargetSpd : 8;	
     
     uint8 HVAC_1_ECPwrLimit : 8;	
     
     /*********************************/
     uint8 HVAC_1_CoolFanDutyCycleReq: 8;
     
     uint8 HVAC_1_PTCCurSt : 2;	
     uint8 HVAC_1_EVAvalve : 1;	
     uint8 HVAC_1_CondDefSt : 2;	
     uint8 HVAC_1_HighSpdFanReqVD : 1;	
     uint8 HVAC_1_HighSpdFanReq : 1;	
     uint8 HVAC_1_CoolFanDutyCyclerReqVD : 1;

     
     uint8 HVAC_1_StsCabinHeatPrioReq : 4;	
     uint8 HVAC_1_StsCanbinCoolPrioReq : 4;	

     
     uint8 HVAC_1_ActGrillDutyCycleReqVD : 1;	
     uint8 HVAC_1_ActGrillDutyCycleReq : 7;	

     
     uint8 Unused5 : 8;	
     uint8 Unused6 : 8;	

     
     uint8 HVAC_1_PM25Value_H : 2;	
     uint8 HVAC_1_PM25CleanReq : 1;	
     uint8 HVAC_1_PM10ValueVD : 1;	
     uint8 HVAC_1_PM25ValueVD : 1;	
     uint8 HVAC_1_RefrigerantPrVD : 1;	
     uint8 HVAC_1_RawExterTempVD : 1;
     uint8 HVAC_1_RawCabinTempVD : 1;

     
     uint8 HVAC_1_PM25Value_L : 8;	
     /*********************************/
     uint8 HVAC_1_PM10_Value_H : 8;

     
     uint8 HVAC_1_FraganceTasteReq : 2;
     uint8 HVAC_1_FraganceRatioWarn : 2;
     uint8 HVAC_1_IonModeReq : 2;
     uint8 HVAC_1_PM10_Value_L : 2;

     
     uint8 HVAC_1_FraganceTaste : 2;
     uint8 HVAC_1_FragTaste1RemanentRatio : 4;
     uint8 HVAC_1_FraganceConcentrationReq : 2;

     
     uint8 HVAC_1_FragTaste2RemanentRatio : 4;
     uint8 HVAC_1_FraganceBoxID : 2;
     uint8 HVAC_1_FraganceConcentration : 2;

     
     uint8 HVAC_1_OHX_EXV_PstReq_H : 2;
     uint8 HVAC_1_UVCSwith : 2;
     uint8 HVAC_1_FragTaste3RemanentRatio: 4;

     
     uint8 HVAC_1_OHX_EXV_PstReq_L : 8;

     
     uint8 HVAC_1_CHI_EXV_PstReq_H : 8;

     
     uint8 HVAC_1_EVA_EXV_PstReq_H : 6;
     uint8 HVAC_1_CHI_EXV_PstReq_L : 2;
     /*********************************/
     uint8 HVAC_1_HeataValve : 1;
     uint8 HVAC_1_IconInletValve : 1;
     uint8 HVAC_1_CoolingValve : 1;
     uint8 HVAC_1_DehumidifyValve : 1;
     uint8 HVAC_1_EVA_EXV_PstReq_L : 4;

     
     uint8 HVAC_1_ECV_PosnSet : 8;

     
     uint8 HVAC_1_WarmupReq : 1;
     uint8 HVAC_1_UnlockVentilationSt : 1;
     uint8 HVAC_1_WasteHeatTempMinReq : 6;

     
     uint8 HVAC_1_ECP_EXV_PstReq_H : 2;
     uint8 HVAC_1_HeatPumpMode : 5;
     uint8 HVAC_1_PM25CirReq : 1;

     
     uint8 HVAC_1_ECP_EXV_PstReq_L : 8;

     
     uint8 HVAC_1_ECPPwrConsump_H : 8;

     
     uint8 HVAC_1_WasteHeatTempMaxReq_H : 5;
     uint8 HVAC_1_ECPPwrConsump_L : 3;

     
     uint8 HVAC_1_RawEvaTempVD : 1; 
     uint8 HVAC_1_CabinHeatReq : 3;
     uint8 Unused7 : 3;	
     uint8 HVAC_1_WasteHeatTempMaxReq_L : 1;
     /*********************************/ 
     uint8 Unused8 : 8;

     
     uint8 HVAC_1_PM25ValueOut_H : 8;

     
     uint8 HVAC_1_AirCirculationReqVD: 1;
     uint8 Unused9 : 4;
     uint8 HVAC_1_PM25ValueOutVD: 1;
     uint8 HVAC_1_PM25ValueOut_L : 2;

     
     uint8 HVAC_1_AirCirculationReq : 8;

     
     uint8 HVAC_1_FraganceTasteRemanentRatioResetReq : 2;
     uint8 HVAC_1_FraganceSwitchSt : 2;
     uint8 HVAC_1_BlowerSt: 4;

     uint8 HVAC_1_PTCRsestReq : 2;
     uint8 HVAC_1_PTCOnReq : 2;
     uint8 HVAC_1_ECPDriveReq : 2;
     uint8 HVAC_1_PM25WorkCmd : 2;
 
     
     uint8 HVAC_1_EVA_EXVStallDetEnable : 2;
     uint8 HVAC_1_OHX_EXVStallDetEnable : 2;
     uint8 HVAC_1_OHX_EXVMoveEnable : 1;
     uint8 HVAC_1_PTCDischargeReq : 2;
     uint8 HVAC_1_PTCEmergencyOffReq : 1;

     
     uint8 HVAC_1_EVA_EXVMoveEnable : 1;
     uint8 HVAC_1_OHX_EXVLmhTimeCinfg : 3;
     uint8 HVAC_1_OHX_EXVMoveCtr : 1;
     uint8 HVAC_1_OHX_EXVInitial : 3;
     /*********************************/
     uint8 HVAC_1_ECP_EXVMoveEnable : 1;
     uint8 HVAC_1_EVA_EXVLmhTimeCinfg : 3;
     uint8 HVAC_1_EVA_EXVMoveCtr : 1;
     uint8 HVAC_1_EVA_EXVInitial : 3;

     
     uint8 HVAC_1_ECP_EXVLmhTimeCinfg : 3;
     uint8 HVAC_1_ECP_EXVInitial : 3;
     uint8 HVAC_1_ECP_EXVStallDetEnable : 2;

     
     uint8 HVAC_1_CHI_EXVMoveCtr : 1;
     uint8 HVAC_1_CHI_EXVInitial : 3;
     uint8 HVAC_1_CHI_EXVStallDetEnable : 2;
     uint8 HVAC_1_CHI_EXVMoveEnable : 1;
     uint8 HVAC_1_ECP_EXVMoveCtr : 1;

     
     uint8 Unused10 : 5;
     uint8 HVAC_1_CHI_EXVLmhTimeCinfg : 3;

     
     uint8 Unused11 : 8;
     uint8 Unused12 : 8;
     uint8 Unused13 : 8;
     uint8 Unused14 : 8;
} CanIf_tstrTxMsgType_HVAC_1; /*0x2FF*/


/******************************************************************************/   
/* Receive Signal structures                                                  */ 
/******************************************************************************/  
typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
	 uint8 Unused4 : 8;	
	 uint8 Unused5 : 8;	
	 uint8 BMC_BatVolt_H : 7;	
     uint8 Unused6 : 1;	
     uint8 Unused7 : 5;	
	 uint8 BMC_BatVolt_L : 3;	 
     /*********************************/
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;	
	 uint8 Unused14 : 8;	
	 uint8 Unused15 : 8;
     /*********************************/
     uint8 Unused16 : 8;	
     uint8 Unused17 : 8;	
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
	 uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     /*********************************/
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
	 uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     /*********************************/
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;	
	 uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     /*********************************/
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
	 uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     /*********************************/
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
	 uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     /*********************************/
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;	
	 uint8 Unused62 : 8;	
	 uint8 Unused63 : 8;
} CanIf_tstrRxMsgType_BMC_1;  /*0x198*/


typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
	 uint8 Unused4 : 8;	
	 uint8 Unused5 : 8;	
     uint8 Unused6 : 8;	
     uint8 Unused7 : 8;	 
     /*********************************/
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;	
	 uint8 Unused14 : 8;	
	 uint8 Unused15 : 8;
     /*********************************/
     uint8 BMC_BattSocDisp_H : 4;
     uint8 Unused16 : 4;
     uint8 Unused17 : 2;
     uint8 BMC_BattSocDisp_L : 6;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
	 uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     /*********************************/
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
	 uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     /*********************************/
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;	
	 uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     /*********************************/
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
	 uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     /*********************************/
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
	 uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     /*********************************/
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;	
	 uint8 Unused62 : 8;	
	 uint8 Unused63 : 8;
} CanIf_tstrRxMsgType_BMC_22;  /*0x32C*/
	 
typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
     
     uint8 BMC_BattTempMin_H : 1;
     uint8 Unused4 : 7;
     
     uint8 BMC_BattTempAvg_H : 1;
     uint8 BMC_BattTempMin_L : 7;
     
     uint8 BMC_BattTempMax_H : 1;
     uint8 BMC_BattTempAvg_L : 7;
     
     uint8 Unused5 : 1;	
     uint8 BMC_BattTempMax_L : 7; 
     /*********************************/
     uint8 Unused6 : 8;	
     uint8 Unused7 : 8;	
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;
     /*********************************/
     uint8 Unused14 : 8;	
	 uint8 Unused15 : 8;
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     /*********************************/
     uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     /*********************************/
     uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;	
     /*********************************/
     uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     /*********************************/
     uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     /*********************************/
     uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
} CanIf_tstrRxMsgType_BMC_3;  /*0x3B0*/


typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
     uint8 Unused4 : 8;
     uint8 Unused5 : 8;	
     uint8 Unused6 : 8;
     uint8 BMC_CoolantTargTemp_H:1;
     uint8 Unused7 : 7;	
     /*********************************/
     uint8 Unused8 : 1;	
     uint8 BMC_CoolantTargTemp_L : 7;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;
     uint8 Unused14 : 8;
     uint8 Unused15 : 8;
     /*********************************/
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     /*********************************/
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     /*********************************/
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     /*********************************/
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     /*********************************/
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     /*********************************/
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
	 uint8 Unused63 : 8;
} CanIf_tstrRxMsgType_BMC_4;  /*0x448*/


typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
     uint8 PowerModeSt : 3;
	 uint8 Unused3 : 5;	
     uint8 Unused4 : 8;
     uint8 Unused5 : 8;	
     uint8 Unused6 : 8;
     uint8 Unused7 : 8;	
     /*********************************/
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;
     uint8 Unused14 : 8;
     uint8 Unused15 : 8;
     /*********************************/
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     /*********************************/
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     /*********************************/
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     /*********************************/
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     /*********************************/
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     /*********************************/
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
	 uint8 Unused63 : 8;
} CanIf_tstrRxMsgType_CCU_1;  /*0x268*/


typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
     
     uint8 Unused3 : 5;	
     uint8 ACmaxSt : 1;
     uint8 ACSt : 1;
     uint8 RearDefrostSt : 1;
     
     uint8 Unused4 : 3;
     uint8 WindExitMode : 3;
     uint8 AutoSt : 1;
     uint8 DualSynSt : 1;
     
     uint8 Unused5 : 6;
     uint8 AirCirculationSt : 2;
     
     uint8 Unused6 : 2;
     uint8 DriverTempSelect : 5;
     uint8 Unused7 : 1;	
     
     uint8 Unused8 : 4;	
     uint8 WindExitSpd : 4;	
     /*********************************/
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
     
     uint8 ComfortCfgSt : 2;
	 uint8 Unused11 : 1;
     uint8 PsnTempSelect : 5;
     
     uint8 AirCirCfgSt : 1;
	 uint8 Unused12 : 7;
     
     uint8 AirQqualitySenSt : 2;	
	 uint8 Unused13 : 6;
     
     uint8 ExterTempSnsDiag : 2;
     uint8 SolarFeaturesCfgSt :1;
     uint8 EvapratorSelfCleanSt : 1;
     uint8 SceneDisplayReq : 2;
     uint8 FanspeedCfgSt : 2;
     
     uint8 Unused14 : 8;
     uint8 Unused15 : 8;
     /*********************************/
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18 : 8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     /*********************************/
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26 : 8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     /*********************************/
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34 : 8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     /*********************************/
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42 : 8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     /*********************************/
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50 : 8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     /*********************************/
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58 : 8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
	 uint8 Unused63 : 8;
} CanIf_tstrRxMsgType_CCU_2;  /*0x330*/




typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
     uint8 BCS_VehSpd_H : 8;
	 uint8 Unused3 : 2;	
     uint8 BCS_VehSpdVD : 1;
     uint8 BCS_VehSpd_L : 5;
     uint8 Unused4 : 8;
     uint8 Unused5 : 8;	
     uint8 Unused6 : 8;
     /*********************************/
     uint8 Unused7 : 8;	
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;
     uint8 Unused14 : 8;
     /*********************************/
     uint8 Unused15 : 8;
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
     /*********************************/
     uint8 Unused23 : 8;
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
     /*********************************/
     uint8 Unused31 : 8;
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
     /*********************************/
     uint8 Unused39 : 8;
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
     /*********************************/
     uint8 Unused47 : 8;
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
     /*********************************/
     uint8 Unused55 : 8;
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
} CanIf_tstrRxMsgType_CCU_BCS_2_C;  /*0x160*/


typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
     uint8 Unused4 : 8;
     uint8 Unused5 : 8;	
     uint8 Unused6 : 8;
     uint8 Unused7 : 8;	
     /*********************************/
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;
     uint8 Unused14 : 8;
     uint8 Unused15 : 8;
     /*********************************/
     uint8 Unused16 : 8;
     uint8 RawExterTemp_H : 8;
     uint8 Unused17 : 5;
     uint8 RawExterTemp_L : 3;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
     /*********************************/
     uint8 Unused23 : 8;
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
     /*********************************/
     uint8 Unused31 : 8;
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
     /*********************************/
     uint8 Unused39 : 8;
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
     /*********************************/
     uint8 Unused47 : 8;
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
     /*********************************/
     uint8 Unused55 : 8;
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
} CanIf_tstrRxMsgType_CCU_ZCUF_1;  /*0x310*/


typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
     uint8 Unused4 : 8;
     uint8 RawCabinTemp_H : 8;
     uint8 Unused5 : 5;	
     uint8 RawCabinTemp_L : 3;
     uint8 Unused6 : 8;
     /*********************************/
     uint8 Unused7 : 8;	
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 8;
     uint8 Unused14 : 8;
     /*********************************/
     uint8 Unused15 : 8;
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
     /*********************************/
     uint8 Unused23 : 8;
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
     /*********************************/
     uint8 Unused31 : 8;
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
     /*********************************/
     uint8 Unused39 : 8;
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
     /*********************************/
     uint8 Unused47 : 8;
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
     /*********************************/
     uint8 Unused55 : 8;
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
} CanIf_tstrRxMsgType_CCU_ZCUR_5;  /*0x312*/


typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
     
     uint8 ITS_HeaterPumpStpSpdErr : 4;
     uint8 ITS_FanRunSt : 1;
	 uint8 Unused3 : 3;	
     
     uint8 Unused4 : 1;
     uint8 ITS_EcvErr : 1;
     uint8 Unused5 : 2;
     uint8 ITS_ValveModeAct :4;
     
     uint8 ITS_ECVPosnAct_H : 5;
     uint8 Unused6 : 2;
     uint8 ITS_ECVMotorSt : 1;
     
     uint8 Unused7 : 5;	
     uint8 ITS_ECVPosnAct_L : 3;
     
     uint8 Unused8 : 8;	
     /*********************************/
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;
	 uint8 Unused12 : 8;
     
     uint8 Unused13 : 4;
     uint8 ITS_ChillerInletTempErr : 1;
     uint8 ITS_BatteryInletTempErr : 1;
     uint8 ITS_MotorInletTempErr : 1;
	 uint8 Unused14 : 1;
     
     uint8 ITS_MotorInletTemp_H : 8;
     uint8 ITS_MotorInletTemp_L : 8;
     
     uint8 ITS_BatteryInletTemp_H : 8;
     /*********************************/
     uint8 ITS_BatteryInletTemp_L : 8;
     uint8 ITS_ChillerInletTemp_H : 8;
     uint8 ITS_ChillerInletTemp_L : 8;
     uint8 Unused15 : 8;
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
     uint8 Unused18 : 8;
	 uint8 Unused19:  8;			
     /*********************************/
     uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;
     uint8 Unused23 : 8;
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;		
     /*********************************/
     uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;
     uint8 Unused31 : 8;
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;		
     /*********************************/
     uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;
     uint8 Unused39 : 8;
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
     /*********************************/
     uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
     uint8 Unused47 : 8;
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
     /*********************************/
     uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
     uint8 Unused55 : 8;
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
} CanIf_tstrRxMsgType_ITS_1;  /*0x370*/





typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
     
     uint8 Unused4 : 1;
     uint8 VCU_HVAC_PTCdelayEn: 1;
     uint8 Unused5 : 6;	
     
     uint8 Unused6 : 1;
     uint8 VCU_HVAC_InterCirReq: 1;
     uint8 Unused7 : 6;	
     
     uint8 VCU_HVBatCoolPrioReq_H : 2;
	 uint8 Unused8 : 6;
     
     uint8 Unused9 : 6;	
     uint8 VCU_HVBatCoolPrioReq_L : 2;
     /*********************************/
	 uint8 Unused10 : 3;
     uint8 VCU_HVAC_CabinCoolHeatOffReq : 1;
	 uint8 Unused11 : 4;
     
     uint8 VCU_BattCoolPwrReq_H : 4;
	 uint8 Unused12 : 4;
     
     uint8 Unused13 : 4;
     uint8 VCU_BattCoolPwrReq_L : 4;
         
     uint8 Unused14 : 8;
     uint8 Unused15 : 8;
     uint8 Unused16:  8;	
     uint8 Unused17 : 8;	
	 uint8 Unused18 : 8;
     /*********************************/
	 uint8 Unused19 : 8;	
     uint8 Unused20 : 8;	
     uint8 Unused21 : 8;
     uint8 Unused22 : 8;	
     uint8 Unused23 : 8;	
     uint8 VCU_HVBatHeatPrioReq_H : 3;
     uint8 VCU_PwrHeatEn : 1;
	 uint8 Unused24 : 4;	
     
     uint8 Unused25 : 7;	
     uint8 VCU_HVBatHeatPrioReq_L : 1;
	 uint8 Unused26:  8;	
     /*********************************/
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;
     uint8 Unused29 : 8;
     uint8 Unused30 : 8;	
     uint8 Unused31 : 8;	
	 uint8 Unused32:  8;
     uint8 Unused33 : 8;	
	 uint8 Unused34 : 8;	
     /*********************************/
	 uint8 Unused35 : 8;
     uint8 Unused36 : 8;
     uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
     uint8 Unused39 : 8;	
	 uint8 Unused40:  8;
     uint8 Unused41 : 8;	
	 uint8 Unused42 : 8;
     /*********************************/
	 uint8 Unused43 : 8;	
     uint8 Unused44 : 8;
     uint8 Unused45 : 8;
     uint8 Unused46 : 8;	
     
     uint8 VCU_HVACPwrLimit_H : 1;
	 uint8 Unused47 : 1;	
     uint8 VCU_PwrCoolEn : 1;
     uint8 Unused48 : 5;
     
     uint8 Unused49 : 3;
     uint8 VCU_HVACPwrLimit_L : 5;
     
     uint8 Unused50 : 4;
     uint8 VCU_HVACPwrLimitAct : 1;
     uint8 Unused51 : 3;
     
    
     uint8 Unused52 : 8;	
     /*********************************/
     uint8 Unused53 : 8;
     uint8 Unused54 : 8;
	 uint8 Unused55:  8;
     
	 uint8 Unused56 : 6;
     uint8 VCU_HVACEcoModeReq : 1;
     uint8 Unused57 : 1;

     uint8 Unused58 : 8;
     uint8 Unused59 : 8;
     uint8 Unused60 : 8;	
     uint8 Unused61 : 8;	
	 /*********************************/
     uint8 Unused62:  8;
     uint8 Unused63:  8;
     uint8 Unused64:  8;
     uint8 Unused65:  8;
     uint8 Unused66:  8;
     uint8 Unused67:  8;
     uint8 Unused68:  8;
     uint8 Unused69:  8;
} CanIf_tstrRxMsgType_VCU_2;  /*0x338*/

typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
     uint8 Unused4 : 8;
     uint8 Unused5 : 8;	
     uint8 Unused6 : 8;
     uint8 Unused7 : 8;	
     /*********************************/
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 5;
     uint8 VCU_HeatRecEnChiller : 1;
     uint8 Unused14 : 1;
     uint8 Unused15 : 8;
     /*********************************/
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     /*********************************/
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     /*********************************/
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     /*********************************/
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     /*********************************/
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     /*********************************/
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
	 uint8 Unused63 : 8;
} CanIf_tstrRxMsgType_VCU_3;  /*0x3B8*/

typedef struct
{	
     uint8 Unused0 : 8;	
	 uint8 Unused1 : 8;	
	 uint8 Unused2 : 8;	
	 uint8 Unused3 : 8;	
     uint8 Unused4 : 8;
     uint8 Unused5 : 8;	
     uint8 Unused6 : 8;
     uint8 Unused7 : 8;	
     /*********************************/
     uint8 Unused8 : 8;	
     uint8 Unused9 : 8;	
	 uint8 Unused10 : 8;	
	 uint8 Unused11 : 8;	
	 uint8 Unused12 : 8;	
	 uint8 Unused13 : 3;
     uint8 VCU_HVAC_PTCShutlmme : 1;
     uint8 Unused14 : 4;
     uint8 Unused15 : 8;
     /*********************************/
     uint8 Unused16 : 8;
     uint8 Unused17 : 8;
	 uint8 Unused18:  8;	
	 uint8 Unused19 : 8;	
	 uint8 Unused20 : 8;	
	 uint8 Unused21 : 8;	
     uint8 Unused22 : 8;	
	 uint8 Unused23 : 8;
     /*********************************/
     uint8 Unused24 : 8;	
     uint8 Unused25 : 8;	
	 uint8 Unused26:  8;	
	 uint8 Unused27 : 8;	
	 uint8 Unused28 : 8;	
	 uint8 Unused29 : 8;	
     uint8 Unused30 : 8;	
	 uint8 Unused31 : 8;
     /*********************************/
     uint8 Unused32 : 8;	
     uint8 Unused33 : 8;	
	 uint8 Unused34:  8;	
	 uint8 Unused35 : 8;	
	 uint8 Unused36 : 8;	
	 uint8 Unused37 : 8;
     uint8 Unused38 : 8;	
	 uint8 Unused39 : 8;
     /*********************************/
     uint8 Unused40 : 8;	
     uint8 Unused41 : 8;	
	 uint8 Unused42:  8;	
	 uint8 Unused43 : 8;	
	 uint8 Unused44 : 8;	
	 uint8 Unused45 : 8;	
     uint8 Unused46 : 8;	
	 uint8 Unused47 : 8;
     /*********************************/
     uint8 Unused48 : 8;	
     uint8 Unused49 : 8;	
	 uint8 Unused50:  8;	
	 uint8 Unused51 : 8;	
	 uint8 Unused52 : 8;	
	 uint8 Unused53 : 8;	
     uint8 Unused54 : 8;	
	 uint8 Unused55 : 8;
     /*********************************/
     uint8 Unused56 : 8;	
     uint8 Unused57 : 8;	
	 uint8 Unused58:  8;	
	 uint8 Unused59 : 8;	
	 uint8 Unused60 : 8;	
	 uint8 Unused61 : 8;
     uint8 Unused62 : 8;	
	 uint8 Unused63 : 8;
} CanIf_tstrRxMsgType_VCU_4;  /*0x3A2*/
/********************************************************************************/   
/* Send Message unions 															*/
/********************************************************************************/ 
typedef union 
{
	CanIf_tstrTxMsgType_HVAC_1 Ipdu;
	uint8 _c[64];
} CanIf_tuniTxMsgType_HVAC_1; /*0x2FF*/

/********************************************************************************/   
/* Receive Message unions */
/********************************************************************************/ 
typedef union 
{
	CanIf_tstrRxMsgType_BMC_1 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_BMC_1; /*0x198*/

typedef union 
{
	CanIf_tstrRxMsgType_BMC_22 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_BMC_22; /*0x32C*/


typedef union 
{
	CanIf_tstrRxMsgType_BMC_3 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_BMC_3; /*0x3B0*/

typedef union 
{
	CanIf_tstrRxMsgType_BMC_4 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_BMC_4; /*0x448*/


typedef union 
{
	CanIf_tstrRxMsgType_CCU_1 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_CCU_1; /*0x268*/

typedef union 
{
	CanIf_tstrRxMsgType_CCU_2 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_CCU_2; /*0x330*/

typedef union 
{
	CanIf_tstrRxMsgType_CCU_BCS_2_C Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_CCU_BCS_2_C; /*0x160*/

typedef union 
{
	CanIf_tstrRxMsgType_CCU_ZCUF_1 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_CCU_ZCUF_1; /*0x310*/

typedef union 
{
	CanIf_tstrRxMsgType_CCU_ZCUR_5 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_CCU_ZCUR_5; /*0x312*/

typedef union 
{
	CanIf_tstrRxMsgType_ITS_1 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_ITS_1; /*0x370*/

typedef union 
{
	CanIf_tstrRxMsgType_VCU_2 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_VCU_2; /*0x338*/

typedef union 
{
	CanIf_tstrRxMsgType_VCU_3 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_VCU_3; /*0x3B8*/


typedef union 
{
	CanIf_tstrRxMsgType_VCU_4 Ipdu;
	uint8 _c[64];
} CanIf_tuniRxMsgType_VCU_4; /*0x3A2*/



/******************************************************************************/
/* VARIABLE DECLARATION                                                       */
/******************************************************************************/

/******************************************************************************/   
/* Databuffer for send  objects                                               */ 
/******************************************************************************/  
extern CanIf_tuniTxMsgType_HVAC_1 CanIf_uniTxMsgType_HVAC_1;   /*0X2FF*/
/******************************************************************************/   
/* Databuffer for receive objects                                             */ 
/******************************************************************************/   
extern CanIf_tuniRxMsgType_BMC_1 CanIf_uniRxMsgType_BMC_1;/*0X198*/
extern CanIf_tuniRxMsgType_BMC_22 CanIf_uniRxMsgType_BMC_22;/*0X32C*/
extern CanIf_tuniRxMsgType_BMC_3 CanIf_uniRxMsgType_BMC_3;/*0X3B0*/
extern CanIf_tuniRxMsgType_BMC_4 CanIf_uniRxMsgType_BMC_4;/*0X448*/
extern CanIf_tuniRxMsgType_CCU_1 CanIf_uniRxMsgType_CCU_1;/*0X268*/
extern CanIf_tuniRxMsgType_CCU_2 CanIf_uniRxMsgType_CCU_2;/*0X330*/
extern CanIf_tuniRxMsgType_CCU_BCS_2_C CanIf_uniRxMsgType_CCU_BCS_2_C;/*0X160*/
extern CanIf_tuniRxMsgType_CCU_ZCUF_1 CanIf_uniRxMsgType_CCU_ZCUF_1;/*0X310*/
extern CanIf_tuniRxMsgType_CCU_ZCUR_5 CanIf_uniRxMsgType_CCU_ZCUR_5;/*0X312*/
extern CanIf_tuniRxMsgType_ITS_1 CanIf_uniRxMsgType_ITS_1;/*0X370*/
extern CanIf_tuniRxMsgType_VCU_2 CanIf_uniRxMsgType_VCU_2;/*0X338*/
extern CanIf_tuniRxMsgType_VCU_3 CanIf_uniRxMsgType_VCU_3;/*0X3B8*/
extern CanIf_tuniRxMsgType_VCU_4 CanIf_uniRxMsgType_VCU_4;/*0X3A2*/


/*control variabiles*/
extern const CanIf_tstrTxMsgInfoType CanIf_kstrTxMsgInfo[COM_TXPDUNUM]; 
extern const CanIf_tstrDataAddrType CanIf_kstrTxPduBuf[COM_TXPDUNUM];
extern CanIf_tstrTxCtrlType CanIf_strTxCtrl[COM_TXPDUNUM];

extern const CanIf_tstrRxMsgInfoType CanIf_kstrRxMsgInfo[COM_RXPDUNUM];
extern const CanIf_tstrDataAddrType CanIf_kstrRxPduBuf[COM_RXPDUNUM];
extern CanIf_tstrRxCtrlType CanIf_strRxCtrl[COM_RXPDUNUM];

extern const uint32 CanIf_ku32TpRxMsgId[TP_RXPDUNUM];
extern const CanTp_tenuTpTaType CanIf_kenuTpTa[TP_RXPDUNUM];
/******************************************************************************/
/* GLOBAL FUNCTIONS DECLARATION                                               */
/******************************************************************************/
/******************************************************************************/   
/*Rx indication function definition                                           */
/******************************************************************************/
extern void AppCom_vidRxInd_BMC_1(void); /*0X198*/
extern void AppCom_vidRxInd_BMC_22(void); /*0X32C*/
extern void AppCom_vidRxInd_BMC_3(void); /*0X3B0*/
extern void AppCom_vidRxInd_BMC_4(void); /*0X448*/
extern void AppCom_vidRxInd_CCU_1(void); /*0X268*/
extern void AppCom_vidRxInd_CCU_2(void); /*0X330*/
extern void AppCom_vidRxInd_CCU_BCS_2_C(void); /*0X160*/
extern void AppCom_vidRxInd_CCU_ZCUF_1(void); /*0X310*/
extern void AppCom_vidRxInd_CCU_ZCUR_5(void); /*0X312*/
extern void AppCom_vidRxInd_ITS_1(void); /*0X370*/
extern void AppCom_vidRxInd_VCU_2(void); /*0X338*/
extern void AppCom_vidRxInd_VCU_3(void); /*0X3B8*/
extern void AppCom_vidRxInd_VCU_4(void); /*0X3A2*/
/******************************************************************************/   
/*rx Ipdu timeout indication function definition                              */
/******************************************************************************/ 
extern void AppCom_vidToInd_BMC_1(void);/*0X198*/
extern void AppCom_vidToInd_BMC_22(void);/*0X32C*/
extern void AppCom_vidToInd_BMC_3(void);/*0X3B0*/
extern void AppCom_vidToInd_BMC_4(void);/*0X448*/
extern void AppCom_vidToInd_CCU_1(void);/*0X268*/
extern void AppCom_vidToInd_CCU_2(void);/*0X330*/
extern void AppCom_vidToInd_CCU_BCS_2_C(void);/*0X160*/
extern void AppCom_vidToInd_CCU_ZCUF_1(void);/*0X310*/
extern void AppCom_vidToInd_CCU_ZCUR_5(void);/*0X312*/
extern void AppCom_vidToInd_ITS_1(void);/*0X370*/
extern void AppCom_vidToInd_VCU_2(void);/*0X338*/
extern void AppCom_vidToInd_VCU_3(void);/*0X3B8*/
extern void AppCom_vidToInd_VCU_4(void);/*0X3A2*/
/******************************************************************************/   
/*tx Ipdu indication function definition                                      */
/******************************************************************************/   
extern void AppCom_vidTxInd_HVAC_1(uint8 *pu8Data); /*0X22F*/


#endif  /* XXX_H */ 

/*-------------------------------- end of file ----------------------------*/
