/******************************************************************************/
/* PROJECT  :  CHJ_D01                                                        */
/******************************************************************************/
/* !Layer           : Can                                                     */
/*                                                                            */
/* !Component       : Can                                                     */
/* !Description     : Interface for Managing the can                          */
/*                                                                            */
/* !Module          : can                                                     */
/* !Description     : can                                                     */
/*                                                                            */
/* !File            : Can_Cfg.c                                               */
/*                                                                            */
/* !Scope           : Private                                                 */
/*                                                                            */
/* !Target          : RH850F1K_S1_R7F7016843                                  */
/*                                                                            */
/* !Vendor          : (VALEO Climate Control China)                           */
/*                                                                            */
/* Coding language  : C                                                       */
/*                                                                            */
/* all rights reserved                                                        */
/******************************************************************************/
#include "Device.h"
#include "Can_Cfg.h"
#include "Port.h"
/*===========================================================================*/

/******************************************************************************/
/* GLOBAL FUNCTION DECLARATION                                                */
/******************************************************************************/
const CAN_RX_RULE_TYPE CAN_RX_RULE_TABLE[CAN_RX_RULE_NUM] = {
		/* CAN 1 reception rules */
		/* NO.0 : ID = 0x3DB will be accepted, Receive FIFO Buffer 0 */
		{{0x000003DBUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000001UL}},
		/* NO.1 : ID = 0x3BC will be accepted, Receive FIFO Buffer 1 */
		{{0x000003BCUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000002UL}},
		/* NO.2 : ID = 0x51C will be accepted, Receive FIFO Buffer 1 */
		{{0x0000051CUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000002UL}},
		/* NO.3 : ID = 0x3CC will be accepted, Receive FIFO Buffer 1 */
		{{0x000003CCUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000002UL}},
#if 0
		/* NO.4 : ID = 0x530 will be accepted, Receive FIFO Buffer 4 */
		//{{0x00000530UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}}, //use to send msg to control Dc Motor Board
#else
		/* NO.4 : ID = 0x008 will be accepted, Receive FIFO Buffer 4 */
		{{0x00000008UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}}, //use to recv msg from control Dc Motor Board
#endif
		/* NO.5 : ID = 0x390 will be accepted, Receive FIFO Buffer 4 */
		{{0x00000390UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}},
		/* NO.6 : ID = 0x295 will be accepted, Receive FIFO Buffer 4 */
		{{0x00000295UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000010UL}},
		/* NO.7 : ID = 0x95 will be accepted, Receive FIFO Buffer 5 */
		{{0x00000095UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
		/* NO.8 : ID = 0x3A0 will be accepted, Receive FIFO Buffer 5 */
		{{0x000003A0UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
	    /* NO.9 : ID = 0x620 will be accepted, Receive FIFO Buffer 5 */
		{{0x00000620UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
#if 0
		/* NO.10 : ID = 0x560 will be accepted, Receive FIFO Buffer 5 */
		{{0x00000560UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
		/* NO.11: ID = 0x400 will be accepted, Receive FIFO Buffer 6 */
		{{0x00000400UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.12 : ID = 0x42A will be accepted, Receive FIFO Buffer 6 */
		{{0x0000042AUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.13: ID = 0x419 will be accepted, Receive FIFO Buffer 6 */
		{{0x00000419UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.14 : ID = 0x405 will be accepted, Receive FIFO Buffer 6 */
		{{0x00000405UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.15 : ID = 0x429 will be accepted, Receive FIFO Buffer 6 */
#else
		/* NO.10 : ID = 0x00A will be accepted, Receive FIFO Buffer 5 */
		{{0x0000000AUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000020UL}},
		/* NO.11: ID = 0x00B will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000BUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.12 : ID = 0x00C will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000CUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.13: ID = 0x00D will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000DUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.14 : ID = 0x00E will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000EUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
		/* NO.15 : ID = 0x00F will be accepted, Receive FIFO Buffer 6 */
		{{0x0000000FUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000040UL}},
#endif	
		/* NO.16 : ID = 0x7A3 will be accepted, Receive FIFO Buffer 7 */
		{{0x000007A3UL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000080UL}},
		/* NO.17 : ID = 0x7DF will be accepted, Receive FIFO Buffer 7 */
		{{0x000007DFUL, 0xDFFFFFFFUL, 0x00000000UL, 0x00000080UL}},
};

const Port_tstrPortCfgType Can_akstrPortCfg[]=
{
    /*CAN_u8CAN1TX_ID*/
    {
       Port_10,
	   7u
    },
    /*CAN_u8CAN1RX_ID*/
    {
       Port_10,
	   6u
    }
};

/*-------------------------------- end of file -------------------------------*/
