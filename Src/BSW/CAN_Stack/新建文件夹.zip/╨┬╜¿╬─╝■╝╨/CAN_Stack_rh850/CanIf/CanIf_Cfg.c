/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
#include "CanIf_Cfg.h"
#include "CanIf.h"
/******************************************************************************/
/* DEFINES                                                                    */
/******************************************************************************/


/******************************************************************************/
/* CONSTANTS DEFINITION                                                       */
/******************************************************************************/


const static uint8  CanIf_au8DefaultValue_FF[8]=
{
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu
};

/*********send msg info**********/
const CanIf_tstrTxMsgInfoType CanIf_kstrTxMsgInfo[COM_TXPDUNUM] = 
{ 
	/*msg0*/
	{
		{0x398u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		}, 
		100u, /*cycle time*/
		0u,  /*cycle time fast*/
		0u,   /*NbOfRepetition*/
		MST_Cycle, /*Msg type*/
		&AppCom_vidTxInd_AC_PwrAlloted, /*call back func*/
		0u	/*msg buf number*/
	},
	/*msg1*/
	{
		{0x3E8u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		100u, /*cycle time*/
		0u,  /*cycle time fast*/
		0u,   /*NbOfRepetition*/
		MST_Cycle, /*Msg type*/
		&AppCom_vidTxInd_AC_ACCtrlFeedback, /*call back func*/
		1u	/*msg buf number*/
	},
	/*msg2*/
	{
		{0x538u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		100u, /*cycle time*/
		0u,  /*cycle time fast*/
		0u,   /*NbOfRepetition*/
		MST_Cycle, /*Msg type*/
		&AppCom_vidTxInd_AC_TempInfo, /*call back func*/
		2u	/*msg buf number*/
	},
	/*msg3*/
	{
		{0x558u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		100u, /*cycle time*/
		0u,  /*cycle time fast*/
		0u,   /*NbOfRepetition*/
		MST_Cycle, /*Msg type*/
		&AppCom_vidTxInd_AC_PwrInfo, /*call back func*/
		3u	/*msg buf number*/
	},
	/*msg4*/
	{
		{0x609u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		5000u, /*cycle time*/
		0u,  /*cycle time fast*/
		0u,   /*NbOfRepetition*/
		MST_Cycle, /*Msg type*/
		&AppCom_vidTxInd_AC_SHMNumber, /*call back func*/
		4u	/*msg buf number*/
	},
	/*msg5*/
	{
		{0x508u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		100u, /*cycle time*/
		0u,  /*cycle time fast*/
		0u,   /*NbOfRepetition*/
		MST_Cycle, /*Msg type*/
		&AppCom_vidTxInd_AC_LightAndTemp, /*call back func*/
		5u	/*msg buf number*/
	}	
};

/**********receive msg info********/
const CanIf_tstrRxMsgInfoType CanIf_kstrRxMsgInfo[COM_RXPDUNUM] = 
{ 
	/*msg0*/
	{
		{0x095u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_ACU_DirverInfo, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_ACU_DirverInfo /*TOIndication*/
	},
	/*msg1*/
	{
		{0x3DBu, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/
			
		&AppCom_vidRxInd_GW_BD_HU_ACCtrlReq, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_HU_ACCtrlReq /*TOIndication*/
	},
	/*msg2*/
	{
		{0x51Cu, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_HU_LightandSRCtrlReq, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_HU_LightandSRCtrlReq /*TOIndication*/
	},
	/*msg3*/
	{
		{0x530u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_VCU_PT_ACPwrSpd, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_VCU_PT_ACPwrSpd /*TOIndication*/
	},
	/*msg4*/
	{
		{0x560u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_BMS_TempIso, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_BMS_TempIso /*TOIndication*/
	},
	/*msg5*/
	{
		{0x390u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_VCU_PT_HVCmdandPwrAllot, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_VCU_PT_HVCmdandPwrAllot /*TOIndication*/
	},	
	/*msg6*/
	{
		{0x295u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_ESP_GeneralStatus, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_ESP_GeneralStatus /*TOIndication*/
	},		
	/*msg7*/
	{
		{0x3A0u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_BMS_RESSPTCandCmpsReq, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_BMS_RESSPTCandCmpsReq /*TOIndication*/
	},
	/*msg8*/
	{
		{0x3BCu, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_HU_DriveCtrlReq, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_HU_DriveCtrlReq /*TOIndication*/
	},
	/*msg9*/
	{
		{0x3CCu, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_IPC_DisplayInfo, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_IPC_DisplayInfo /*TOIndication*/
	},
	/*msg10*/
	{
		{0x620u, /*ID*/
		8u, /*dlc*/
		(uint8 *)CanIf_au8DefaultValue_FF	/*data buffer addr*/
		},
		TRUE, /*TOMonitored*/
		2000u, /*RxTimeout*/

		&AppCom_vidRxInd_GW_BD_BMS_RESSTempInfo, /*RxIndication*/
		&AppCom_vidToInd_GW_BD_BMS_RESSTempInfo /*TOIndication*/
	}	
};   


const uint32 CanIf_ku32TpRxMsgId[TP_RXPDUNUM]=
{
    0x7A3u,
    0x7DFu
};	

const CanTp_tenuTpTaType CanIf_kenuTpTa[TP_RXPDUNUM]=
{
    CANTP_TTT_PHYSICAL,
    CANTP_TTT_FUNCTIONAL
};

const CanIf_tstrDataAddrType CanIf_kstrRxPduBuf[COM_RXPDUNUM]=
{
	CanIf_uniRxMsgType_GW_BD_ACU_DirverInfo._c, /*0-0X95 D01*/
	CanIf_uniRxMsgType_GW_BD_HU_ACCtrlReq._c,  /*0X3DB D01*/
	CanIf_uniRxMsgType_GW_BD_HU_LightandSRCtrlReq._c,  /*0x51C D01*/
	CanIf_uniRxMsgType_GW_BD_VCU_PT_ACPwrSpd._c,  /*0X530 D01*/
	CanIf_uniRxMsgType_GW_BD_BMS_TempIso._c,  /*0X560 D01*/
	CanIf_uniRxMsgType_GW_BD_VCU_PT_HVCmdandPwrAllot._c, /*0X390 D01*/
	CanIf_uniRxMsgType_GW_BD_ESP_GeneralStatus._c,  /*0X295 D01*/
	CanIf_uniRxMsgType_GW_BD_BMS_RESSPTCandCmpsReq._c, /*0X3A0 D01*/
    CanIf_uniRxMsgType_GW_BD_HU_DriveCtrlReq._c,  /*0X3BC D01*/
	CanIf_uniRxMsgType_GW_BD_IPC_DisplayInfo._c,  /*0X3CC D01*/
	CanIf_uniRxMsgType_GW_BD_BMS_RESSTempInfo._c  /*0X620 D01*/
};

const CanIf_tstrDataAddrType CanIf_kstrTxPduBuf[COM_TXPDUNUM]=
{
	CanIf_uniTxMsgType_AC_PwrAlloted._c, /*0x398 D01*/
	CanIf_uniTxMsgType_AC_ACCtrlFeedback._c, /*0X3E8 D01*/
	CanIf_uniTxMsgType_AC_TempInfo._c, /*0X538 D01*/
	CanIf_uniTxMsgType_AC_PwrInfo._c,  /*0X558 D01*/
	CanIf_uniTxMsgType_AC_SHMNumber._c, /*0X609 D01*/
	CanIf_uniTxMsgType_AC_LightAndTemp._c /*0X508 D01*/
};

/******************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/


/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/


/******************************************************************************/
/* DATA DEFINITION                                                            */
/******************************************************************************/
/******************************************************************************/   
/* Databuffer for receive objects                                             */ 
/******************************************************************************/ 
CanIf_tuniRxMsgType_GW_BD_ACU_DirverInfo CanIf_uniRxMsgType_GW_BD_ACU_DirverInfo;
CanIf_tuniRxMsgType_GW_BD_HU_ACCtrlReq CanIf_uniRxMsgType_GW_BD_HU_ACCtrlReq;
CanIf_tuniRxMsgType_GW_BD_HU_LightandSRCtrlReq CanIf_uniRxMsgType_GW_BD_HU_LightandSRCtrlReq;
CanIf_tuniRxMsgType_GW_BD_VCU_PT_ACPwrSpd CanIf_uniRxMsgType_GW_BD_VCU_PT_ACPwrSpd;
CanIf_tuniRxMsgType_GW_BD_BMS_TempIso CanIf_uniRxMsgType_GW_BD_BMS_TempIso;
CanIf_tuniRxMsgType_GW_BD_VCU_PT_HVCmdandPwrAllot CanIf_uniRxMsgType_GW_BD_VCU_PT_HVCmdandPwrAllot;
CanIf_tuniRxMsgType_GW_BD_ESP_GeneralStatus CanIf_uniRxMsgType_GW_BD_ESP_GeneralStatus;
CanIf_tuniRxMsgType_GW_BD_BMS_RESSPTCandCmpsReq CanIf_uniRxMsgType_GW_BD_BMS_RESSPTCandCmpsReq;
CanIf_tuniRxMsgType_GW_BD_HU_DriveCtrlReq CanIf_uniRxMsgType_GW_BD_HU_DriveCtrlReq;
CanIf_tuniRxMsgType_GW_BD_IPC_DisplayInfo CanIf_uniRxMsgType_GW_BD_IPC_DisplayInfo;
CanIf_tuniRxMsgType_GW_BD_BMS_RESSTempInfo CanIf_uniRxMsgType_GW_BD_BMS_RESSTempInfo;

/******************************************************************************/   
/* Databuffer for send    objects                                             */ 
/******************************************************************************/  
CanIf_tuniTxMsgType_AC_PwrAlloted CanIf_uniTxMsgType_AC_PwrAlloted; 
CanIf_tuniTxMsgType_AC_ACCtrlFeedback CanIf_uniTxMsgType_AC_ACCtrlFeedback; 
CanIf_tuniTxMsgType_AC_TempInfo CanIf_uniTxMsgType_AC_TempInfo; 
CanIf_tuniTxMsgType_AC_PwrInfo CanIf_uniTxMsgType_AC_PwrInfo;
CanIf_tuniTxMsgType_AC_SHMNumber CanIf_uniTxMsgType_AC_SHMNumber;
CanIf_tuniTxMsgType_AC_LightAndTemp CanIf_uniTxMsgType_AC_LightAndTemp;

/*control variable*/
CanIf_tstrRxCtrlType CanIf_strRxCtrl[COM_RXPDUNUM];

CanIf_tstrTxCtrlType CanIf_strTxCtrl[COM_TXPDUNUM];
/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/


/******************************************************************************/
/* LOCAL FUNCTION DEFINITION                                                  */
/******************************************************************************/


/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/


/*-------------------------------- end of file -------------------------------*/
