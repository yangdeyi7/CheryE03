/******************************************************************************/
/* PROJECT  : RH850F1KM-S1 for D01 project                                    */
/******************************************************************************/
/* !Layer           : CanTrcv                                                 */
/*                                                                            */
/* !Component       : CanTrcv                                                 */
/* !Description     : Interface for CanTrcv .                                 */
/*                                                                            */
/* !Module          : CanTrcv                                                 */
/* !Description     : CanTrcv                                                 */
/*                                                                            */
/* !File            : CanTrcv.c                                               */
/*                                                                            */
/* !Scope           : Private                                                 */
/*                                                                            */
/* !Target          : R7F701684                                               */
/*                                                                            */
/* !Vendor          :(VALEO Climate Control China)                            */
/*                                                                            */
/* Coding language  : C                                                       */
/*                                                                            */
/* all rights reserved                                                        */
/*                                                                            */
/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/

/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
#include "Std_Types.h"
#include "Device.h"
#include "CanTrcv.h"
#include "Dio.h"

/******************************************************************************/
/* DEFINES                                                                    */
/******************************************************************************/


/******************************************************************************/
/* CONSTANTS DEFINITION                                                       */
/******************************************************************************/


/******************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/


/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/


/******************************************************************************/
/* DATA DEFINITION                                                            */
/******************************************************************************/


/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/

/******************************************************************************/
/* LOCAL FUNCTION DEFINITION                                                  */
/******************************************************************************/


/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/

extern void Can1Trcv_vidTrcvInitFct(void)
{
//    /* set the enable port to low */
//    Dio_vidWrite(DIO_u8OUT_CAN_EN, STD_LOW);
//    /* set the standby port to low */
//    Dio_vidWrite(DIO_u8OUT_CAN_STB, STD_LOW);
//    /* Switch the transceiver to NORMAL mode */
//    /* set the wake up event */
//    /* set a high level for the wake port */
//    Dio_vidWrite(DIO_u8OUT_CAN_WAKEUP, STD_HIGH);
//    /* wait the specific time for a stable wake port level */
//    NOP();
//    /* set a low level for the wake port */	
//    Dio_vidWrite(DIO_u8OUT_CAN_WAKEUP, STD_LOW);
//    /* set the enable port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_EN, STD_HIGH);
//    /* set the standby port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_STB, STD_HIGH);
}

extern void Can1Trcv_vidWakeUpTrcvFct(void)
{
//    /* set the enable port to low */
//    Dio_vidWrite(DIO_u8OUT_CAN_EN, STD_LOW);
//    /* set the standby port to low */
//    Dio_vidWrite(DIO_u8OUT_CAN_STB, STD_LOW);
//    /* Switch the transceiver to NORMAL mode */
//    /* set the wake up event */
//    /* set a high level for the wake port */
//    Dio_vidWrite(DIO_u8OUT_CAN_WAKEUP, STD_HIGH);
//    /* wait the specific time for a stable wake port level */
//    NOP();
//    /* set a low level for the wake port */	
//    Dio_vidWrite(DIO_u8OUT_CAN_WAKEUP, STD_LOW);
//    /* set the enable port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_EN, STD_HIGH);
//    /* set the standby port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_STB, STD_HIGH);

}

extern void Can1Trcv_vidSleepTrcvFct(void)
{
//    /* set the enable port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_EN, STD_HIGH);
//    /* set the standby port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_STB, STD_HIGH);
//    NOP();
//    /* set the enable port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_EN, STD_HIGH);
//    /* set the standby port to high */
//    Dio_vidWrite(DIO_u8OUT_CAN_STB, STD_LOW);
}

extern void Can1Trcv_vidStdByTrcvFct(void)
{
//    /* Switch the transceiver to STANDBY mode */
//    /* set the standby port to low */
//    Dio_vidWrite(DIO_u8OUT_CAN_STB, STD_LOW);
}

/*-------------------------------- end of file -------------------------------*/
