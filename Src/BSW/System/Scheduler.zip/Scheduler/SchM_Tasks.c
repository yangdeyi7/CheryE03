

/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
#include "DIO.h"
#include "ADC_handler.h"
#include "SchM_Tasks.h"
#include "WDG_Manager.h"
#include "MCU_Manager.h"
#include "GPT.h"
#include "AppMain.h"
#include "CanCcl.h"
#include "Can.h"
#include "TLE9410xDrv.h"
#include "Actuator.h"







/******************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/


/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/

/******************************************************************************/
/* DATA DEFINITION                                                            */
/******************************************************************************/

/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/

/******************************************************************************/
/* LOCAL FUNCTION DEFINITION                                                  */
/******************************************************************************/

/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/

/******************************************************************************/
/*!Function :   SchM_vidTask1                                                 */
/*! \Description call 10ms tasks. \n
    \return      void.\n
    \Trace_To: HVAC_SCD_SYSTEM_0010#01,HVAC_SCD_SYSTEM_0011#02 
 ******************************************************************************/
void SchM_vidTask1( void )
{
    Wdg_vidManagFast();
    ADC_vidManage();
    CanCcl_vidMainTask();  
    TLE9410xDrv_vidManage();
    Actuator_vidManage(u8ACT_MIXL);
    Actuator_vidManage(u8ACT_MIXR);
    //Actuator_vidManage(u8ACT_MODE);
    Actuator_vidManage(u8ACT_RECY);
    AppMain_vidFastManage();
}

/******************************************************************************/
/*!Function :   SchM_vidTask2                                         */
/*! \Description call 40ms tasks. \n
    \return      void. \n
    \Trace_To: HVAC_SCD_SYSTEM_0012#01,HVAC_SCD_SYSTEM_0013#01
 *******************************************************************************/
void SchM_vidTask2( void )
{

	AppMain_vidManage();
}

/******************************************************************************/
/*!Function :   SchM_vidTask3                                                 */
/*! \Description call 100ms tasks. \n
    \return      void.\n
    \Trace_To: HVAC_SCD_SYSTEM_0014#01,HVAC_SCD_SYSTEM_0015#06
 *******************************************************************************/
void SchM_vidTask3( void )
{
	AppMain_vidSlowManage();
    /*----------------- PLEASE PUT ALL TASKS BEFORE THIS TASK----------------*/
    /*! call watchdog refesh for slow tasks*/
    Wdg_vidManagSlow();
}


/** \} */ /* end of SchM_TASKS module group */
/** \} */ /* end of SchM_TASKS Component group */
