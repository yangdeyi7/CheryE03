/******************************************************************************/
/* PROJECT  :  CHJ_D01                                                        */
/******************************************************************************/
/* !Layer           : can                                                     */
/*                                                                            */
/* !Component       : can                                                     */
/* !Description     : Interface for Managing the can                          */
/*                                                                            */
/* !Module          : can                                                     */
/* !Description     : can                                                     */
/*                                                                            */
/* !File            : can.c                                                   */
/*                                                                            */
/* !Scope           : Private                                                 */
/*                                                                            */
/* !Target          : RH850F1K_S1_R7F7016843                                  */
/*                                                                            */
/* !Vendor          : (VALEO Climate Control China)                           */
/*                                                                            */
/* Coding language  : C                                                       */
/*                                                                            */
/* all rights reserved                                                        */
/******************************************************************************/
/* INCLUDE FILES                                                              */
#include "Device.h"
#include "Can.h"
#include "Can_Cfg.h"
#include "Port.h"
#include "CanTrcv.h"
#include "Can_Hdl.h"
/*===========================================================================*/
/* Functions */
/*===========================================================================*/
static boolean Can1_bBusOffFlag;

/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/
static uint8 vidSetSendMsg(uint8 u8ChIdx, uint8 u8BufIdx, const Can_tstrFrameType *pFrame);
static uint8 vidGetFIFOMsg(uint8 u8BufIdx, Can_tstrFrameType *pFrame);
static void  Can_vidSetRxRule(void);
static void  Can_vidRegInit(void);

#if 0
static uint8 Can_u8ReadRxBuffer(Can_tstrFrameType* pFrame);
static void  Can_vidReadRxFifoBuf(uint8 u8BufIdx, Can_tstrFrameType* pFrame);
static uint8 Can_vidCh1SendMsgByTxBuf(uint8 TxBufIdx, const Can_tstrFrameType* pFrame);
static uint8 Can_vidCh3SendMsgByTxBuf(uint8 TxBufIdx, const Can_tstrFrameType* pFrame);
#endif
/******************************************************************************/
/* INTERRUPT FUNCTION DECLARATION                                             */
/******************************************************************************/
#if 0
static uint8   *Can_pu8TxBuffer;
static uint8    Can_u16NumOfTxFrames;
static uint8    Can_u8SendProtectionFlag = 0u;

void Can_vidSendBuffer(uint8 * pu8Buffer, uint16 u16Length)
{
    if ( pu8Buffer != NULL_PTR) 
    {
	if(0u == Can_u8SendProtectionFlag)
	{
	    Can_u8SendProtectionFlag = 1u;
	    Can_u16NumOfTxFrames = u16Length;
	    Can_pu8TxBuffer = pu8Buffer;
	    Can_bSendMsg(1,0,0x700,8,Can_pu8TxBuffer);
	    /*enable channel 1 transmit complete interrupt*/
	    INTC2MKRCAN1TRX = 0u;
	}
    }
}
#endif

/*channel1 transmit complete interrupt ISR*/   
#pragma ghs interrupt
void INTRCAN1TRX(void)
{
#if 1
    uint8 u8Index;
    for(u8Index = 0u; u8Index < 7; u8Index++)  /*need to modify*/
    {	
        if(((RCFDC0CFDTMSTSp(1, u8Index)) & 0x04u) == 0x04u)
        {
            /*Clear Transmit Buffer Transmit Request Status Flag */
            (RCFDC0CFDTMSTSp(1, u8Index)) &= (~0x04u);
	    
            break;
        }
    }
#else
    if(Can_pu8TxBuffer != NULL_PTR)
    {
       static uint8 LOC_u8TxIndex = 0u;
       if(Can_u16NumOfTxFrames > 8u)
       {
	      LOC_u8TxIndex += 8;
	      Can_bSendMsg(1,0,0x700,8,&Can_pu8TxBuffer[LOC_u8TxIndex]);
	      Can_u16NumOfTxFrames -= 8u;
       }
       else
       {
	   LOC_u8TxIndex = 0u;
	   /*disable channel 1 transmit complete interrupt*/
  	   INTC2MKRCAN1TRX = 1u;
	   Can_u8SendProtectionFlag = 0u;
       }
    }
#endif
}


/*global Receive FIFO interrupt ISR */
#pragma ghs interrupt
void INTRCANGRECC0(void)
{
	uint8 u8Tmp;
	for(u8Tmp = 0u; u8Tmp < 8u; u8Tmp++)
	{
		if((RCFDC0CFDRFSTSx(u8Tmp)) & 0x00000008UL)
		{
			/*clear Receive FIFO Receive Interrupt Request Flag*/
			(RCFDC0CFDRFSTSx(u8Tmp)) &= (~0x00000008UL);
			/*receive data*/
			Can_vidRxHandler(u8Tmp);
		}		
	}	
}



/*channel 1 busoff error interrput ISR*/
//#pragma ghs interrupt
//void INTRCAN1ERR(void)
//{
//	if ((RCFDC0CFDC1STS & 0x00000010u) > 0u)
//	{
//		/*enter halt mode if busoff*/
//		Can1_bBusOffFlag = TRUE;
//		RCFDC0CFDC1CTR &= 0xFFFFFFFEu;		
//	}
//	/*clear all error Flag*/
//    RCFDC0CFDC1ERFL = 0x00000000u;
//}


/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/
static void Can_vidSetRxRule(void)
{
//    uint16 RxRuleIdx;
//    uint8 PageRxRuleIdx;
//    volatile CAN_RX_RULE_TYPE* pCRE;
//
//    /* Set Rx rule number per channel */
//    RCFDC0CFDGAFLCFG0 |= 0x00120000u;   //Channel 1 18 rules
//
//    /* Get access base address of Rx rule */
//    pCRE = (volatile CAN_RX_RULE_TYPE*)&(RCFDC0CFDGAFLID0);
//
//    /* Receive Rule Table Write Enable and select page 0 (start from page 0) */
//    RCFDC0CFDGAFLECTR |= 0x00000100u;  
//    for (RxRuleIdx = 0U; RxRuleIdx < CAN_RX_RULE_NUM; RxRuleIdx++) 
//    {
//        PageRxRuleIdx = (uint8) (RxRuleIdx & 0x0f); 
//        /* Update target Rx rule page if necessary */ 
//        if (PageRxRuleIdx == 0U)   
//        {
//            RCFDC0CFDGAFLECTR |= RxRuleIdx >> 4U;  
//        }
//        /* Set a single Rx rule*/
//        pCRE[PageRxRuleIdx] = CAN_RX_RULE_TABLE[RxRuleIdx];
//    }
//    /* Rx rule write disable */
//    RCFDC0CFDGAFLECTR &= 0xfffffeffu;
}

static void Can_vidRegInit(void)
{
//    /*set channel 1 transmit complete interrupt*/
//    INTC2MKRCAN1TRX = 1u;
//    INTC2RFRCAN1TRX = 0u;
//    INTC2TBRCAN1TRX = 1u;
//    /*set receive FIFO interrupt*/
//    INTC1MKRCANGRECC0 = 1u;
//    INTC1RFRCANGRECC0 = 0u;
//    INTC1TBRCANGRECC0 = 1u;	
//    /*set channel 1 error interrupt*/
//    INTC2MKRCAN1ERR = 1u;
//    INTC2RFRCAN1ERR = 0u;
//    INTC2TBRCAN1ERR = 1u;
//    /* Wait while CAN RAM initialization is ongoing */
//    while((RCFDC0CFDGSTS & 0x00000008u)) ; 
//    RCFDC0CFDGCTR &= 0xfffffffbu;	 
//    RCFDC0CFDGCTR |= 0x00000001u;   	
//    /*ensure global reset mode is over and not in stop mode*/
//    while((RCFDC0CFDGSTS & 0x00000004u)||
//	    ((RCFDC0CFDGSTS & 0x00000001u) != 0x00000001u));
//    /*for can1*/
//    RCFDC0CFDC1CTR &= 0xfffffffbu; 
//    RCFDC0CFDC1CTR |= 0x00000001u; 
//    /*ensure can1 reset mode is over and not in stop mode*/
//    while((RCFDC0CFDC1STS & 0x00000004u)||
//	    ((RCFDC0CFDC1STS & 0x00000001u) != 0x00000001u));
//    /* set Classical CAN only mode */
//    /*for can1*/
//    RCFDC0CFDC1FDCFG |=	0x40000000u;   
//    RCFDC0CFDC1FDCFG &= 0xefffffffu;
//    /*ID priority,  DLC check is disabled, clk_xincan as fCAN = mainOSC CLOCK = 8M, overflow stored, */
//    RCFDC0CFDGCFG = 0x00001030u;	
//    /* CHJ DO1 Standard: tBit = 2000(1997~2003), Baud= 500kbps(+-0.15%) */ 
//    /* CHJ DO1 Standard: SJW = 2Tq (2Tq~3Tq),  SP = 75%~82%  NBT =16Tq  (10Tq ~20Tq ) */
//    /*Nominal Bit Rate = fCAN/(BRP+1)/(1+TSEG1+TSEG2) = 8M/(0+1)/(1+11+4) = 500Kbps */
//    /*for can1*/
//    RCFDC0CFDC1NCFG = 0x030a0800u;   //NTS2=4Tq; NTS1=11Tq; NSJW=2Tq; NBRP = 0;  SP = (11+1)/16 = 75% 
//    /* Rx rule setting */
//    Can_vidSetRxRule();
//    /* Receive buffer setting */ 
//    /*Receive FIFO buffer setting : 4 buffer depth, 8 data length, FIFO 1 interrupt is enable*/
//    RCFDC0CFDRFCC0 |= 0x00001102u;
//    RCFDC0CFDRFCC1 |= 0x00001102u; 
//    RCFDC0CFDRFCC4 |= 0x00001102u; 
//    RCFDC0CFDRFCC5 |= 0x00001102u; 
//    RCFDC0CFDRFCC6 |= 0x00001102u; 
//    RCFDC0CFDRFCC7 |= 0x00001102u; 
//    /* Set CMPOFIE,THLEIE,MEIE,DEIE disabled*/
//    RCFDC0CFDGCTR &= 0xfffff0ffu;	
//    /*channel 1 Transmit buffer interrupt enable*/
//    RCFDC0CFDTMIEC1 = 0x0000007Fu;  /*need to modify */
//    /*set channel 1 busoff entery  interrupt enable*/
//    RCFDC0CFDC1CTR  |= 0x00000E00u;
//    /*clear Bus off entry flag*/
//    RCFDC0CFDC1ERFL |= 0x00000008u;	
//    /* If GlobalChannel in halt or reset mode */
//    if (RCFDC0CFDGSTS & 0x03u) 
//    {	
//	RCFDC0CFDGCTR &= 0xfffffffcu; //Switch to communication mode
//	while ((RCFDC0CFDGSTS & 0x02u) == 2u) {
//	    /* While halt mode */
//	}
//	while ((RCFDC0CFDGSTS & 0x01u) == 1u) {
//	    /* While reset mode */
//	}
//    }
//    /* If Channel1 in halt or reset mode */
//    if (RCFDC0CFDC1STS & 0x03u) 
//    {
//	RCFDC0CFDC1CTR &= 0xfffffffc;    //Switch to communication mode
//	while ((RCFDC0CFDC1STS & 0x02u) == 2u) {
//	    /* While halt mode */
//	}
//	while ((RCFDC0CFDC1STS & 0x01u) == 1u) {
//	    /* While reset mode */
//	}
//    }
//    /*set RxFIFO0 ~ RxFIFO7 to operation mode  */
//    RCFDC0CFDRFCC0 |= 0x00000001u;   
//    RCFDC0CFDRFCC1 |= 0x00000001u; 
//    RCFDC0CFDRFCC4 |= 0x00000001u;   
//    RCFDC0CFDRFCC5 |= 0x00000001u; 
//    RCFDC0CFDRFCC6 |= 0x00000001u; 
//    RCFDC0CFDRFCC7 |= 0x00000001u;
//    /*enable channel 1 transmit complete interrupt*/
//    INTC2MKRCAN1TRX = 0u;
//    /*enable global Receive FIFO Receive interrupt */
//    INTC1MKRCANGRECC0 = 0u; 
//    /*enable channel 1 error interrput*/
//    INTC2MKRCAN1ERR = 0u;
}

static uint8 vidSetSendMsg(uint8 u8ChIdx, uint8 u8BufIdx, const Can_tstrFrameType *pFrame)
{
	/* ---- Store message to tx buffer ---- */
    volatile uint32 * p_CiTBp;
	uint32 *p_data;

#if defined(__CHECK__)
	/* Check can channel index */
	if (u8ChIdx >= CANDEV_CH_NUM) 
	{
		return RTN_INPUT_NOK;
	}
	/* Check txbuffer index */
	if (u8BufIdx >= CAN_MAX_TXBUF_NUM)
	{
		return RTN_INPUT_NOK;
	}
	/* Check pFrame point */
	if (pFrame == NULL_PTR)
	{
		return RTN_PNULL_NOK;
	}
#endif

	p_CiTBp = &(RCFDC0CFDTMIDp(u8ChIdx, u8BufIdx));
	p_data = (uint32 *)pFrame;
	*(p_CiTBp++) = *(p_data++);
	*(p_CiTBp++) = *(p_data++);
	*(p_CiTBp++) = *(p_data++);
	*(p_CiTBp++) = *(p_data++);
	*(p_CiTBp  ) = *(p_data  );

	return RTN_COMMON_OK;
}

static uint8 vidGetFIFOMsg(uint8 u8BufIdx, Can_tstrFrameType *pFrame)
{
    /* ---- Read out message from Rx FIFO ---- */
	uint32 *p_data;
	volatile uint32 * ptr_reg;

#if defined(__CHECK__)
		/* ----  Check RX FIFO BUFF  index ---- */
		if (u8BufIdx >= CANDEV_CH_NUM) 
		{
			return RTN_INPUT_NOK;
		}
		/*Check pFrame point */
		if (pFrame == NULL_PTR)
		{
			return RTN_PNULL_NOK;
		}
#endif

	ptr_reg = &(RCFDC0CFDRFIDx(u8BufIdx));
	p_data = (uint32 *)pFrame;
	*(p_data++) = *(ptr_reg++);
	*(p_data++) = *(ptr_reg++);
	*(p_data++) = *(ptr_reg++);
	*(p_data++) = *(ptr_reg++);
	*(p_data  ) = *(ptr_reg  );
	
	return RTN_COMMON_OK;
}

#if 0
static uint8 Can_u8ReadRxBuffer(Can_tstrFrameType* pFrame)
{
  uint8 BufIdx;
  uint8 CRBRCFiBufIdx;
  uint8 OverwrittenFlag;
  uint32 TempCRBRCF0;
  uint32 TempCRBRCF1;
  uint32 TempCRBRCF2;
  
  Can_tstrFrameType* pRxBuffer;
  volatile uint32* pCRBRCF;
  uint8 RtnValue;

  /* Judge if new messages are available */
  TempCRBRCF0 = RCFDC0CFDRMND0;
  TempCRBRCF1 = RCFDC0CFDRMND1;
  TempCRBRCF2 = RCFDC0CFDRMND2;

  if ((TempCRBRCF0 == 0u) && (TempCRBRCF1 == 0u)&& (TempCRBRCF2 == 0u)) 
  {
    RtnValue = CAN_RTN_BUFFER_EMPTY;
  }
  else
  {
    /* Get Rx buffer that has new message */
    if (TempCRBRCF0 != 0u) 
    {
      pCRBRCF = (volatile uint32 *)&(RCFDC0CFDRMND0);
      for (BufIdx = 0u; BufIdx < 32u; BufIdx++) 
      {
        if ((TempCRBRCF0 & 1u) == 1u) 
        {
          	break;
        }
        TempCRBRCF0 = TempCRBRCF0 >> 1u;
      }
    }
    else if (TempCRBRCF1 != 0u)
    {
      pCRBRCF = (volatile uint32 *)&(RCFDC0CFDRMND1);
      for (BufIdx = 0u; BufIdx < 32u; BufIdx++) 
      {
        if ((TempCRBRCF1 & 1u) == 1u) 
        {
            break;
        }
        TempCRBRCF1 = TempCRBRCF1 >> 1u;
      }
      BufIdx += 32u;
    }
    else if (TempCRBRCF2 != 0u)
    {
      pCRBRCF = (volatile uint32 *)&(RCFDC0CFDRMND2);
      for (BufIdx = 0u; BufIdx < 32u; BufIdx++) 
	  {
        if ((TempCRBRCF2 & 1u) == 1u) 
	    {
            break;
        }
        TempCRBRCF2 = TempCRBRCF2 >> 1u;
      }
      BufIdx += 64u;
    }
    /* Calculate index value in CRBRCFi */
    CRBRCFiBufIdx = BufIdx & 0x1fu;

    do 
    {
      /* Clear Rx complete flag of corresponding Rx buffer */
      do 
        {
          CLR_BIT(*pCRBRCF, CRBRCFiBufIdx);
        }while (GET_BIT(*pCRBRCF, CRBRCFiBufIdx) == 1u);

        /* Read out message from Rx buffer */
        pRxBuffer = (Can_tstrFrameType*) &(RCFDC0CFDRMIDq(BufIdx));  
        *pFrame = pRxBuffer[0];

        /* Judge if current message is overwritten */
        OverwrittenFlag = GET_BIT(*pCRBRCF, CRBRCFiBufIdx);
        /* Message is overwritten */
        if (OverwrittenFlag == 1u) 
        {
          /* User process for message overwritten */
        }
    }while (OverwrittenFlag == 1u);

    RtnValue = CAN_RTN_OK;
  }
  return RtnValue;
}

static void Can_vidReadRxFifoBuf(uint8 u8BufIdx, Can_tstrFrameType* pFrame)
{
    Can_tstrFrameType* pRxFIFOBuffer ;
    /*check data to RX FIFO buffer */
    if((RCFDC0CFDRFIDx(u8BufIdx) & 0x00000001u) == 0x0u)	
    {
		pRxFIFOBuffer = (Can_tstrFrameType*) &(RCFDC0CFDRFIDx(u8BufIdx));
		*pFrame = pRxFIFOBuffer[0];
		RCFDC0CFDRFPCTRx(u8BufIdx) |=0xFF;
    }
}

static uint8 Can_vidCh1SendMsgByTxBuf(uint8 TxBufIdx, const Can_tstrFrameType* pFrame)
{
  /*p: ch1 : 32~63 */
  volatile uint8* pTBSR;
  Can_tstrFrameType* pTxBuffer;
  volatile uint8* pTBCR;

  pTBSR = (volatile uint8 *)&(RCFDC0CFDTMSTS32);
  pTBCR = (volatile uint8 *)&(RCFDC0CFDTMC32);

  /* ---- Return if Tx Buffer is transmitting. ---- */    
  if( (pTBSR[TxBufIdx] & (uint8)0x01u) == 1U)
  {
 		return CAN_RTN_ERR;
  }

  /* Clear Tx buffer status */
  do 
  {
    pTBSR[TxBufIdx] = 0u;
  }while (pTBSR[TxBufIdx] != 0u);

  /* Store message to Tx buffer */
  pTxBuffer = (Can_tstrFrameType*) &(RCFDC0CFDTMID32);
  pTxBuffer[TxBufIdx] = *pFrame;

  /* Set transmission request */
  pTBCR[TxBufIdx] = 1u;

  return CAN_RTN_OK;
}

static uint8 Can_vidCh3SendMsgByTxBuf(uint8 TxBufIdx, const Can_tstrFrameType* pFrame)
{
  /*p: ch3 : 96~127 */
  volatile uint8* pTBSR;
  Can_tstrFrameType* pTxBuffer;
  volatile uint8* pTBCR;

  pTBSR = (volatile uint8 *)&(RCFDC0CFDTMSTS96);
  pTBCR = (volatile uint8 *)&(RCFDC0CFDTMC96);

  /* ---- Return if Tx Buffer is transmitting. ---- */    
  if( (pTBSR[TxBufIdx] & (uint8)0x01u) == 1U )
  {
 		return CAN_RTN_ERR;
  }

  /* Clear Tx buffer status */
  do 
  {
    pTBSR[TxBufIdx] = 0u;
  }while (pTBSR[TxBufIdx] != 0u);

  /* Store message to Tx buffer */
  pTxBuffer = (Can_tstrFrameType*) &(RCFDC0CFDTMID96);
  pTxBuffer[TxBufIdx] = *pFrame;
  /* Set transmission request */
  pTBCR[TxBufIdx] = 1u;

  return CAN_RTN_OK;
}
#endif

#if 0
void Can_vid_Test(void)
{
   static uint8 LOC_u8Count = 0u;
   static uint8 LOC_u8Count1 = 0u;
   static uint8 LOC_au8Data[8] = {0};      
   if(LOC_u8Count < 25u)
   {
         LOC_u8Count++;
   }
   else
   {
	     uint8 u8Index;
         LOC_u8Count = 0u;
		 LOC_u8Count1++;
		 for(u8Index = 0u; u8Index < 8u; u8Index++)
         {
           LOC_au8Data[u8Index] = LOC_u8Count1; 
         }
		 Can_bSendMsg(1,0,0x700,8,LOC_au8Data);
		 Can_bSendMsg(1,1,0x701,8,LOC_au8Data);
		 Can_bSendMsg(1,2,0x702,8,LOC_au8Data);
		 Can_bSendMsg(1,3,0x703,8,LOC_au8Data);
		 Can_bSendMsg(1,4,0x704,8,LOC_au8Data);
		 Can_bSendMsg(1,5,0x705,8,LOC_au8Data);
		 Can_bSendMsg(1,6,0x706,8,LOC_au8Data);
		 Can_bSendMsg(1,7,0x707,8,LOC_au8Data);
		 if(LOC_u8Count1 == 255)
		 {
             LOC_u8Count1 = 0u;
		 }
   }
}
#endif


/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/
void Can_vidInit(void)
{
    /*CAN1 port Initial*/
    Port_vidSetAltFunc(Can_akstrPortCfg[CAN_u8CAN1TX_ID], Port_Alt4, Port_Output);
    Port_vidSetAltFunc(Can_akstrPortCfg[CAN_u8CAN1RX_ID], Port_Alt4, Port_Input);
    /*CAN1 Reg initial*/	  
    Can_vidRegInit();	
    /*CAN1 transceiver initial*/
    Can1Trcv_vidTrcvInitFct();
}

boolean Can_bSendMsg(uint8 u8ChIdx, uint8 u8BufIdx, uint32 u32CanId, uint8 u8Dlc, /*const*/ uint8 *pu8Data)
{
    boolean bRtn;
    uint8 u8Tmp;
//    Can_tstrFrameType frame1 = {0u};
//    frame1.ID = u32CanId;
//    frame1.DLC = u8Dlc;
//    frame1.THLEN = 0u;
//    frame1.RTR = 0u;
//    frame1.IDE = 0u;
//    frame1.FDF = 0u;
//
//    u8Tmp = 0;
//    do
//    {
//	frame1.DB[u8Tmp] = pu8Data[u8Tmp];
//	frame1.DB[u8Tmp+1] = pu8Data[u8Tmp+1];
//	u8Tmp += 2;
//    } while(u8Tmp < u8Dlc);
//
//    if( (RCFDC0CFDTMSTSp(u8ChIdx, u8BufIdx) & (uint8)0x01u) == 0x0u )
//    {
//	/* Clear Tx buffer status */
//	RCFDC0CFDTMSTSp(u8ChIdx, u8BufIdx) = 0x0u;	
//	/*Store message to tx buffer*/
//	vidSetSendMsg(u8ChIdx, u8BufIdx, &frame1);
//	/*Transmission is requested*/
//        RCFDC0CFDTMCp(u8ChIdx, u8BufIdx) = 0x1u;
//
//	bRtn = TRUE;
//    }
//    else
//    {
//	bRtn = FALSE;
//    }

    return bRtn;
}

boolean Can_bReceiveFIFORxBuf(uint8 u8BufIdx, uint32* pu32CanId, uint8* pu8Dlc, uint8* pu8Data)
{
//    boolean bRtn;
//    uint8 u8Tmp;
//    Can_tstrFrameType frame1;
//    uint8 u8Timeout = 8u;
//    /* if The receive FIFO buffer contains unread message.*/
//    do
//    {
//	u8Timeout--;
//	vidGetFIFOMsg(u8BufIdx, &frame1);
//	*pu32CanId = frame1.ID;
//	*pu8Dlc = frame1.DLC;	
//	u8Tmp = 0;
//	do
//	{
//	    pu8Data[u8Tmp] = frame1.DB[u8Tmp];
//	    pu8Data[u8Tmp+1] = frame1.DB[u8Tmp+1];
//	    u8Tmp += 2;
//	} while(u8Tmp < frame1.DLC);
//	/* read pointer to the next unread message in the receive FIFO buffer*/
//	RCFDC0CFDRFPCTRx(u8BufIdx) = 0x000000FFUL;
//    }while((((RCFDC0CFDRFSTSx(u8BufIdx)) & 0x00000001UL) == 0UL) && (u8Timeout != 0u)); /*contains unread message*/
//    /*if timeout occoured*/
//    if(u8Timeout == 0u)
//    {
//	bRtn = FALSE;
//    }
//    /*RX FIFO buffer has been read out and has no unread message*/
//    else
//    {
//	bRtn = TRUE;
//    }

//    return bRtn;
}

void Can1_vidFromCommToReset(void)
{
//    /* Global reset mode*/
//    RCFDC0CFDGCTR |= 0x00000001u;  
//    /* Channel1 reset mode*/ 
//    RCFDC0CFDC1CTR |= 0x00000001u; 
}

uint8 Can1_u8CanChGetBusStatus(void)
{
    Std_ReturnType udtRtn = E_OK;
//    if((Can1_bBusOffFlag == TRUE)  )
//    {
//	udtRtn = E_NOT_OK;
//    }
//
//    if ((RCFDC0CFDC1STS & 0x00000010ul) > 0u)
//    {
//	udtRtn =  E_NOT_OK;
//    }

    return udtRtn;
}

/*-------------------------------- end of file -------------------------------*/
