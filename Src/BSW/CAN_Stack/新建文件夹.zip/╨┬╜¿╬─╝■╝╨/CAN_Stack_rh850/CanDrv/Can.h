/******************************************************************************/
/* PROJECT  :  CHJ_D01                                                        */
/******************************************************************************/
/* !Layer           : can                                                     */
/*                                                                            */
/* !Component       : can                                                     */
/* !Description     : Interface for Managing the can                          */
/*                                                                            */
/* !Module          : can                                                     */
/* !Description     : can                                                     */
/*                                                                            */
/* !File            : can.h                                                   */
/*                                                                            */
/* !Scope           : Private                                                 */
/*                                                                            */
/* !Target          : RH850F1K_S1_R7F7016843                                  */
/*                                                                            */
/* !Vendor          : (VALEO Climate Control China)                           */
/*                                                                            */
/* Coding language  : C                                                       */
/*                                                                            */
/* all rights reserved                                                        */
/******************************************************************************/
#ifndef CAN_H
#define CAN_H

#include "Std_Types.h"
/*****************************************************************************/


#define CANDEV_START_ADDR           (0xFFD00000UL)  

/* ---- Address ---- */
#define CAN_REG8(x)   (*((volatile unsigned char *)(CANDEV_START_ADDR + (x))))  
#define CAN_REG16(x)  (*((volatile unsigned short *)(CANDEV_START_ADDR + (x))))  
#define CAN_REG32(x)  (*((volatile unsigned long *)(CANDEV_START_ADDR + (x))))   

/* ---- Tx buffers ---- */  
#define RCFDC0CFDTMCp(ch, txbuf)        CAN_REG8(0x0250 + (0x20 * (ch)) + txbuf)  
#define RCFDC0CFDTMSTSp(ch, txbuf)      CAN_REG8(0x0350 + (0x20 * (ch)) + txbuf)  

/* ---- RAM ---- */
#define RCFDC0CFDRFIDx(rxfifo)          CAN_REG32(0x6000 + (0x80 * (rxfifo)))  
#define RCFDC0CFDTMIDp(ch, txbuf)       CAN_REG32(0x8000 + (0x1000 * (ch)) + (0x80 * (txbuf)))  
#define RCFDC0CFDRMIDq(rxbuf)           CAN_REG32(0x2000 + (0x80 * (rxbuf)))  

/* ---- Rx FIFO ---- */
#define RCFDC0CFDRFSTSx(rxfifo)         CAN_REG32(0x00D8 + (0x04 * (rxfifo))) 
#define RCFDC0CFDRFPCTRx(rxfifo)        CAN_REG32(0x00F8 + (0x04 * (rxfifo)))  

/* ---- CAN frame ----- */
/*CAN FD frame is not same as Classical CAN frame*/
typedef struct
{
    uint32 ID :29;
    uint32 THLEN :1;
    uint32 RTR :1;
    uint32 IDE :1;
    uint32 TS :16;
    uint32 LBL :8;
    uint32 res0 :4;
    uint32 DLC :4;
    uint32 ESI :1;
    uint32 BRS :1;
    uint32 FDF :1;
    uint32 res1 :29;
    uint8 DB[8];
} Can_tstrFrameType;  

/* ---- function return value ---- */
#define CAN_RTN_OK                          0U
#define CAN_RTN_FIFO_FULL                   1U
#define CAN_RTN_BUFFER_EMPTY                2U
#define CAN_RTN_ERR                         255U

#define RTN_COMMON_OK                        0U
#define RTN_PNULL_NOK                        1U
#define RTN_INPUT_NOK                        2U

/* ---- bit mask ---- */
#define CAN_1_BIT_MASK                      1U
#define CAN_2_BIT_MASK                      3U
#define CAN_3_BIT_MASK                      7U
#define CAN_4_BIT_MASK                      0xfU
#define CAN_5_BIT_MASK                      0x1fU

/* ---- bit position ---- */
#define CAN_B0_BIT_POS                      0U
#define CAN_B1_BIT_POS                      1U
#define CAN_B2_BIT_POS                      2U
#define CAN_B3_BIT_POS                      3U
#define CAN_B4_BIT_POS                      4U
#define CAN_B5_BIT_POS                      5U
#define CAN_B6_BIT_POS                      6U
#define CAN_B7_BIT_POS                      7U
#define CAN_B8_BIT_POS                      8U
#define CAN_B9_BIT_POS                      9U
#define CAN_B10_BIT_POS                     10U
#define CAN_B11_BIT_POS                     11U
#define CAN_B12_BIT_POS                     12U
#define CAN_B13_BIT_POS                     13U
#define CAN_B14_BIT_POS                     14U
#define CAN_B15_BIT_POS                     15U

/* ---- bit operations ---- */
#define GET_BIT(reg, pos)              (((reg) >> (pos)) & 1U)
#define SET_BIT(reg, pos)              ((reg) |= 1U << (pos))
#define CLR_BIT(reg, pos)              ((reg) &= ~(1UL << (pos)))

/******************************************************************************/
/*  Function define															  */
/******************************************************************************/
extern void Can_vidInit(void);
extern boolean Can_bSendMsg(uint8 u8ChIdx, uint8 u8BufIdx, 
	                        uint32 u32CanId, uint8 u8Dlc, /*const*/ uint8 *pu8Data);
extern boolean Can_bReceiveFIFORxBuf(uint8 u8BufIdx, 
	                          uint32* pu32CanId, uint8* pu8Dlc, uint8* pu8Data); 
extern void Can1_vidFromCommToReset(void);
extern uint8 Can1_u8CanChGetBusStatus(void);





#if 0
extern void Can_vid_Test(void);
extern void Can_vidSendBuffer(uint8 * pu8Buffer, uint16 u16Length);
#endif

#endif /* CAN_H */
/*-------------------------------- end of file -------------------------------*/
