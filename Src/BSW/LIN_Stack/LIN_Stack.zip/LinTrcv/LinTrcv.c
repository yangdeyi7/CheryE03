/******************************************************************************/
/* PROJECT  :  XXX                                                            */
/******************************************************************************/
/* !Layer           : LinTrcv                                                 */
/*                                                                            */
/* !Component       : LinTrcv                                                 */
/* !Description     : Provides interface of LIN                               */
/*                                                                            */
/* !Module          : LinTrcv                                                 */
/* !Description     : Provides interface of LIN                               */
/*                                                                            */
/* !File            : LinTrcv.c                                               */
/*                                                                            */
/* !Scope           : Private                                                 */
/*                                                                            */
/*!Target          : RH850F1K-S1                                              */
/*                                                                            */
/* !Vendor          : T13 (VALEO Climate Control China)                       */
/*                                                                            */
/* Coding language  : C                                                       */
/*                                                                            */
/* COPYRIGHT 2017 VALEO                                                       */
/* All Rights Reserved                                                        */
/*                                                                            */
/******************************************************************************/
/* PVCS                                                                       */
/******************************************************************************/
/* !Deviation : Inhibit MISRA rule [0288]: Dollar sign is needed by configu-  */
/*              ration management tool (PVCS)                                 */
/* PRQA S 0288 ++                                                             */
/* PRQA S 0292 ++                                                             */
/* $Archive::   V:/SWDatabase/CHJ_M01/archives/M01_CLM/04_Software/Sources/CO$*/
/* $Revision::   1.1      $$Author::   chunping.yan   $$Date::   Jun 30 2017 $*/
/* PRQA S 0292 --                                                             */
/* PRQA S 0288 --                                                             */
/******************************************************************************/
/* MODIFICATION LOG :                                                         */
/******************************************************************************/
/* $Log:   V:/SWDatabase/CHJ_M01/archives/M01_CLM/04_Software/Sources/COM_LIN/LinPort/LinPort.c-arc  $
 * 
 *    Rev 1.1   Jun 30 2017 18:19:06   chunping.yan
 * standardization
 * 
 *    Rev 1.0   Jun 30 2017 09:47:22   CYAN
 * Initial revision.
 * 
 * 
 ******************************************************************************/

/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
#include "Device.h"
#include "Std_Types.h"
#include "LinTrcv.h"
#include "LinIf.h"
#include "Dio.h"

/******************************************************************************/
/* DEFINES                                                                    */
/******************************************************************************/

/******************************************************************************/
/* CONSTANTS DEFINITION                                                       */
/******************************************************************************/


/******************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/


/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/

/******************************************************************************/
/* DATA DEFINITION                                                            */
/******************************************************************************/

/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/

/******************************************************************************/
/* LOCAL FUNCTION DEFINITION                                                  */
/******************************************************************************/

/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/


/*******************************************************************************
** Function:    LIN Trcv_init
** Description: Configures P0_2 to alternative function RLIN30TX
**              Configures P0_3 to alternative function RLIN30RX
**              Configures P0_4 to alternative function RLIN31RX
**              Configures P0_5 to alternative function RLIN31TX
** Parameter:   LIN channel No.
** Return:      None
*******************************************************************************/
void LINTRCV_vidInit(uint8 u8ChanNum)
{
//    switch(u8ChanNum)
//    {
//        case 0u:
//            /* Config RLIN30 Port Pins */ 
//            /* RLIN30 TX on PIN 2 of Port 0 2st ALT*/
//            PORTPMC0   |=  (1 << 2);
//            PORTPFCE0  &= ~(1 << 2);
//            PORTPFC0   |=  (1 << 2);
//            PORTPFCAE0 &= ~(1 << 2);
//            PORTPM0    &= ~(1 << 2);
//    
//            /* RLIN30 RX on PIN 3 of Port 0 2st ALT*/
//            PORTPMC0  |=  (1 << 3);
//            PORTPFCE0 &= ~(1 << 3);
//            PORTPFC0  |=  (1 << 3);
//            PORTPFCAE0&= ~(1 << 3);
//            PORTPM0   |=  (1 << 3);
//            break;
//
//        case 1u:
//			/*Enable LIN Trcv*/
//	        Dio_vidWrite(DIO_u8OUT_LIN_EN, 1U);
//			
//            /* Config RLIN31 Port Pins */ 
//            /* RLIN31 TX on PIN 5 of Port 0 1st ALT*/
//            PORTPMC0   |=  (1 << 5);
//            PORTPFCE0  &= ~(1 << 5);
//            PORTPFC0   &= ~(1 << 5);
//            PORTPFCAE0 &= ~(1 << 5);
//            PORTPM0    &= ~(1 << 5);
//    
//            /* RLIN31 RX on PIN 4 of Port 0 1st ALT*/
//            PORTPMC0  |=  (1 << 4);
//            PORTPFCE0 &= ~(1 << 4);
//            PORTPFC0  &= ~(1 << 4);
//            PORTPFCAE0&= ~(1 << 4);
//            PORTPM0   |=  (1 << 4);
//            break;
//
//        default:
//            break;
//    }
}


