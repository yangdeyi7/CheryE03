/******************************************************************************/
/* INCLUDE FILES                                                              */
/******************************************************************************/
#include "device_registers.h"  /* include peripheral declarations S32K144 */
#include "Std_Types.h"
#include "Can.h"
#include "Can_Hdl.h"
#include "Can_Type.h"
/******************************************************************************/
/* DEFINES                                                                    */
/******************************************************************************/


/******************************************************************************/
/* CONSTANTS DEFINITION                                                       */
/******************************************************************************/

/******************************************************************************/
/* MACRO FUNCTIONS                                                            */
/******************************************************************************/


/******************************************************************************/
/* TYPES                                                                      */
/******************************************************************************/


/******************************************************************************/
/* DATA DEFINITION                                                            */
static boolean   Can_bBusoffFlag;
/******************************************************************************/

/******************************************************************************/
/* LOCAL FUNCTION DECLARATION                                                 */
/******************************************************************************/
static uint32  u32Byte2Dword(uint8* pu8Data, uint8 u8Length);
static uint8_t u8GetDlc(uint8_t u8Length);

/******************************************************************************/
/* LOCAL FUNCTION DEFINITION                                                  */
/******************************************************************************/

/******************************************************************************/
/* GLOBAL FUNCTION DEFINITION                                                 */
/******************************************************************************/
void Can_vidInit(void)
{
	uint8  u8Index = 0u;
	/*CanPort Config*/
	PCC->PCCn[PCC_PORTE_INDEX] |= PCC_PCCn_CGC_MASK;
	PORTE->PCR[4] |= PORT_PCR_MUX(5); /*Port E4: MUX = ALT5, CAN0_RX*/
	PORTE->PCR[5] |= PORT_PCR_MUX(5); /*Port E5: MUX = ALT5, CAN0_TX*/
    /*Can Register Config*/
    PCC->PCCn[PCC_FlexCAN0_INDEX] |= PCC_PCCn_CGC_MASK; /* CGC=1: enable clock to FlexCAN0 */
    CAN0->MCR = 0xD890000Fu;               /* Reset value */
    CAN0->CTRL1 |= CAN_CTRL1_CLKSRC_MASK;  /* CLKSRC=1: Clock Source = BUSCLK (40 MHz) */
    CAN0->MCR &= ~CAN_MCR_MDIS_MASK;        /* MDIS=0; Enable module config. (Sets FRZ, HALT)*/
     /* Good practice: wait for FRZACK=1 on freeze mode entry/exit */
	while (!((CAN0->MCR & CAN_MCR_FRZACK_MASK) >> CAN_MCR_FRZACK_SHIFT))
	{
        ;
	}
    CAN0->CBT = BTF(1) + EPRESDIV(7) + EPSEG2(3) + EPSEG1(6) + EPROPSEG(7) + ERJW(2);
    //CAN0->CBT = 0x802FB9EF;   /* Configure nominal phase: 500 KHz bit time, 40 MHz Sclock */
                            /* Prescaler = CANCLK / Sclock = 80 MHz / 40 MHz = 2 */
                            /* EPRESDIV = Prescaler - 1 = 2 - 1 = 1, shift 21 */
                            /* EPSEG2 = 15, shift 0 */
                            /* EPSEG1 = 15, shift 5 */
                            /* EPROPSEG = 46, shift 10 */
                            /* ERJW = 15, shift 16 */
    /* BITRATEn =Fcanclk /( [(1 + (EPSEG1+1) + (EPSEG2+1) + (EPROPSEG + 1)] x (EPRESDIV+1)) */
    /*          = 80 MHz /( [(1 + ( 15   +1) + ( 15   +1) + (   46    + 1)] x (    1   +1)) */
    /*          = 80 MHz /( [1+16+16+47] x 2) = 80 MHz /(80x2) = 500 Kz */

    CAN0->FDCBT = FPRESDIV(1) + FPSEG2(4) + FPSEG1(4) + FPROPSEG(9) + FRJW(2);
    //CAN0->FDCBT = 0x00131CE3;  /* Configure data phase: 2 MHz bit time, 40 MHz Sclock */
                             /* Prescaler = CANCLK / Sclock = 80 MHz / 40 MHz = 2 */
                             /* FPRESDIV = Prescaler - 1 = = 2 - 1 = 1, shift 20 */
                             /* FPSEG2 = 3, shift 0 */
                             /* FPSEG1 = 7, shift 5 */
                             /* FPROPSEG = 7, shift 10 */
                             /* FRJW = 3, shift 16 */
    /* BITRATEf =Fcanclk /( [(1 + (FPSEG1+1) + (FPSEG2+1) + (FPROPSEG)] x (FPRESDIV+1)) */
    /*          = 80 MHz /( [(1 + (  7   +1) + (  3   +1) + (   7    )] x (    1   +1)) */
    /*          = 80 MHz /( [1+8+4+7] x 2) = 80 MHz /(20x2) = 80 MHz / 40 = 2 MHz  */
    CAN0->FDCTRL =0x80038500;  /* Configure bit rate switch, data size, transcv'r delay  */
                             /* BRS=1: enable Bit Rate Swtich in frame's header */
                             /* MBDSR1: Not applicable */
                             /* MBDSR0=3: Region 0 has 64 bytes data in frame's payload */
                             /* TDCEN=1: enable Transceiver Delay Compensation */
                             /* TDCOFF=5: 5 CAN clocks (300us) offset used */

	for(u8Index = 0u; u8Index < 128u; u8Index++)
	{
		/* CAN0: clear 32 msg bufs x 4 words/msg buf = 128 words*/
	    CAN0->RAMn[u8Index] = 0;      /* Clear msg buf word */
	}
    
#if 0  //use global Mask Filter IDs
	for(u8Index = 0u; u8Index < 16u; u8Index++)
	{
		/* In FRZ mode, init CAN0 16 msg buf filters */
	    CAN0->RXIMR[u8Index] = 0xFFFFFFFF;  /* Check all ID bits for incoming messages */
	}
	CAN0->RXMGMASK = 0x1FFFFFFF;  /* Global acceptance mask: check all ID bits */
    //Rcev ID Filter start 
    CAN0->RAMn[RX_BUF2_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF2_ID * MSG_BUF_SIZE + 1] = (0x310<< 18u); 
  
    CAN0->RAMn[RX_BUF3_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF3_ID * MSG_BUF_SIZE + 1] = (0x312<< 18u);
  
    CAN0->RAMn[RX_BUF4_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF4_ID * MSG_BUF_SIZE + 1] = (0x330<< 18u);
  
    CAN0->RAMn[RX_BUF5_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF5_ID * MSG_BUF_SIZE + 1] = (0x338<< 18u);
  
    CAN0->RAMn[RX_BUF6_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF6_ID * MSG_BUF_SIZE + 1] = (0x370<< 18u);
    /*
    CAN0->RAMn[RX_BUF7_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF7_ID * MSG_BUF_SIZE + 1] = (0x3A2<< 18u);

    CAN0->RAMn[RX_BUF8_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF8_ID * MSG_BUF_SIZE + 1] = (0x3B0<< 18u);

    CAN0->RAMn[RX_BUF9_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF9_ID * MSG_BUF_SIZE + 1] = (0x3B8<< 18u);

    CAN0->RAMn[RX_BUF10_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF10_ID * MSG_BUF_SIZE + 1] = (0x160<< 18u);

    CAN0->RAMn[RX_BUF11_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF11_ID * MSG_BUF_SIZE + 1] = (0x268<< 18u);
  
    CAN0->RAMn[RX_BUF12_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF12_ID * MSG_BUF_SIZE + 1] = (0x448<< 18u);

    CAN0->RAMn[RX_BUF13_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF13_ID * MSG_BUF_SIZE + 1] = (0x7A3<< 18u);
  
    CAN0->RAMn[RX_BUF14_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
    CAN0->RAMn[RX_BUF14_ID * MSG_BUF_SIZE + 1] = (0x7DF<< 18u);
   */
#else //use Individual Mask Filter IDs
   CAN0->RXIMR[RX_BUF2_ID] = 0xFC17FFFF; //recv(310 312 330 338 370 3A2 3B0 3B8)
   CAN0->RAMn[RX_BUF2_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
   CAN0->RAMn[RX_BUF2_ID * MSG_BUF_SIZE + 1] = (0x310<< 18u); 
   
   CAN0->RXIMR[RX_BUF3_ID] = 0xFFFFFFFF; //recv(160)
   CAN0->RAMn[RX_BUF3_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
   CAN0->RAMn[RX_BUF3_ID * MSG_BUF_SIZE + 1] = (0x160<< 18u); 
   
   CAN0->RXIMR[RX_BUF4_ID] = 0xFFFFFFFF; //recv(268)
   CAN0->RAMn[RX_BUF4_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
   CAN0->RAMn[RX_BUF4_ID * MSG_BUF_SIZE + 1] = (0x268<< 18u);
   
   CAN0->RXIMR[RX_BUF5_ID] = 0xFFFFFFFF; //recv(448)
   CAN0->RAMn[RX_BUF5_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
   CAN0->RAMn[RX_BUF5_ID * MSG_BUF_SIZE + 1] = (0x448<< 18u); 
   
   CAN0->RXIMR[RX_BUF6_ID] = 0xFE0FFFFF; //recv(7A3, 7DF)
   CAN0->RAMn[RX_BUF6_ID * MSG_BUF_SIZE + 0] = 0xC4000000;
   CAN0->RAMn[RX_BUF6_ID * MSG_BUF_SIZE + 1] = (0x7A3<< 18u); 
#endif

  CAN0->CTRL2 |= CAN_CTRL2_ISOCANFDEN_MASK; /* Enable CRC fix for ISO CAN FD */
  
  CAN0->MCR = 0x0001087F;       /* Negate FlexCAN 1 halt state & enable CAN FD for 32 MBs */

  /* Open FIFO receives interrupt */
  CAN0->IMASK1 |=   (1<<RX_BUF2_ID)  |
                    (1<<RX_BUF3_ID)  |
                    (1<<RX_BUF4_ID)  |
                    (1<<RX_BUF5_ID)  |
                    (1<<RX_BUF6_ID) ;
/*
                    (1<<RX_BUF7_ID)  |
                    (1<<RX_BUF8_ID)  |
                    (1<<RX_BUF9_ID)  |
                    (1<<RX_BUF10_ID) |
    		        (1<<RX_BUF11_ID) |
					(1<<RX_BUF12_ID) |
					(1<<RX_BUF13_ID) |
					(1<<RX_BUF14_ID) |
					(1<<RX_BUF15_ID) |
					(1<<RX_BUF16_ID) |
					(1<<RX_BUF17_ID) |
					(1<<RX_BUF18_ID) |
					(1<<RX_BUF19_ID) |
					(1<<RX_BUF20_ID) |
					(1<<RX_BUF21_ID) |
					(1<<RX_BUF22_ID) |
					(1<<RX_BUF23_ID) |
					(1<<RX_BUF24_ID) |
					(1<<RX_BUF25_ID) |
					(1<<RX_BUF26_ID) |
					(1<<RX_BUF27_ID) |
					(1<<RX_BUF28_ID) |
					(1<<RX_BUF29_ID) |
					(1<<RX_BUF30_ID) |
    		        (1<<RX_BUF31_ID);
*/
    
    CAN0->CTRL2 |= (1<<30U);/*enable bus off interrupt*/

    while ((CAN0->MCR && CAN_MCR_FRZACK_MASK) >> CAN_MCR_FRZACK_SHIFT)
    {
    	/* Good practice: wait for FRZACK to clear (not in freeze mode) */
    	;
    }

    while ((CAN0->MCR && CAN_MCR_NOTRDY_MASK) >> CAN_MCR_NOTRDY_SHIFT)
    {
    	/* Good practice: wait for NOTRDY to clear (module ready)  */
    	;
    }
    /* Init BusOff Flag */
    Can_bBusoffFlag = FALSE;
}

/*****************************FD_CAN Send**************************************/
static uint32  u32Byte2Dword(uint8* pu8Data, uint8 u8Length)
{
    uint32_t u32Temp = 0;
    uint8_t u8Len = u8Length;
    uint8_t u8Ind;
    if (4 < u8Len)
    {
        u8Len = 4;
    }
    for (u8Ind = 0; u8Ind < u8Len; u8Ind++)
    {
        u32Temp <<= 8;
        u32Temp += pu8Data[u8Ind];
    }
    return u32Temp;
}

static uint8_t u8GetDlc(uint8_t u8Length)
{
    uint8_t u8Dlc;

    if (8 >= u8Length)
    {
        u8Dlc = u8Length;
    }
    else if (24 >= u8Length)
    {
        u8Dlc = 6 + ((u8Length + 3) >> 2);
    }
    else if (64 >= u8Length)
    {
        u8Dlc = 11 + ((u8Length + 15) >> 4);
    }
    else
    {
        u8Dlc = 15;
    }
    
    return u8Dlc;
}

#define CODE_SHIFT      (24u)
#define CODE_WIDTH      (4u)
#define CODE_INACTIVE   (0x0u)
#define CODE_TX_FULL    (0xCu)
uint32 Can_u32TrasnimitMsg(uint32 u32MsgBufId, Can_tstrPduType *pstrPduType)
{
    uint8_t j;
	uint32 u32Result = 0u;
    uint32_t u32Code = (CAN0->RAMn[ u32MsgBufId*MSG_BUF_SIZE + 0] >> CODE_SHIFT)&((1 << CODE_WIDTH) - 1u);
    if ((CODE_INACTIVE ==  (u32Code & 0x7u)) || ((CAN0->IFLAG1) & (1 << u32MsgBufId)))
	{
	   /* Clear CAN 0 MB 0 flag without clearing others*/
	   CAN0->IFLAG1 = 0x1 << u32MsgBufId;
       if (64u < pstrPduType->u8Dlc)
       {
          pstrPduType->u8Dlc = 64u;
       }
       for (j = 0; j < ((pstrPduType->u8Dlc + 3) >> 2); j++)
       {
          CAN0->RAMn[ u32MsgBufId*MSG_BUF_SIZE + 2 + j] = u32Byte2Dword(&(pstrPduType->pu8Data[j << 2]), 4); /* MB0 word 2: data word 0 */
       }
       //CAN0->RAMn[ u32MsgBufId*MSG_BUF_SIZE + 3] = u32Byte2Dword(&(pstrFrame->au8Data[4]), 4); /* MB0 word 3: data word 1 */
       CAN0->RAMn[u32MsgBufId*MSG_BUF_SIZE + 1] = ((pstrPduType->u32CanId)<<18u) ; /* MB word 1: Tx msg with STD ID */


       CAN0->RAMn[u32MsgBufId*MSG_BUF_SIZE + 0] = 0xCC400000 | (u8GetDlc(pstrPduType->u8Dlc)) <<CAN_WMBn_CS_DLC_SHIFT; /* MB0 word 0: */
                                                /* EDL=1 CAN FD format frame*/
                                                /* BRS=1: Bit rate is switched inside msg */
                                                /* ESI=0: ??? */
                                                /* CODE=0xC: Activate msg buf to transmit */
                                                /* IDE=0: Standard ID */
                                                /* SRR=1 Tx frame (not req'd for std ID) */
                                                /* RTR = 0: data, not remote tx request frame*/
                                                /* DLC=15; 64 bytes */
	 }
	 else
	 {
	    u32Result = 1;
	 }
	return u32Result;
}

/*! this function only for can send msg test*/
#if 0
static uint8  Can_au8TxDefaultValue[64]=
{
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu
};

void Can_vidSendMsgManage(void)
{
	uint8  u8Index1;
    static uint8 LOC_u8Cnt = 0u;
    Can_tstrPduType astrPdu;

    astrPdu.u32CanId = ((0x200u) << 18u);
    astrPdu.u8Dlc= 64u;
    astrPdu.pu8Data= Can_au8TxDefaultValue;
    LOC_u8Cnt++;
    for(u8Index1 = 0u; u8Index1 < 64u; u8Index1++)
    {
          astrPdu.pu8Data[u8Index1] = LOC_u8Cnt; 
    }
    if(LOC_u8Cnt == 255)
    {
       LOC_u8Cnt = 0u;
    }
    Can_u32TrasnimitMsg(TX_BUF0_ID, &astrPdu);
}
#endif

/*****************************FD_CAN Receive************************************/
static const uint8_t au8DlcToLen[] =
{
  0, 1, 2, 3, 4, 5, 6, 7, 8, 12, 16, 20, 24, 32, 48, 64
};

static uint8  Can_au8RxDefaultValue[64]=
{
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu,
  0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu, 0xFFu
};


uint32_t  RxCODE;              /* Received message buffer code */
uint32_t  RxID;                /* Received message ID */
uint32_t  RxLENGTH;            /* Recieved message number of data bytes */
uint32_t  RxDATA[2];           /* Received message data (2 words) */
uint32_t  RxTIMESTAMP;         /* Received message time */

void CAN0_ORed_0_15_MB_IRQHandler(void)
{
    Can_tstrPduType strPdu;
    uint32 u32Temp;
    uint32 u32MsgBufId;
    uint8_t u8Tmp;
    uint8_t j;
  
    strPdu.pu8Data = Can_au8RxDefaultValue;
  
    u32Temp = CAN0->IFLAG1;
    if ((u32Temp >> RX_BUF2_ID) & 1)
    {
	  u32MsgBufId = RX_BUF2_ID;
    }
    else if ((u32Temp >> RX_BUF3_ID) & 1)
    {
	  u32MsgBufId = RX_BUF3_ID;
    }
    else if ((u32Temp >> RX_BUF4_ID) & 1)
    {
	  u32MsgBufId = RX_BUF4_ID;
    }
    else if ((u32Temp >> RX_BUF4_ID) & 1)
    {
	  u32MsgBufId = RX_BUF4_ID;
    }
    else if ((u32Temp >> RX_BUF5_ID) & 1)
    {
	  u32MsgBufId = RX_BUF5_ID;
    }
    else if ((u32Temp >> RX_BUF6_ID) & 1)
    {
	  u32MsgBufId = RX_BUF6_ID;
    }
    else
    {

    }
    RxCODE   = (CAN0->RAMn[ u32MsgBufId * MSG_BUF_SIZE + 0] & 0x07000000) >> 24;  /* Read CODE field */
    strPdu.u32CanId = (CAN0->RAMn[u32MsgBufId * MSG_BUF_SIZE + 1] & CAN_WMBn_ID_ID_MASK)  >> CAN_WMBn_ID_ID_SHIFT ;
    u8Tmp = (CAN0->RAMn[u32MsgBufId * MSG_BUF_SIZE + 0] & CAN_WMBn_CS_DLC_MASK) >> CAN_WMBn_CS_DLC_SHIFT;
    strPdu.u8Dlc = au8DlcToLen[u8Tmp & 0x0F];
    if (8 >= strPdu.u8Dlc)
    {
        u8Tmp = 2;
    }
    else
    {
        u8Tmp = (strPdu.u8Dlc) >> 2;
    }
    for (j = 0; j < u8Tmp; j++)
    {  /* Read two words of data (8 bytes) */
      u32Temp = CAN0->RAMn[u32MsgBufId * MSG_BUF_SIZE + 2 + j];
      strPdu.pu8Data[(j << 2) + 0] = (u32Temp >> 24) & 0xFFu;
      strPdu.pu8Data[(j << 2) + 1] = (u32Temp >> 16) & 0xFFu;
      strPdu.pu8Data[(j << 2) + 2] = (u32Temp >>  8) & 0xFFu;
      strPdu.pu8Data[(j << 2) + 3] = (u32Temp >>  0) & 0xFFu;
    }
    u32Temp = CAN0->TIMER;             /* Read TIMER to unlock message buffers */
    Can_vidRxHandler(strPdu);
    CAN0->IFLAG1 = (0x1 << u32MsgBufId); /* Clear CAN 0 MB 4 flag without clearing others*/
}


void CAN0_ORed_16_31_MB_IRQHandler(void)
{

}


/*****************************FD_CAN BusOff************************************/
uint8 Can_u8GetBusStatus(void)
{
    return (uint8)Can_bBusoffFlag;
}


void CAN0_ORed_IRQHandler(void)
{
	CAN0->ESR1 |= (1<<19U);/*clear busoff interrupt flag*/
	Can_bBusoffFlag = TRUE;
}





