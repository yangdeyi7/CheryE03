/******************************************************************************/
/* PROJECT  :  CHJ_D01                                                        */
/******************************************************************************/
/* !Layer           : Can                                                     */
/*                                                                            */
/* !Component       : Can                                                     */
/* !Description     : Interface for Managing the can                          */
/*                                                                            */
/* !Module          : can                                                     */
/* !Description     : can                                                     */
/*                                                                            */
/* !File            : Can_Cfg.h                                               */
/*                                                                            */
/* !Scope           : Private                                                 */
/*                                                                            */
/* !Target          : RH850F1K_S1_R7F7016843                                  */
/*                                                                            */
/* !Vendor          : (VALEO Climate Control China)                           */
/*                                                                            */
/* Coding language  : C                                                       */
/*                                                                            */
/* all rights reserved                                                        */
/******************************************************************************/
#ifndef CANCFG_H
#define CANCFG_H

#include "Port.h"
/***********************Can Port ID Set Define********************************/

#define CAN_u8CAN1TX_ID              ((uint8)0)
#define CAN_u8CAN1RX_ID              ((uint8)1)

/*****************************Can Rx_Rule Define******************************/

typedef struct
{
  	uint32 lword[4];
} Can_tstrCreType;

#define RX_RULE_NUM_CH0              (0U)         /* Channel 0 Rx rule number */
#define RX_RULE_NUM_CH1              (18U)        /* Channel 1 Rx rule number */  /*need to modify*/
#define RX_RULE_NUM_CH2              (0U)         /* Channel 2 Rx rule number */
#define RX_RULE_NUM_CH3              (0U)         /* Channel 3 Rx rule number */
#define RX_RULE_NUM_CH4              (0U)         /* Channel 4 Rx rule number */
#define RX_RULE_NUM_CH5              (0U)         /* Channel 5 Rx rule number */

#define CAN_C0RN                     RX_RULE_NUM_CH0
#define CAN_C1RN                     RX_RULE_NUM_CH1 
#define CAN_C2RN                     RX_RULE_NUM_CH2
#define CAN_C3RN                     RX_RULE_NUM_CH3
#define CAN_C4RN                     RX_RULE_NUM_CH4
#define CAN_C5RN                     RX_RULE_NUM_CH5
#define CAN_RX_RULE_NUM              (CAN_C0RN + CAN_C1RN + CAN_C2RN + CAN_C3RN + CAN_C4RN + CAN_C5RN)
#define CAN_RX_RULE_TYPE             Can_tstrCreType

/*can chn & txbuf & rxfifo & rxbuf*/
#define CANDEV_CH_NUM       	(6U)
#define CAN_MAX_TXBUF_NUM   	(32U)
#define CAN_MAX_RXFIFO_NUM   	(8U)
#define CAN_MAX_RXBUFF_NUM   	(96U)

/*rx rule table*/
extern const CAN_RX_RULE_TYPE CAN_RX_RULE_TABLE[CAN_RX_RULE_NUM];
extern const Port_tstrPortCfgType Can_akstrPortCfg[];

#endif /* CANCFG_H */

/*-------------------------------- end of file -------------------------------*/
